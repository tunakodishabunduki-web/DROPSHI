# DropShip AI v2 Module Guide

This guide walks through the major modules, explaining what each block manages and suggesting alternative ways to accomplish the same goal.

## Backend Bootstrap (`src/main.ts` + `src/app.module.ts`)
- **Purpose:** Wire Nest, TypeORM, Bull, Cache, and Swagger so the API, scheduled jobs, and queues boot together. It also enforces validation and route prefixes.
- **Alternative:** Instead of manual Swagger setup, `nestjs/swagger` decorators can be placed on each module and you could auto-generate docs in a build step. You could also swap `NestFactory.create` for `NestFactory.createMicroservice` if you need only queue workers.

## Autopilot Module (`modules/autopilot`)
- **Purpose:** Runs pricing, ad, supplier, and product-import logic on a cron timer. Stores every action in `autopilot_decisions` for traceability.
- **Alternative:** Replace the custom `runCycleForTenant` with a message-per-task approach where each optimization enqueues its own Bull job; this improves parallelism but needs more queue management.

## Social Media Module (`modules/social-media`)
- **Purpose:** Handles OAuth, creative generation, publishing, and analytics. Uses OpenAI to generate TikTok/IG/Facebook creatives, then caches them in campaigns/posts tables.
- **Alternative:** Instead of OpenAI JSON parsing, you could call a dedicated creative microservice or use templated string heuristics; that removes AI reliance but reduces novelty.

## Viral Detector / Inventory / Reports / Profitability Modules
- These modules fill the dashboards: viral trends feed the product grid, inventory forecaster warns about stockouts, daily reports generate summaries, and profitability tracks margins.
- **Alternative:** Each module could expose raw CSV exports or WebSocket streams for real-time dashboards rather than REST endpoints.

## AI Worker (`ai-modules/unified_worker.py`)
- **Purpose:** Single worker listens to `critical`, `standard`, and `background` queues to run autopilot cycles, viral scans, inventory forecasts, and reports. Pydantic schemas now validate OpenAI output.
- **Alternative:** Split this into specialized workers (pricing-worker, social-worker, etc.) if you need horizontal scaling or want to deploy the tasks separately.

## Frontend Reference (`frontend/src/...` + `frontend/index.html`)
- **Purpose:** New Next.js workspace provides layout/styles/hooks/stores and a simple API client for `@/lib`. The standalone `index.html` documents architecture.
- **Alternative:** You might build a fully static marketing site using the same HTML while keeping the Next frontend solely for the authenticated dashboard.

### Cross-Cutting Guidance
- **Comments/DTOs** highlight how data flows; beginners should follow the DTOs to understand schema expectations (e.g., `GenerateCreativeDto` or the Pydantic classes).
- **Testing** is scaffolded with Jest specs for key services—these tests mimic fallback behavior and prove the modules handle broken AI responses gracefully.
- **Deployment Tip:** Complete the missing docker/infra steps (Postgres, Redis, RabbitMQ, OpenAI keys) before launching; the `docker-compose` file already outlines these containers.

This document can be read alongside the commented files so a beginner can see both inline explanations and module-level overviews.
