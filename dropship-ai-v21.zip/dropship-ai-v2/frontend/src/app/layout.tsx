import { ReactNode } from 'react';
import './globals.css';

export const metadata = {
  title: 'DropShip AI',
  description: 'AI-powered drop shipping automation platform',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-50 font-sans min-h-screen">
        {children}
      </body>
    </html>
  );
}
