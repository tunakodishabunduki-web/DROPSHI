import { useMemo } from 'react';

export function useUiStore() {
  return useMemo(() => ({
    theme: 'dark',
    setTheme: (value: string) => {
      console.log('theme change', value);
    },
  }), []);
}
