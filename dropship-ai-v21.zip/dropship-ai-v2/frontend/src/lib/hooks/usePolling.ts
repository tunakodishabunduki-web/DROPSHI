'use client';
import { useEffect, useRef } from 'react';

export function usePolling(callback: () => void, delay: number) {
  const saved = useRef(callback);

  useEffect(() => {
    saved.current = callback;
  }, [callback]);

  useEffect(() => {
    const tick = () => saved.current();
    const id = setInterval(tick, delay);
    tick();
    return () => clearInterval(id);
  }, [delay]);
}
