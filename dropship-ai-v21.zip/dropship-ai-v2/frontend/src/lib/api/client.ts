const BASE_URL = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1').replace(/\/$/, '');

const ensurePath = (path: string) => path.startsWith('/') ? path : `/${path}`;

const handleResponse = async (res: Response) => {
  if (!res.ok) {
    const message = await res.text().catch(() => res.statusText);
    throw new Error(`${res.status} ${res.statusText} - ${message}`);
  }
  return res.json();
};

export const api = {
  get: (path: string, options: RequestInit = {}) =>
    fetch(`${BASE_URL}${ensurePath(path)}`, { method: 'GET', ...options }).then(handleResponse),
  post: (path: string, body?: any, options: RequestInit = {}) =>
    fetch(`${BASE_URL}${ensurePath(path)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      body: body ? JSON.stringify(body) : undefined,
      ...options,
    }).then(handleResponse),
};
