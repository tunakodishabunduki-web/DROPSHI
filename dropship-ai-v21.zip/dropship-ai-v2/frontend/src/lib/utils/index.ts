export const formatCurrency = (value?: number) =>
  value !== undefined && value !== null ? `$${value.toFixed(2)}` : '$0.00';

export const formatNumber = (value?: number) =>
  value !== undefined && value !== null ? value.toLocaleString() : '0';

export const formatRelativeTime = (value?: string | number | Date) => {
  if (!value) return 'just now';
  const d = typeof value === 'string' || typeof value === 'number' ? new Date(value) : value;
  const diff = Math.floor((Date.now() - d.getTime()) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
};
