"""
DropShip AI v2 — Unified AI Worker
Handles ALL AI tasks from 3 consolidated queues: critical, standard, background
"""

import os
import json
import time
import logging
import threading
from datetime import datetime
from typing import Callable, Type, TypeVar

import pika
import redis
import psycopg2
from psycopg2.extras import RealDictCursor
from openai import OpenAI
from pydantic import BaseModel, Field, ValidationError
from tenacity import retry, stop_after_attempt, wait_exponential

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
)
logger = logging.getLogger('unified_worker')

# ── Config ─────────────────────────────────────────────────────────────────────
RABBITMQ_URL = os.getenv('RABBITMQ_URL', 'amqp://dropship:rabbitmq_secret@localhost:5672/dropship')
REDIS_URL = os.getenv('REDIS_URL', 'redis://:redis_secret@localhost:6379')
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://dropship:dropship_secret@localhost:5432/dropship_db')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')

QUEUES = ['critical', 'standard', 'background']

client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None
redis_client = redis.from_url(REDIS_URL, decode_responses=True)

# Schema describing each product entry returned from the AI discovery worker.
class AutoImportProduct(BaseModel):
    # Schema describing each product returned by the AI discovery job.
    name: str
    score: float = Field(ge=0)
    category: str
    estimatedMargin: float = Field(ge=0)


class AutoImportResponse(BaseModel):
    # The top-level wrapper defines the expected structure returned by OpenAI.
    products: list[AutoImportProduct] = []


class ViralTrend(BaseModel):
    # Each trend captures the signal used in the dashboard and alerts.
    keyword: str
    platform: str
    score: float = Field(ge=0)
    growthRate: float = Field(ge=0)
    category: str
    currentValue: float = Field(ge=0)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ViralScanResponse(BaseModel):
    # Ensures the viral scan has a stable list before mutating it.
    trends: list[ViralTrend] = []


T = TypeVar('T', bound=BaseModel)


def parse_openai_response(model: Type[T], payload: str, retries: int = 3) -> T:
    # Retry parsing to handle slight format drift from OpenAI responses.
    attempt = 0
    text = payload.strip()
    while attempt < retries:
        try:
            return model.parse_raw(text)
        except ValidationError as exc:
            logger.warning('OpenAI response failed schema validation (attempt %s): %s', attempt + 1, exc.errors())
        except json.JSONDecodeError as exc:
            logger.warning('OpenAI response could not be parsed (attempt %s): %s', attempt + 1, exc)
        attempt += 1
        time.sleep(0.5 * attempt)
    raise ValueError('Failed to parse OpenAI response after retries')


def get_db():
    return psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)


# ── Task Handlers ──────────────────────────────────────────────────────────────

def handle_autopilot_cycle(payload: dict):
    """Run autopilot optimization cycle for a tenant."""
    tenant_id = payload.get('tenantId')
    logger.info(f'Running autopilot cycle for {tenant_id}')

    with get_db() as conn:
        with conn.cursor() as cur:
            # Get autopilot config
            cur.execute(
                'SELECT * FROM autopilot_configs WHERE tenant_id = %s AND enabled = true',
                (tenant_id,),
            )
            config = cur.fetchone()
            if not config:
                return

            config = dict(config)

            # Price optimization — check all active products
            cur.execute(
                """SELECT id, name, base_price, cost_price, ai_score
                   FROM products WHERE tenant_id = %s AND status = 'active'
                   AND deleted_at IS NULL LIMIT 50""",
                (tenant_id,),
            )
            products = [dict(p) for p in cur.fetchall()]

        # Log each pricing decision
        min_margin = float(config.get('min_margin_percent', 35)) / 100
        for product in products:
            cost = float(product.get('cost_price') or 0)
            current = float(product.get('base_price') or 0)
            min_price = cost * (1 + min_margin)

            if current < min_price:
                # Price is below minimum — fix it
                new_price = round(min_price * 1.05, 2)
                with get_db() as conn:
                    with conn.cursor() as cur:
                        cur.execute(
                            'UPDATE products SET base_price = %s WHERE id = %s',
                            (new_price, product['id']),
                        )
                        cur.execute(
                            """INSERT INTO autopilot_decisions
                               (tenant_id, action, target, target_id, old_value, new_value, confidence, reasoning, approved)
                               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                            (tenant_id, 'PRICE_UPDATE', 'product', product['id'],
                             json.dumps(current), json.dumps(new_price), 0.95,
                             f'Price was ${current} which is below minimum margin floor ${min_price:.2f}. Corrected to ${new_price}.',
                             True),
                        )
                        conn.commit()

    logger.info(f'Autopilot cycle complete for {tenant_id}')


def handle_auto_import_products(payload: dict):
    """Auto-import high-scoring products from suppliers."""
    tenant_id = payload.get('tenantId')
    min_score = float(payload.get('minScore', 75))
    limit = int(payload.get('limit', 20))

    logger.info(f'Auto-importing products for {tenant_id} (min score: {min_score})')

    # Get trending keywords from cache
    cached = redis_client.get(f'trending:{tenant_id}:general')
    if not cached and client:
        try:
        response = client.chat.completions.create(
            model='gpt-4o-mini',
            messages=[{
                'role': 'user',
                'content': f'Generate {limit} dropshipping product keywords currently trending on TikTok/Instagram 2025-2026. JSON: {{"products": [{{"name": str, "score": int, "category": str, "estimatedMargin": int}}]}}'
            }],
            response_format={'type': 'json_object'},
            max_tokens=500,
        )
        parsed = parse_openai_response(AutoImportResponse, response.choices[0].message.content)
        products = [p for p in parsed.products if p.score >= min_score]

        logger.info(f'Auto-import found {len(products)} qualifying products for {tenant_id}')

            # Log to AI logs
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """INSERT INTO ai_logs (tenant_id, module, task_type, status, output_data)
                           VALUES (%s, %s, %s, %s, %s)""",
                        (tenant_id, 'autopilot', 'auto_import', 'completed',
                         json.dumps({'productsFound': len(products)})),
                    )
                    conn.commit()
        except Exception as e:
            logger.error(f'Auto-import AI call failed: {e}')


def handle_viral_scan(payload: dict):
    """Scan for viral product opportunities."""
    tenant_id = payload.get('tenantId')
    logger.info(f'Running viral scan for {tenant_id}')

    if not client:
        return

    try:
        response = client.chat.completions.create(
            model='gpt-4o-mini',
            messages=[{
                'role': 'user',
                'content': 'List 15 dropshipping products going viral on TikTok/Instagram right now (March 2026). JSON: {"trends": [{"keyword": str, "score": int, "platform": str, "growthRate": int, "category": str, "currentValue": int}]}'
            }],
            response_format={'type': 'json_object'},
            max_tokens=600,
        )
        parsed = parse_openai_response(ViralScanResponse, response.choices[0].message.content)
        trends = parsed.trends

        with get_db() as conn:
            with conn.cursor() as cur:
                for trend in trends:
                    cur.execute(
                        """INSERT INTO trends (tenant_id, keyword, platform, score, growth_rate, category, data_snapshot)
                           VALUES (%s, %s, %s, %s, %s, %s, %s)
                           ON CONFLICT DO NOTHING""",
                        (tenant_id, trend.keyword, trend.platform,
                         trend.score, trend.growthRate, trend.category,
                         json.dumps(trend.dict(exclude_none=True))),
                    )
                conn.commit()

        # Cache the results
        redis_client.setex(
            f'trending:{tenant_id}:general',
            3600,
            json.dumps([t.dict(exclude_none=True) for t in trends]),
        )
        logger.info(f'Viral scan saved {len(trends)} trends for {tenant_id}')
    except Exception as e:
        logger.error(f'Viral scan failed: {e}')


def handle_inventory_forecast(payload: dict):
    """Run inventory forecasts for all products of a tenant."""
    tenant_id = payload.get('tenantId')
    logger.info(f'Running inventory forecast for {tenant_id}')

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT p.id, p.name, p.stock_quantity, p.low_stock_threshold,
                          COALESCE(s.avg_ship_days, 14) as lead_days
                   FROM products p
                   LEFT JOIN suppliers s ON s.id = p.supplier_id
                   WHERE p.tenant_id = %s AND p.status = 'active' AND p.track_inventory = true""",
                (tenant_id,),
            )
            products = [dict(p) for p in cur.fetchall()]

            for product in products:
                # Get 30-day sales velocity
                cur.execute(
                    """SELECT COALESCE(SUM(quantity)::float / 30, 0.5) as daily_velocity
                       FROM order_items oi JOIN orders o ON o.id = oi.order_id
                       WHERE oi.product_id = %s AND o.status != 'cancelled'
                       AND o.created_at >= NOW() - INTERVAL '30 days'""",
                    (product['id'],),
                )
                vel_row = cur.fetchone()
                daily_velocity = float(vel_row['daily_velocity'] if vel_row else 0.5)
                stock = int(product.get('stock_quantity') or 0)
                lead_days = int(product.get('lead_days') or 14) + 3

                days_left = int(stock / daily_velocity) if daily_velocity > 0 else 999

                if days_left <= lead_days:
                    logger.warning(f'[{tenant_id}] {product["name"]}: {days_left} days left — reorder needed')


def handle_daily_report(payload: dict):
    """Generate daily report for a tenant."""
    tenant_id = payload.get('tenantId')
    logger.info(f'Generating daily report for {tenant_id}')

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT COALESCE(SUM(total), 0) as revenue, COUNT(*) as orders
                   FROM orders WHERE tenant_id = %s AND created_at::date = CURRENT_DATE
                   AND status != 'cancelled'""",
                (tenant_id,),
            )
            today = dict(cur.fetchone() or {})

            # Simple report generation
            report_data = {
                'tenantId': tenant_id,
                'generatedAt': time.strftime('%Y-%m-%dT%H:%M:%SZ'),
                'summary': {
                    'revenue': {'today': float(today.get('revenue') or 0)},
                    'orders': {'today': int(today.get('orders') or 0)},
                },
            }

            cur.execute(
                """INSERT INTO daily_reports (tenant_id, report_date, data)
                   VALUES (%s, CURRENT_DATE, %s)
                   ON CONFLICT (tenant_id, report_date) DO UPDATE SET data = %s""",
                (tenant_id, json.dumps(report_data), json.dumps(report_data)),
            )
            conn.commit()


# ── Task Router ────────────────────────────────────────────────────────────────
TASK_HANDLERS: dict[str, Callable] = {
    'autopilot_cycle': handle_autopilot_cycle,
    'autopilot_full_scan': handle_autopilot_cycle,
    'auto_import_products': handle_auto_import_products,
    'viral_scan': handle_viral_scan,
    'inventory_forecast': handle_inventory_forecast,
    'generate_daily_report': handle_daily_report,
}


# ── Worker Core ────────────────────────────────────────────────────────────────
class UnifiedWorker:
    def __init__(self, queue: str):
        self.queue = queue
        self.connection = None
        self.channel = None

    @retry(stop=stop_after_attempt(10), wait=wait_exponential(min=2, max=30))
    def connect(self):
        params = pika.URLParameters(RABBITMQ_URL)
        params.heartbeat = 600
        self.connection = pika.BlockingConnection(params)
        self.channel = self.connection.channel()

        # Declare DLX
        self.channel.exchange_declare(f'{self.queue}.dlx', exchange_type='direct', durable=True)
        self.channel.queue_declare(f'{self.queue}.dead', durable=True)
        self.channel.queue_bind(f'{self.queue}.dead', f'{self.queue}.dlx', routing_key=self.queue)

        # Declare main queue
        self.channel.queue_declare(
            self.queue, durable=True,
            arguments={
                'x-dead-letter-exchange': f'{self.queue}.dlx',
                'x-dead-letter-routing-key': self.queue,
            },
        )
        self.channel.basic_qos(prefetch_count=1)
        logger.info(f'Worker connected to queue: {self.queue}')

    def process(self, ch, method, properties, body):
        start = time.time()
        try:
            payload = json.loads(body)
            task_type = payload.get('type') or payload.get('taskType', 'unknown')
            logger.info(f'[{self.queue}] Processing: {task_type}')

            handler = TASK_HANDLERS.get(task_type)
            if handler:
                handler(payload)
            else:
                logger.warning(f'Unknown task type: {task_type}')

            ch.basic_ack(delivery_tag=method.delivery_tag)
            logger.info(f'[{self.queue}] {task_type} done in {(time.time()-start)*1000:.0f}ms')
        except Exception as e:
            logger.error(f'[{self.queue}] Task failed: {e}', exc_info=True)
            retry_count = (properties.headers or {}).get('x-retry-count', 0)
            if retry_count < 3:
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                self.channel.basic_publish(
                    exchange='', routing_key=self.queue, body=body,
                    properties=pika.BasicProperties(
                        delivery_mode=2,
                        headers={'x-retry-count': retry_count + 1},
                        expiration=str(5000 * (2 ** retry_count)),
                    ),
                )
            else:
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

    def start(self):
        while True:
            try:
                self.connect()
                self.channel.basic_consume(queue=self.queue, on_message_callback=self.process)
                logger.info(f'[{self.queue}] Waiting for tasks...')
                self.channel.start_consuming()
            except pika.exceptions.AMQPConnectionError:
                logger.error(f'[{self.queue}] Connection lost, reconnecting...')
                time.sleep(5)
            except KeyboardInterrupt:
                break


def start_worker(queue: str):
    worker = UnifiedWorker(queue)
    worker.start()


if __name__ == '__main__':
    logger.info('Starting DropShip AI v2 Unified Worker...')
    logger.info(f'Processing queues: {", ".join(QUEUES)}')

    # Start each queue in its own thread
    threads = []
    for queue in QUEUES:
        t = threading.Thread(target=start_worker, args=(queue,), daemon=True)
        t.start()
        threads.append(t)
        logger.info(f'Started thread for queue: {queue}')

    # Keep main thread alive
    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        logger.info('Shutting down workers...')
