import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { CacheModule } from '@nestjs/cache-manager';
import { ScheduleModule } from '@nestjs/schedule';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { AutopilotController } from './modules/autopilot/autopilot.controller';
import { AutopilotService } from './modules/autopilot/autopilot.service';
import { AutopilotConfig } from './modules/autopilot/entities/autopilot-config.entity';
import { AutopilotDecision } from './modules/autopilot/entities/autopilot-decision.entity';
import { SocialMediaController } from './modules/social-media/social-media.controller';
import { SocialMediaService } from './modules/social-media/social-media.service';
import { SocialAccount } from './modules/social-media/entities/social-account.entity';
import { SocialCampaign } from './modules/social-media/entities/social-campaign.entity';
import { SocialPost } from './modules/social-media/entities/social-post.entity';
import { AiAssistantController, ViralDetectorController, InventoryForecasterController, ProfitabilityController, DailyReportController } from './modules/ai-assistant/ai-assistant.controller';
import { AiAssistantService } from './modules/ai-assistant/ai-assistant.service';
import { ViralDetectorService } from './modules/viral-detector/viral-detector.service';
import { InventoryForecasterService } from './modules/inventory-forecaster/inventory-forecaster.service';
import { ProfitabilityService } from './modules/profitability/profitability.service';
import { DailyReportService } from './modules/daily-report/daily-report.service';

@Module({
  imports: [
    // Load configuration globally so any module can access env vars.
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    // Cache storage is shared by services for autopilot configs, viral data, etc.
    CacheModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        isGlobal: true,
        ttl: Number(config.get('CACHE_TTL') || 30),
      }),
    }),
    // Database connection; typeorm auto-loads entities so we don’t re-register every table.
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        url: config.get('DATABASE_URL') || 'postgresql://dropship:dropship_secret@localhost:5432/dropship_db',
        autoLoadEntities: true,
        synchronize: false,
        logging: config.get('NODE_ENV') !== 'production',
        ssl: config.get('DB_SSL') === 'true' ? { rejectUnauthorized: false } : undefined,
      }),
    }),
    // Register only the entities used directly by modules here to keep TypeORM aware of them.
    TypeOrmModule.forFeature([
      AutopilotConfig,
      AutopilotDecision,
      SocialAccount,
      SocialCampaign,
      SocialPost,
    ]),
    // Bull handles background queues; configure redis based on env.
    BullModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        redis: {
          url: config.get('REDIS_URL') || 'redis://:redis_secret@localhost:6379',
        },
      }),
    }),
    BullModule.registerQueue({ name: 'critical' }, { name: 'standard' }, { name: 'background' }),
    ScheduleModule.forRoot(),
    EventEmitterModule.forRoot(),
  ],
  controllers: [
    AutopilotController,
    SocialMediaController,
    AiAssistantController,
    ViralDetectorController,
    InventoryForecasterController,
    ProfitabilityController,
    DailyReportController,
  ],
  providers: [
    AutopilotService,
    SocialMediaService,
    AiAssistantService,
    ViralDetectorService,
    InventoryForecasterService,
    ProfitabilityService,
    DailyReportService,
  ],
})
export class AppModule {}
