import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import type { Request } from 'express';

@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext) {
    const req = context.switchToHttp().getRequest<Request & { tenantId?: string; user?: any }>();
    const headerTenant = (req.headers['x-tenant-id'] || req.headers['tenant-id']) as string | undefined;
    const tenantId = headerTenant || req.tenantId || req.user?.tenantId || process.env.DEFAULT_TENANT_ID;
    if (!tenantId) {
      throw new UnauthorizedException('Tenant context is required. Pass X-Tenant-Id header with each request.');
    }
    req.tenantId = tenantId;
    return true;
  }
}
