import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import type { Request } from 'express';

const DEFAULT_TENANT = process.env.DEFAULT_TENANT_ID || 'demo-tenant';
const DEFAULT_USER_ID = process.env.DEFAULT_USER_ID || 'system-user';
const DEFAULT_ROLES = (process.env.DEFAULT_USER_ROLES || 'tenant_admin').split(',').map((r) => r.trim());

@Injectable()
export class JwtAuthGuard implements CanActivate {
  canActivate(context: ExecutionContext) {
    const req = context.switchToHttp().getRequest<Request & { user?: any; tenantId?: string }>();
    const authHeader = req.headers['authorization'] as string | undefined;
    const tenantHeader = (req.headers['x-tenant-id'] || req.headers['tenant-id']) as string | undefined;

    if (!authHeader && !process.env.ALLOW_ANONYMOUS_ACCESS) {
      throw new UnauthorizedException('Missing Authorization header. Supply Bearer token or set ALLOW_ANONYMOUS_ACCESS=true for dev.');
    }

    let parsedUser: any = {};
    if (authHeader) {
      const token = authHeader.split(' ')[1];
      if (token) {
        try {
          parsedUser = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
        } catch {
          parsedUser = { token };
        }
      }
    }

    const tenantId = tenantHeader || parsedUser.tenantId || DEFAULT_TENANT;
    req.user = {
      id: parsedUser.id || DEFAULT_USER_ID,
      roles: parsedUser.roles || DEFAULT_ROLES,
      tenantId,
      ...(parsedUser.extra || {}),
    };
    req.tenantId = tenantId;
    return true;
  }
}
