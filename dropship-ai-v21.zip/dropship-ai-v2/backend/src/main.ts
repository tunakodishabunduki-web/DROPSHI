import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';

// The bootstrap function is the entry point of the NestJS application.
// It wires middleware, docs, and global settings before the server starts.
async function bootstrap() {
  // Create the application instance using our AppModule wiring.
  const app = await NestFactory.create(AppModule, { bodyParser: true });
  const config = app.get(ConfigService);

  // Prefix all routes so the API lives under /api/v1.
  app.setGlobalPrefix('api/v1');
  // Use Nest's ValidationPipe to strip unknown fields and transform payloads.
  app.useGlobalPipes(
    new ValidationPipe({ whitelist: true, transform: true, forbidNonWhitelisted: true }),
  );
  // Allow CORS from the configured domain.
  app.enableCors({ origin: config.get('CORS_ORIGIN') || '*', credentials: true });

  // Build Swagger/OpenAPI so developers can explore endpoints visually.
  const documentConfig = new DocumentBuilder()
    .setTitle('DropShip AI v2 API')
    .setDescription('Backend API for the DropShip AI automation platform')
    .setVersion('v1')
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, documentConfig);
  SwaggerModule.setup('api/docs', app, document);

  const port = Number(config.get('PORT') || 4000);
  await app.listen(port);
  // Log the listening address so devs know where to call the API.
  console.log(`NestJS listening on http://localhost:${port}`);
}

bootstrap();
