import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import axios from 'axios';
import { SocialAccount } from './entities/social-account.entity';
import { SocialCampaign } from './entities/social-campaign.entity';
import { SocialPost } from './entities/social-post.entity';
import { GenerateCreativeDto } from './dto/generate-creative.dto';
import { SocialPlatform, SocialPlatformEnum, SOCIAL_PLATFORMS } from './types/social-platform.type';
import { z } from 'zod';

const CreativeSchema = z.object({
  headline: z.string().min(10).max(120),
  script: z.string().min(1),
  caption: z.string().min(1),
  hashtags: z.array(z.string()).max(10),
  cta: z.string().min(1),
  variantB: z
    .object({
      headline: z.string().min(5).max(80),
      script: z.string().min(1),
      cta: z.string().min(1),
    })
    .optional(),
  bestPostTime: z.string().optional(),
  estimatedCtr: z.number().optional(),
});

export interface CampaignCreateDto {
  productId: string;
  platforms: SocialPlatform[];
  dailyBudget: number;
  durationDays: number;
  targetAudience?: object;
  autoPublish?: boolean;
}

export interface CreativeResult {
  platform: SocialPlatform;
  headline: string;
  script: string;
  caption: string;
  hashtags: string[];
  cta: string;
  variantB?: any;
  viralScore: number;
  estimatedCtr: number;
  bestPostTime: string;
}

// SocialMediaService orchestrates creative generation, campaign creation, and external API calls for ads.
@Injectable()
export class SocialMediaService {
  private readonly logger = new Logger(SocialMediaService.name);
  private openai: OpenAI;

  // Platform API base URLs
  private readonly PLATFORM_URLS = {
    tiktok: 'https://business-api.tiktok.com/open_api/v1.3',
    instagram: 'https://graph.facebook.com/v19.0',
    facebook: 'https://graph.facebook.com/v19.0',
  };

  constructor(
    @InjectRepository(SocialAccount) private accountsRepo: Repository<SocialAccount>,
    @InjectRepository(SocialCampaign) private campaignsRepo: Repository<SocialCampaign>,
    @InjectRepository(SocialPost) private postsRepo: Repository<SocialPost>,
    @InjectQueue('standard') private standardQueue: Queue,
    private dataSource: DataSource,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── OAuth Connect ──────────────────────────────────────────────────────────
  // Build an OAuth redirect URL so the dashboard can begin connecting a new platform.
  getOAuthUrl(platform: SocialPlatform, tenantId: string): string {
    const state = Buffer.from(JSON.stringify({ tenantId, platform })).toString('base64');
    const redirectUri = `${this.config.get('API_URL')}/api/v1/social/oauth/${platform}/callback`;

    switch (platform) {
      case 'tiktok':
        return `https://www.tiktok.com/auth/authorize/?client_key=${this.config.get('TIKTOK_CLIENT_KEY')}&scope=user.info.basic,video.upload,ads.read,ads.manage&response_type=code&redirect_uri=${redirectUri}&state=${state}`;

      case 'instagram':
      case 'facebook':
        const fbScopes = [
          'ads_management', 'ads_read', 'business_management',
          'instagram_basic', 'instagram_content_publish', 'pages_manage_ads',
        ].join(',');
        return `https://www.facebook.com/v19.0/dialog/oauth?client_id=${this.config.get('FACEBOOK_APP_ID')}&redirect_uri=${redirectUri}&scope=${fbScopes}&state=${state}&response_type=code`;
    }
  }

  // Handle the OAuth callback, exchange the code for tokens, and save them in the DB.
  async handleOAuthCallback(platform: SocialPlatform, code: string, tenantId: string) {
    const redirectUri = `${this.config.get('API_URL')}/api/v1/social/oauth/${platform}/callback`;
    let tokenData: any;

    try {
      if (platform === 'tiktok') {
        const response = await axios.post('https://business-api.tiktok.com/open_api/v1.3/oauth2/access_token/', {
          app_id: this.config.get('TIKTOK_CLIENT_KEY'),
          auth_code: code,
          secret: this.config.get('TIKTOK_CLIENT_SECRET'),
          grant_type: 'authorization_code',
        });
        tokenData = response.data.data;
      } else {
        const response = await axios.post('https://graph.facebook.com/v19.0/oauth/access_token', {
          client_id: this.config.get('FACEBOOK_APP_ID'),
          client_secret: this.config.get('FACEBOOK_APP_SECRET'),
          redirect_uri: redirectUri,
          code,
        });
        tokenData = response.data;
      }

      await this.accountsRepo.upsert(
        {
          tenantId,
          platform,
          accessToken: tokenData.access_token,
          refreshToken: tokenData.refresh_token,
          tokenExpiresAt: tokenData.expires_in
            ? new Date(Date.now() + tokenData.expires_in * 1000)
            : null,
          isActive: true,
          connectedAt: new Date(),
        },
        ['tenantId', 'platform'],
      );

      return { success: true, platform };
    } catch (e) {
      this.logger.error(`OAuth callback failed for ${platform}: ${e.message}`);
      throw new BadRequestException(`Failed to connect ${platform}: ${e.message}`);
    }
  }

  // ── Get Connected Accounts ─────────────────────────────────────────────────
  // Return the status of each platform connection so the UI can show badges.
  async getConnectedAccounts(tenantId: string) {
    const accounts = await this.accountsRepo.find({
      where: { tenantId },
      select: ['id', 'platform', 'isActive', 'connectedAt', 'accountName'],
    });

    return {
      tiktok: accounts.find((a) => a.platform === 'tiktok') || null,
      instagram: accounts.find((a) => a.platform === 'instagram') || null,
      facebook: accounts.find((a) => a.platform === 'facebook') || null,
    };
  }

  // ── Create Campaign ────────────────────────────────────────────────────────
  // Compose creatives, budgets, and store the campaign record before publishing.
  async createCampaign(tenantId: string, dto: CampaignCreateDto) {
    const product = await this.dataSource.query(
      'SELECT * FROM products WHERE id = $1 AND tenant_id = $2',
      [dto.productId, tenantId],
    );
    if (!product[0]) throw new BadRequestException('Product not found');

    const p = product[0];

    // Verify accounts are connected
    const accounts = await this.accountsRepo.find({
      where: { tenantId, isActive: true },
    });
    const connectedPlatforms = accounts.map((a) => a.platform);
    const validPlatforms = dto.platforms.filter((p) => connectedPlatforms.includes(p));

    if (validPlatforms.length === 0) {
      throw new BadRequestException('No connected accounts for selected platforms');
    }

    // Generate AI creatives for each platform
    const creatives = await this.generateCreativesForAllPlatforms(p, validPlatforms);

    // Calculate optimal budget split
    const budgetSplit = await this.calculateBudgetSplit(tenantId, validPlatforms, dto.dailyBudget, p);

    // Save campaign
    const campaign = await this.campaignsRepo.save(this.campaignsRepo.create({
      tenantId,
      productId: dto.productId,
      name: `${p.name} — Auto Campaign`,
      platforms: validPlatforms,
      dailyBudget: dto.dailyBudget,
      budgetSplit,
      durationDays: dto.durationDays,
      status: dto.autoPublish ? 'pending_publish' : 'draft',
      targetAudience: dto.targetAudience || {},
      creatives,
      totalBudget: dto.dailyBudget * dto.durationDays,
    }));

    if (dto.autoPublish) {
      await this.standardQueue.add('publish_social_campaign', {
        tenantId,
        campaignId: campaign.id,
      }, { priority: 7 });
    }

    return campaign;
  }

  // ── Publish Campaign ───────────────────────────────────────────────────────
  // Send the AI creatives to each connected social platform.
  async publishCampaign(tenantId: string, campaignId: string) {
    const campaign = await this.campaignsRepo.findOne({
      where: { id: campaignId, tenantId },
    });
    if (!campaign) throw new BadRequestException('Campaign not found');

    const publishResults: any[] = [];

    for (const platform of campaign.platforms) {
      try {
        const account = await this.accountsRepo.findOne({
          where: { tenantId, platform, isActive: true },
        });
        if (!account) continue;

        const creative = (campaign.creatives as any[])?.find((c) => c.platform === platform);
        const budget = (campaign.budgetSplit as any)[platform] || campaign.dailyBudget / campaign.platforms.length;

        let externalId: string;
        switch (platform) {
          case 'tiktok':
            externalId = await this.publishTikTokAd(account, campaign, creative, budget);
            break;
          case 'instagram':
            externalId = await this.publishInstagramAd(account, campaign, creative, budget);
            break;
          case 'facebook':
            externalId = await this.publishFacebookAd(account, campaign, creative, budget);
            break;
        }

        await this.postsRepo.save(this.postsRepo.create({
          tenantId,
          campaignId: campaign.id,
          platform,
          externalId,
          status: 'published',
          publishedAt: new Date(),
        }));

        publishResults.push({ platform, status: 'published', externalId });
      } catch (e) {
        this.logger.error(`Failed to publish to ${platform}: ${e.message}`);
        publishResults.push({ platform, status: 'failed', error: e.message });
      }
    }

    await this.campaignsRepo.update(campaign.id, { status: 'active' });
    return { campaign: campaign.id, results: publishResults };
  }

  // ── Generate AI Creatives ──────────────────────────────────────────────────
  // Helpers that request AI scripts for each platform and validate the response.
  async generateCreativesForAllPlatforms(
    product: any,
    platforms: SocialPlatform[],
  ): Promise<CreativeResult[]> {
    return Promise.all(platforms.map((p) => this.generateCreativeForPlatform(product, p)));
  }

  async generateCreativesPreview(tenantId: string, dto: GenerateCreativeDto) {
    const [product] = await this.dataSource.query(
      'SELECT * FROM products WHERE id = $1 AND tenant_id = $2',
      [dto.productId, tenantId],
    );
    if (!product) throw new BadRequestException('Product not found');

    const accounts = await this.accountsRepo.find({
      where: { tenantId, isActive: true },
    });
    const connectedPlatforms = accounts.map((a) => a.platform).filter((p): p is SocialPlatform => SOCIAL_PLATFORMS.includes(p as SocialPlatform));
    const requestedPlatforms = dto.platforms.filter((p) => connectedPlatforms.includes(p));

    if (requestedPlatforms.length === 0) {
      throw new BadRequestException('No connected accounts for selected platforms');
    }

    const creatives = await this.generateCreativesForAllPlatforms(product, requestedPlatforms);

    return {
      productId: product.id,
      productName: product.name,
      platforms: requestedPlatforms,
      creatives,
      dailyBudget: dto.dailyBudget,
      durationDays: dto.durationDays,
    };
  }

  async generateCreativeForPlatform(product: any, platform: SocialPlatform): Promise<CreativeResult> {
    const viralScore = await this.calculateViralScore(product, platform);

    const platformSpecs: Record<SocialPlatform, string> = {
      tiktok: `TikTok (15-60s vertical video): Create a hook in first 2 seconds. Use trending sounds. Gen Z / Millennial voice. Transformation or "wow" moment. Strong CTA at end.`,
      instagram: `Instagram (Reels/Stories): Aesthetic-first. Lifestyle positioning. Aspirational tone. Visual appeal description. Shopping tag mention. Story arc: problem → product → result.`,
      facebook: `Facebook (Feed/Carousel): Benefit-first headline. Address objections. Social proof. Clear value proposition. Urgency without being pushy. Broad audience appeal.`,
    };

    const prompt = `Generate high-converting ${platform} ad creative for this dropshipping product.

Product: ${product.name}
Price: $${product.base_price}
Category: ${product.category || 'General'}
Description: ${product.short_description || product.description?.slice(0, 200) || 'Quality product'}

Platform specs: ${platformSpecs[platform]}

Create 2 variants (A/B test) with different angles:
Variant A: Feature/benefit angle
Variant B: Emotional/lifestyle angle

Return JSON only:
{
  "headline": "Main headline (under 60 chars)",
  "script": "Full video script or ad copy (200-400 chars)",
  "caption": "Social media caption with emojis",
  "hashtags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
  "cta": "Call to action text",
  "variantB": {
    "headline": "...",
    "script": "...",
    "cta": "..."
  },
  "bestPostTime": "e.g. 7-9pm weekdays",
  "estimatedCtr": 0.035
}`;

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        max_tokens: 800,
      });

      const raw = response.choices[0].message.content.trim();
      const parsed = CreativeSchema.safeParse(JSON.parse(raw));
      if (!parsed.success) {
        throw new Error('Creative schema validation failed');
      }

      return {
        platform,
        ...parsed.data,
        viralScore,
        estimatedCtr: parsed.data.estimatedCtr ?? 0.02,
        bestPostTime: parsed.data.bestPostTime || '7-9pm weekdays',
      };
    } catch (e) {
      this.logger.error(`Creative generation failed for ${platform}: ${e.message}`);
      return this.buildFallbackCreative(product, platform, viralScore);
    }
  }

  private buildFallbackCreative(product: any, platform: SocialPlatform, viralScore: number): CreativeResult {
    const fallbackHashtags = ['dropshipai', 'viral', 'limited', 'deal', 'fresh'];
    const variantB = {
      headline: `${product.name} — Lifestyle glow`,
      script: `Feel ${product.name} in action. Tap to shop before it sells out.`,
      cta: 'Shop Today',
    };

    return {
      platform,
      headline: `${product.name} — AI Selected`,
      script: `Check out ${product.name}! Quality materials, fast shipping, competitor-beating price. Tap to buy now.`,
      caption: `🔥 ${product.name} is trending. Limited stock.`,
      hashtags: fallbackHashtags,
      cta: 'Shop Now',
      variantB,
      viralScore,
      estimatedCtr: 0.02,
      bestPostTime: '7-9pm weekdays',
    };
  }

  // ── Get Campaign Analytics ─────────────────────────────────────────────────
  async getCampaignAnalytics(tenantId: string, campaignId?: string) {
    const query = campaignId
      ? `SELECT * FROM social_campaigns WHERE id = $1 AND tenant_id = $2`
      : `SELECT sc.*, 
           SUM(sp.impressions) as total_impressions,
           SUM(sp.clicks) as total_clicks,
           SUM(sp.spent) as total_spent,
           AVG(sp.roas) as avg_roas
         FROM social_campaigns sc
         LEFT JOIN social_posts sp ON sp.campaign_id = sc.id
         WHERE sc.tenant_id = $1
         GROUP BY sc.id
         ORDER BY sc.created_at DESC
         LIMIT 20`;

    const params = campaignId ? [campaignId, tenantId] : [tenantId];
    return this.dataSource.query(query, params);
  }

  // ── Performance Auto-Optimizer ─────────────────────────────────────────────
  async runPerformanceOptimizer(tenantId: string) {
    const campaigns = await this.campaignsRepo.find({
      where: { tenantId, status: 'active' },
    });

    let optimized = 0;

    for (const campaign of campaigns) {
      const posts = await this.postsRepo.find({
        where: { campaignId: campaign.id },
      });

      for (const post of posts) {
        const impressions = post.impressions || 0;
        if (impressions < 2000) continue;

        const ctr = (post.clicks || 0) / impressions;
        const roas = parseFloat(post.roas as any) || 0;

        // Check break-even ROAS
        const product = await this.dataSource.query(
          'SELECT base_price, cost_price FROM products WHERE id = $1',
          [campaign.productId],
        );
        const p = product[0];
        const breakEvenRoas = p
          ? parseFloat(p.base_price) / (parseFloat(p.base_price) - parseFloat(p.cost_price))
          : 1.5;

        if (roas > 0 && roas < breakEvenRoas) {
          // Pause this post
          await this.postsRepo.update(post.id, { status: 'paused' });
          this.logger.log(`Paused ${post.platform} post ${post.id} — ROAS ${roas.toFixed(2)}x below break-even ${breakEvenRoas.toFixed(2)}x`);
          optimized++;
        } else if (ctr < 0.004 && impressions > 5000) {
          // Creative fatigue — generate fresh creatives
          await this.standardQueue.add('regenerate_creative', {
            tenantId,
            campaignId: campaign.id,
            postId: post.id,
            platform: post.platform,
            reason: 'creative_fatigue',
          });
        }
      }
    }

    return { optimized };
  }

  // ── Viral Score Calculator ─────────────────────────────────────────────────
  async calculateViralScore(product: any, platform: SocialPlatform): Promise<number> {
    // Weighted scoring based on product and platform characteristics
    const scores = {
      aiScore: (parseFloat(product.ai_score) || 50) / 100,
      pricePoint: this.scorePricePoint(parseFloat(product.base_price), platform),
      impulse: this.scoreImpulseFactor(product.name, product.category),
      visual: platform === 'tiktok' ? 0.8 : 0.7,  // simplified
    };

    const weights = platform === 'tiktok'
      ? { aiScore: 0.3, pricePoint: 0.25, impulse: 0.3, visual: 0.15 }
      : platform === 'instagram'
      ? { aiScore: 0.25, pricePoint: 0.2, impulse: 0.25, visual: 0.3 }
      : { aiScore: 0.3, pricePoint: 0.3, impulse: 0.3, visual: 0.1 };

    const raw = Object.entries(scores).reduce(
      (sum, [key, val]) => sum + val * (weights as any)[key], 0,
    );
    return Math.round(raw * 100);
  }

  private scorePricePoint(price: number, platform: SocialPlatform): number {
    // Sweet spots: TikTok $10-50, Instagram $20-150, Facebook $15-200
    if (platform === 'tiktok') return price >= 10 && price <= 50 ? 1.0 : price <= 100 ? 0.6 : 0.3;
    if (platform === 'instagram') return price >= 20 && price <= 150 ? 1.0 : price <= 200 ? 0.7 : 0.4;
    return price >= 15 && price <= 200 ? 1.0 : 0.6;
  }

  private scoreImpulseFactor(name: string, category: string): number {
    const highImpulse = ['wireless', 'led', 'portable', 'mini', 'smart', 'magnetic', 'gadget', 'tool'];
    const score = highImpulse.filter((kw) =>
      name?.toLowerCase().includes(kw) || category?.toLowerCase().includes(kw),
    ).length;
    return Math.min(score * 0.2 + 0.4, 1.0);
  }

  // ── Platform Publishers ────────────────────────────────────────────────────
  private async publishTikTokAd(
    account: SocialAccount, campaign: SocialCampaign, creative: any, budget: number,
  ): Promise<string> {
    // TikTok Ads Manager API - create ad group and ad
    try {
      const response = await axios.post(
        `${this.PLATFORM_URLS.tiktok}/ad/create/`,
        {
          advertiser_id: account.accountId,
          adgroup_id: campaign.externalIds?.['tiktok_adgroup'],
          creatives: [{
            ad_name: creative?.headline || campaign.name,
            ad_text: creative?.caption || campaign.name,
            call_to_action: creative?.cta || 'SHOP_NOW',
          }],
        },
        { headers: { 'Access-Token': account.accessToken, 'Content-Type': 'application/json' } },
      );
      return response.data?.data?.ad_id || `tiktok_mock_${Date.now()}`;
    } catch (e) {
      this.logger.warn(`TikTok publish error: ${e.message}`);
      return `tiktok_draft_${Date.now()}`; // Fallback for development
    }
  }

  private async publishInstagramAd(
    account: SocialAccount, campaign: SocialCampaign, creative: any, budget: number,
  ): Promise<string> {
    try {
      const response = await axios.post(
        `${this.PLATFORM_URLS.instagram}/act_${account.accountId}/ads`,
        {
          name: creative?.headline || campaign.name,
          adset_id: campaign.externalIds?.['instagram_adset'],
          creative: {
            creative_id: campaign.externalIds?.['instagram_creative'],
          },
          status: 'ACTIVE',
        },
        { params: { access_token: account.accessToken } },
      );
      return response.data?.id || `ig_mock_${Date.now()}`;
    } catch (e) {
      this.logger.warn(`Instagram publish error: ${e.message}`);
      return `ig_draft_${Date.now()}`;
    }
  }

  private async publishFacebookAd(
    account: SocialAccount, campaign: SocialCampaign, creative: any, budget: number,
  ): Promise<string> {
    try {
      const response = await axios.post(
        `${this.PLATFORM_URLS.facebook}/act_${account.accountId}/ads`,
        {
          name: creative?.headline || campaign.name,
          adset_id: campaign.externalIds?.['facebook_adset'],
          creative: { creative_id: campaign.externalIds?.['facebook_creative'] },
          status: 'ACTIVE',
        },
        { params: { access_token: account.accessToken } },
      );
      return response.data?.id || `fb_mock_${Date.now()}`;
    } catch (e) {
      this.logger.warn(`Facebook publish error: ${e.message}`);
      return `fb_draft_${Date.now()}`;
    }
  }

  // ── Budget Split Calculator ────────────────────────────────────────────────
  private async calculateBudgetSplit(
    tenantId: string,
    platforms: SocialPlatform[],
    totalBudget: number,
    product: any,
  ): Promise<Record<string, number>> {
    // Get historical ROAS per platform for this tenant
    const historicalRoas = await this.dataSource.query(
      `SELECT platform, AVG(roas) as avg_roas
       FROM social_posts sp
       JOIN social_campaigns sc ON sc.id = sp.campaign_id
       WHERE sc.tenant_id = $1 AND sp.roas > 0
       GROUP BY platform`,
      [tenantId],
    );

    const roasMap: Record<string, number> = {};
    historicalRoas.forEach((r: any) => { roasMap[r.platform] = parseFloat(r.avg_roas); });

    // Default ROAS weights if no history
    const defaults: Record<string, number> = {
      tiktok: 3.0,
      instagram: 2.5,
      facebook: 2.8,
    };

    const weights: Record<string, number> = {};
    let totalWeight = 0;

    for (const p of platforms) {
      weights[p] = roasMap[p] || defaults[p] || 2.0;
      totalWeight += weights[p];
    }

    const split: Record<string, number> = {};
    for (const p of platforms) {
      split[p] = Math.round((weights[p] / totalWeight) * totalBudget * 100) / 100;
    }

    return split;
  }

  // ── Disconnect Account ─────────────────────────────────────────────────────
  async disconnectAccount(tenantId: string, platform: SocialPlatform) {
    await this.accountsRepo.update({ tenantId, platform }, { isActive: false });
    return { success: true };
  }

  // ── Get Campaigns ──────────────────────────────────────────────────────────
  async getCampaigns(tenantId: string, filters: any = {}) {
    const { page = 1, limit = 20, status, platform } = filters;
    const qb = this.campaignsRepo.createQueryBuilder('c')
      .where('c.tenantId = :tenantId', { tenantId })
      .orderBy('c.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    if (status) qb.andWhere('c.status = :status', { status });
    const [data, total] = await qb.getManyAndCount();
    return { data, meta: { total, page, limit } };
  }

  // ── Update Post Metrics ────────────────────────────────────────────────────
  async updatePostMetrics(postId: string, metrics: any) {
    await this.postsRepo.update(postId, metrics);
  }
}
