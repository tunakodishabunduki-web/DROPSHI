import {
  ArrayNotEmpty,
  IsArray,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  IsUUID,
  Min,
} from 'class-validator';
import { SocialPlatformEnum, SocialPlatform } from '../types/social-platform.type';

export class GenerateCreativeDto {
  @IsUUID()
  productId: string;

  @IsArray()
  @ArrayNotEmpty()
  @IsEnum(SocialPlatformEnum, { each: true })
  platforms: SocialPlatform[];

  @IsNumber()
  @IsPositive()
  dailyBudget: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  durationDays?: number;
}
