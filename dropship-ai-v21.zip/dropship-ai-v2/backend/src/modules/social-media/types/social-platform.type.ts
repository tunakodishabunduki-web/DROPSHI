export enum SocialPlatformEnum {
  TIKTOK = 'tiktok',
  INSTAGRAM = 'instagram',
  FACEBOOK = 'facebook',
}

export type SocialPlatform = (typeof SocialPlatformEnum)[keyof typeof SocialPlatformEnum];
export const SOCIAL_PLATFORMS: SocialPlatform[] = Object.values(SocialPlatformEnum);
