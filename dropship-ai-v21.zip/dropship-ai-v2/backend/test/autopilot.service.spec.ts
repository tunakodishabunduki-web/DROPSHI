import { AutopilotService } from '../src/modules/autopilot/autopilot.service';
import { AutopilotConfig } from '../src/modules/autopilot/entities/autopilot-config.entity';

describe('AutopilotService', () => {
  let service: AutopilotService;
  const repoMock = () => ({
    upsert: jest.fn(),
    update: jest.fn(),
    findOne: jest.fn().mockResolvedValue(null),
    save: jest.fn(),
    createQueryBuilder: jest.fn().mockReturnValue({
      where: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      skip: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      getManyAndCount: jest.fn().mockResolvedValue([[], 0]),
    }),
  });
  const queueMock = { add: jest.fn() } as any;
  const cacheMock = { get: jest.fn(), set: jest.fn(), del: jest.fn() } as any;
  const dataSourceMock = { query: jest.fn().mockResolvedValue([]) } as any;
  const configMock = { get: jest.fn().mockReturnValue('') } as any;
  const eventsMock = { emit: jest.fn() } as any;

  beforeEach(() => {
    service = new AutopilotService(
      repoMock() as any,
      repoMock() as any,
      queueMock,
      queueMock,
      cacheMock,
      dataSourceMock,
      configMock,
      eventsMock,
    );
    service['openai'] = { chat: { completions: { create: jest.fn().mockResolvedValue({ choices: [{ message: { content: 'nope' } }] }) } } } as any;
  });

  it('gracefully falls back when AI response is invalid', async () => {
    const cfg = new AutopilotConfig();
    cfg.maxPriceIncreasePercent = 15;
    const product = { name: 'Test', cost_price: 12, base_price: 15, ai_score: 60 };

    const result = await (service as any).aiCalculatePrice(product, 14, 15, cfg);

    expect(result.price).toBeGreaterThanOrEqual(15);
    expect(result.reasoning).toContain('Fallback');
  });
});
