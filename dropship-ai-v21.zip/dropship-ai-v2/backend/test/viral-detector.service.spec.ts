import { ViralDetectorService } from '../src/modules/viral-detector/viral-detector.service';
import { Cache } from 'cache-manager';
import { Queue } from 'bull';

describe('ViralDetectorService', () => {
  let service: ViralDetectorService;
  const queueMock = { add: jest.fn() } as unknown as Queue;
  const cacheMock = { get: jest.fn().mockResolvedValue(null), set: jest.fn() } as Cache;
  const dataSourceMock = { query: jest.fn().mockResolvedValue([]) } as any;
  const configMock = { get: jest.fn() } as any;

  beforeEach(() => {
    service = new ViralDetectorService(dataSourceMock, queueMock, cacheMock, configMock);
    (service as any).scoreKeyword = jest.fn().mockResolvedValue({
      keyword: 'test',
      overallScore: 80,
      tiktokScore: 70,
      googleTrendsScore: 60,
      socialProofScore: 50,
      impulseScore: 40,
      signals: [],
      predictedPeakDays: 7,
      recommendation: 'import_now',
      estimatedRevenue: 1024,
    });
  });

  it('returns baseline score when no signals are available', () => {
    const score = (service as any).calculateSignalScore([]);
    expect(score).toBe(30);
  });

  it('analyzeViralPotential uses scoreKeyword and returns structured data', async () => {
    const results = await service.analyzeViralPotential(['test']);
    expect(results).toHaveLength(1);
    expect(results[0].keyword).toBe('test');
  });
});
