import { SocialMediaController } from '../src/modules/social-media/social-media.controller';
import { GenerateCreativeDto } from '../src/modules/social-media/dto/generate-creative.dto';
import { SocialPlatformEnum } from '../src/modules/social-media/types/social-platform.type';

describe('SocialMediaController', () => {
  it('delegates creative generation to the service', async () => {
    const mockService = {
      generateCreativesPreview: jest.fn().mockResolvedValue({ productId: 'xyz' }),
    } as any;
    const controller = new SocialMediaController(mockService);
    const dto: GenerateCreativeDto = {
      productId: 'product-1',
      platforms: [SocialPlatformEnum.TIKTOK],
      dailyBudget: 20,
    };

    const result = await controller.generateCreative(dto, 'tenant-a');

    expect(mockService.generateCreativesPreview).toHaveBeenCalledWith('tenant-a', dto);
    expect(result).toHaveProperty('productId', 'xyz');
  });
});
