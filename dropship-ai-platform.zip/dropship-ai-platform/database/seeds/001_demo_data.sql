-- ─── Seed Data for Development ───────────────────────────────────────────────

-- Demo tenant
INSERT INTO tenants (id, name, slug, plan, currency, settings) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Demo Store', 'demo', 'pro', 'USD',
   '{"theme": "default", "features": ["ai_pricing", "ai_marketing", "ai_support"], "timezone": "UTC"}')
ON CONFLICT (slug) DO NOTHING;

-- Admin user (password: Admin@1234)
INSERT INTO users (tenant_id, email, password_hash, first_name, last_name, role, status, email_verified) VALUES
  ('00000000-0000-0000-0000-000000000001',
   'admin@demo.com',
   '$argon2id$v=19$m=65536,t=3,p=4$randomsalt$hashedpassword',
   'Admin', 'User', 'tenant_admin', 'active', true)
ON CONFLICT (tenant_id, email) DO NOTHING;

-- Demo categories
INSERT INTO categories (tenant_id, name, slug, is_active) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Electronics', 'electronics', true),
  ('00000000-0000-0000-0000-000000000001', 'Home & Garden', 'home-garden', true),
  ('00000000-0000-0000-0000-000000000001', 'Fashion', 'fashion', true),
  ('00000000-0000-0000-0000-000000000001', 'Health & Beauty', 'health-beauty', true),
  ('00000000-0000-0000-0000-000000000001', 'Sports & Outdoors', 'sports-outdoors', true),
  ('00000000-0000-0000-0000-000000000001', 'Toys & Games', 'toys-games', true)
ON CONFLICT (tenant_id, slug) DO NOTHING;

-- Demo supplier
INSERT INTO suppliers (tenant_id, name, slug, api_type, status, reliability_score, is_primary) VALUES
  ('00000000-0000-0000-0000-000000000001', 'AliExpress Demo', 'aliexpress-demo', 'aliexpress', 'active', 0.92, true)
ON CONFLICT (tenant_id, slug) DO NOTHING;

-- Demo products
WITH sup AS (SELECT id FROM suppliers WHERE slug = 'aliexpress-demo' LIMIT 1),
     cat_elec AS (SELECT id FROM categories WHERE slug = 'electronics' AND tenant_id = '00000000-0000-0000-0000-000000000001' LIMIT 1),
     cat_home AS (SELECT id FROM categories WHERE slug = 'home-garden' AND tenant_id = '00000000-0000-0000-0000-000000000001' LIMIT 1)
INSERT INTO products (tenant_id, supplier_id, category_id, sku, name, slug, short_description, cost_price, base_price, stock_quantity, status, ai_score, images, tags)
SELECT
  '00000000-0000-0000-0000-000000000001',
  sup.id,
  CASE WHEN p.cat = 'elec' THEN cat_elec.id ELSE cat_home.id END,
  p.sku, p.name, p.slug, p.desc,
  p.cost, p.price, p.stock, 'active'::product_status, p.ai_score,
  ARRAY[p.img], ARRAY['trending', 'bestseller']
FROM (VALUES
  ('SKU-001', 'Wireless Earbuds Pro X', 'wireless-earbuds-pro-x', 'Premium noise-cancelling wireless earbuds', 12.50, 49.99, 150, 87.5, 'https://picsum.photos/seed/earbuds/400/400', 'elec'),
  ('SKU-002', 'LED Strip Lights 5m RGB', 'led-strip-lights-5m', 'Smart LED strip with app control', 5.20, 24.99, 280, 82.0, 'https://picsum.photos/seed/led/400/400', 'home'),
  ('SKU-003', 'Portable Blender USB', 'portable-blender-usb', 'Mini blender for smoothies on the go', 8.90, 34.99, 95, 78.5, 'https://picsum.photos/seed/blender/400/400', 'home'),
  ('SKU-004', 'Phone Stand Adjustable', 'phone-stand-adjustable', 'Universal desktop phone stand', 2.10, 14.99, 320, 71.0, 'https://picsum.photos/seed/stand/400/400', 'elec'),
  ('SKU-005', 'Resistance Bands Set 5pc', 'resistance-bands-set', 'Professional workout resistance bands', 6.50, 29.99, 180, 89.0, 'https://picsum.photos/seed/bands/400/400', 'home'),
  ('SKU-006', 'Smart Watch Fitness Tracker', 'smart-watch-fitness', 'Health monitoring smartwatch', 18.00, 79.99, 75, 92.0, 'https://picsum.photos/seed/watch/400/400', 'elec'),
  ('SKU-007', 'Collapsible Water Bottle', 'collapsible-water-bottle', 'BPA-free foldable bottle 750ml', 3.80, 19.99, 210, 66.5, 'https://picsum.photos/seed/bottle/400/400', 'home'),
  ('SKU-008', 'Car Phone Mount Magnetic', 'car-phone-mount-magnetic', 'Strong magnetic car holder', 3.50, 17.99, 160, 73.0, 'https://picsum.photos/seed/carmount/400/400', 'elec')
) AS p(sku, name, slug, desc, cost, price, stock, ai_score, img, cat)
CROSS JOIN sup
CROSS JOIN cat_elec
CROSS JOIN cat_home
ON CONFLICT (tenant_id, sku) DO NOTHING;
