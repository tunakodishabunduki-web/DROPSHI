-- ─────────────────────────────────────────────────────────────────────────
-- DropShip AI Platform — Initial Schema Migration
-- Version: 001
-- ─────────────────────────────────────────────────────────────────────────

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────────
-- ENUMS
-- ─────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('super_admin', 'tenant_admin', 'manager', 'staff', 'customer');
CREATE TYPE user_status AS ENUM ('active', 'inactive', 'suspended', 'pending_verification');
CREATE TYPE plan_type AS ENUM ('free', 'starter', 'pro', 'enterprise');
CREATE TYPE order_status AS ENUM (
  'pending', 'confirmed', 'processing', 'shipped', 'delivered',
  'cancelled', 'refunded', 'partially_refunded', 'disputed'
);
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');
CREATE TYPE payment_provider AS ENUM ('stripe', 'paypal', 'mpesa', 'bank_transfer', 'crypto');
CREATE TYPE product_status AS ENUM ('active', 'inactive', 'draft', 'out_of_stock', 'discontinued');
CREATE TYPE supplier_status AS ENUM ('active', 'inactive', 'suspended', 'pending_review');
CREATE TYPE ai_task_status AS ENUM ('queued', 'processing', 'completed', 'failed', 'cancelled');
CREATE TYPE ad_platform AS ENUM ('tiktok', 'instagram', 'facebook', 'google', 'twitter', 'snapchat');
CREATE TYPE ad_status AS ENUM ('draft', 'active', 'paused', 'completed', 'rejected');
CREATE TYPE ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'closed', 'escalated');
CREATE TYPE ticket_priority AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE currency_code AS ENUM ('USD', 'EUR', 'GBP', 'TZS', 'KES', 'NGN', 'ZAR');

-- ─────────────────────────────────────────────
-- TENANTS (Multi-tenant support)
-- ─────────────────────────────────────────────
CREATE TABLE tenants (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            VARCHAR(255) NOT NULL,
  slug            VARCHAR(100) NOT NULL UNIQUE,
  plan            plan_type NOT NULL DEFAULT 'free',
  domain          VARCHAR(255),
  logo_url        TEXT,
  primary_color   VARCHAR(7) DEFAULT '#6366f1',
  currency        currency_code NOT NULL DEFAULT 'USD',
  timezone        VARCHAR(50) NOT NULL DEFAULT 'UTC',
  locale          VARCHAR(10) NOT NULL DEFAULT 'en',
  settings        JSONB NOT NULL DEFAULT '{}',
  is_active       BOOLEAN NOT NULL DEFAULT true,
  trial_ends_at   TIMESTAMPTZ,
  plan_expires_at TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_tenants_slug ON tenants(slug);
CREATE INDEX idx_tenants_plan ON tenants(plan);

-- ─────────────────────────────────────────────
-- USERS
-- ─────────────────────────────────────────────
CREATE TABLE users (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id             UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email                 VARCHAR(255) NOT NULL,
  password_hash         TEXT,
  first_name            VARCHAR(100) NOT NULL,
  last_name             VARCHAR(100) NOT NULL,
  avatar_url            TEXT,
  phone                 VARCHAR(30),
  role                  user_role NOT NULL DEFAULT 'customer',
  status                user_status NOT NULL DEFAULT 'pending_verification',
  email_verified        BOOLEAN NOT NULL DEFAULT false,
  email_verified_at     TIMESTAMPTZ,
  two_factor_enabled    BOOLEAN NOT NULL DEFAULT false,
  two_factor_secret     TEXT,
  oauth_provider        VARCHAR(50),
  oauth_provider_id     VARCHAR(255),
  preferences           JSONB NOT NULL DEFAULT '{}',
  last_login_at         TIMESTAMPTZ,
  last_login_ip         INET,
  failed_login_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until          TIMESTAMPTZ,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at            TIMESTAMPTZ,
  UNIQUE (tenant_id, email)
);
CREATE INDEX idx_users_tenant ON users(tenant_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(tenant_id, role);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_deleted ON users(deleted_at) WHERE deleted_at IS NULL;

-- ─────────────────────────────────────────────
-- REFRESH TOKENS
-- ─────────────────────────────────────────────
CREATE TABLE refresh_tokens (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  family     UUID NOT NULL DEFAULT uuid_generate_v4(),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked    BOOLEAN NOT NULL DEFAULT false,
  user_agent TEXT,
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_expires ON refresh_tokens(expires_at);

-- ─────────────────────────────────────────────
-- SUPPLIERS
-- ─────────────────────────────────────────────
CREATE TABLE suppliers (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id         UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name              VARCHAR(255) NOT NULL,
  slug              VARCHAR(100) NOT NULL,
  description       TEXT,
  logo_url          TEXT,
  website           VARCHAR(500),
  api_type          VARCHAR(50) NOT NULL,  -- aliexpress, shopify, amazon, custom
  api_credentials   JSONB,               -- encrypted at app level
  contact_email     VARCHAR(255),
  contact_phone     VARCHAR(30),
  country           VARCHAR(100),
  status            supplier_status NOT NULL DEFAULT 'pending_review',
  reliability_score NUMERIC(3,2) DEFAULT 0.00,
  avg_ship_days     INTEGER,
  fulfillment_rate  NUMERIC(5,2),
  is_primary        BOOLEAN NOT NULL DEFAULT false,
  failover_supplier_id UUID REFERENCES suppliers(id),
  sync_frequency    INTEGER NOT NULL DEFAULT 60, -- minutes
  last_synced_at    TIMESTAMPTZ,
  metadata          JSONB NOT NULL DEFAULT '{}',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, slug)
);
CREATE INDEX idx_suppliers_tenant ON suppliers(tenant_id);
CREATE INDEX idx_suppliers_status ON suppliers(tenant_id, status);

-- ─────────────────────────────────────────────
-- CATEGORIES
-- ─────────────────────────────────────────────
CREATE TABLE categories (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  parent_id   UUID REFERENCES categories(id),
  name        VARCHAR(255) NOT NULL,
  slug        VARCHAR(255) NOT NULL,
  description TEXT,
  image_url   TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  is_active   BOOLEAN NOT NULL DEFAULT true,
  metadata    JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, slug)
);
CREATE INDEX idx_categories_tenant ON categories(tenant_id);
CREATE INDEX idx_categories_parent ON categories(parent_id);

-- ─────────────────────────────────────────────
-- PRODUCTS
-- ─────────────────────────────────────────────
CREATE TABLE products (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id            UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  supplier_id          UUID REFERENCES suppliers(id),
  category_id          UUID REFERENCES categories(id),
  sku                  VARCHAR(100) NOT NULL,
  supplier_sku         VARCHAR(100),
  name                 VARCHAR(500) NOT NULL,
  slug                 VARCHAR(500) NOT NULL,
  description          TEXT,
  short_description    VARCHAR(500),
  images               JSONB NOT NULL DEFAULT '[]',
  tags                 TEXT[] DEFAULT '{}',
  status               product_status NOT NULL DEFAULT 'draft',
  -- Pricing
  cost_price           NUMERIC(10,2) NOT NULL DEFAULT 0,
  base_price           NUMERIC(10,2) NOT NULL DEFAULT 0,
  sale_price           NUMERIC(10,2),
  currency             currency_code NOT NULL DEFAULT 'USD',
  -- Inventory
  stock_quantity       INTEGER NOT NULL DEFAULT 0,
  stock_reserved       INTEGER NOT NULL DEFAULT 0,
  low_stock_threshold  INTEGER NOT NULL DEFAULT 10,
  track_inventory      BOOLEAN NOT NULL DEFAULT true,
  -- Shipping
  weight               NUMERIC(8,2),
  weight_unit          VARCHAR(5) DEFAULT 'kg',
  dimensions           JSONB,            -- {length, width, height, unit}
  shipping_class       VARCHAR(50),
  -- AI
  ai_score             NUMERIC(5,2),     -- trend score from AI
  ai_tags              TEXT[] DEFAULT '{}',
  ai_last_analyzed_at  TIMESTAMPTZ,
  -- SEO
  seo_title            VARCHAR(255),
  seo_description      VARCHAR(500),
  seo_keywords         TEXT[],
  -- Supplier data
  supplier_url         TEXT,
  supplier_data        JSONB NOT NULL DEFAULT '{}',
  -- Metadata
  attributes           JSONB NOT NULL DEFAULT '{}',
  variants_enabled     BOOLEAN NOT NULL DEFAULT false,
  metadata             JSONB NOT NULL DEFAULT '{}',
  view_count           INTEGER NOT NULL DEFAULT 0,
  sales_count          INTEGER NOT NULL DEFAULT 0,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at           TIMESTAMPTZ,
  UNIQUE (tenant_id, sku)
);
CREATE INDEX idx_products_tenant ON products(tenant_id);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_supplier ON products(supplier_id);
CREATE INDEX idx_products_status ON products(tenant_id, status);
CREATE INDEX idx_products_ai_score ON products(tenant_id, ai_score DESC);
CREATE INDEX idx_products_search ON products USING gin(to_tsvector('english', name || ' ' || COALESCE(description, '')));
CREATE INDEX idx_products_tags ON products USING gin(tags);
CREATE INDEX idx_products_deleted ON products(deleted_at) WHERE deleted_at IS NULL;

-- ─────────────────────────────────────────────
-- PRODUCT VARIANTS
-- ─────────────────────────────────────────────
CREATE TABLE product_variants (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id     UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  tenant_id      UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  sku            VARCHAR(100) NOT NULL,
  name           VARCHAR(255) NOT NULL,
  attributes     JSONB NOT NULL DEFAULT '{}',  -- {color: "red", size: "XL"}
  price          NUMERIC(10,2) NOT NULL,
  cost_price     NUMERIC(10,2) NOT NULL DEFAULT 0,
  stock_quantity INTEGER NOT NULL DEFAULT 0,
  image_url      TEXT,
  is_active      BOOLEAN NOT NULL DEFAULT true,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, sku)
);
CREATE INDEX idx_variants_product ON product_variants(product_id);
CREATE INDEX idx_variants_tenant ON product_variants(tenant_id);

-- ─────────────────────────────────────────────
-- PRICING HISTORY (AI Dynamic Pricing)
-- ─────────────────────────────────────────────
CREATE TABLE pricing_history (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id     UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  tenant_id      UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  old_price      NUMERIC(10,2) NOT NULL,
  new_price      NUMERIC(10,2) NOT NULL,
  strategy       VARCHAR(50) NOT NULL,  -- competitor, demand, cost_plus, ai
  change_reason  TEXT,
  ai_confidence  NUMERIC(3,2),
  competitor_data JSONB,
  simulated      BOOLEAN NOT NULL DEFAULT false,
  applied_by     UUID REFERENCES users(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);
CREATE TABLE pricing_history_2024 PARTITION OF pricing_history
  FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');
CREATE TABLE pricing_history_2025 PARTITION OF pricing_history
  FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE pricing_history_2026 PARTITION OF pricing_history
  FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE INDEX idx_pricing_history_product ON pricing_history(product_id, created_at DESC);

-- ─────────────────────────────────────────────
-- CUSTOMERS
-- ─────────────────────────────────────────────
CREATE TABLE customers (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id          UUID REFERENCES users(id),
  email            VARCHAR(255) NOT NULL,
  first_name       VARCHAR(100),
  last_name        VARCHAR(100),
  phone            VARCHAR(30),
  date_of_birth    DATE,
  gender           VARCHAR(20),
  total_spent      NUMERIC(12,2) NOT NULL DEFAULT 0,
  order_count      INTEGER NOT NULL DEFAULT 0,
  avg_order_value  NUMERIC(10,2) NOT NULL DEFAULT 0,
  last_ordered_at  TIMESTAMPTZ,
  tags             TEXT[] DEFAULT '{}',
  notes            TEXT,
  metadata         JSONB NOT NULL DEFAULT '{}',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, email)
);
CREATE INDEX idx_customers_tenant ON customers(tenant_id);
CREATE INDEX idx_customers_email ON customers(tenant_id, email);
CREATE INDEX idx_customers_user ON customers(user_id);

-- ─────────────────────────────────────────────
-- ADDRESSES
-- ─────────────────────────────────────────────
CREATE TABLE addresses (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id  UUID REFERENCES customers(id) ON DELETE CASCADE,
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  tenant_id    UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  label        VARCHAR(50) DEFAULT 'home',
  first_name   VARCHAR(100) NOT NULL,
  last_name    VARCHAR(100) NOT NULL,
  company      VARCHAR(255),
  address1     VARCHAR(500) NOT NULL,
  address2     VARCHAR(500),
  city         VARCHAR(100) NOT NULL,
  state        VARCHAR(100),
  postal_code  VARCHAR(20),
  country      VARCHAR(100) NOT NULL,
  country_code VARCHAR(2) NOT NULL,
  phone        VARCHAR(30),
  is_default   BOOLEAN NOT NULL DEFAULT false,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_addresses_customer ON addresses(customer_id);
CREATE INDEX idx_addresses_user ON addresses(user_id);

-- ─────────────────────────────────────────────
-- ORDERS (Partitioned)
-- ─────────────────────────────────────────────
CREATE TABLE orders (
  id                 UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id          UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  customer_id        UUID REFERENCES customers(id),
  order_number       VARCHAR(50) NOT NULL,
  status             order_status NOT NULL DEFAULT 'pending',
  payment_status     payment_status NOT NULL DEFAULT 'pending',
  -- Pricing
  subtotal           NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount_total     NUMERIC(12,2) NOT NULL DEFAULT 0,
  shipping_total     NUMERIC(12,2) NOT NULL DEFAULT 0,
  tax_total          NUMERIC(12,2) NOT NULL DEFAULT 0,
  total              NUMERIC(12,2) NOT NULL DEFAULT 0,
  currency           currency_code NOT NULL DEFAULT 'USD',
  -- Addresses
  billing_address    JSONB NOT NULL DEFAULT '{}',
  shipping_address   JSONB NOT NULL DEFAULT '{}',
  -- Fulfillment
  supplier_id        UUID REFERENCES suppliers(id),
  tracking_number    VARCHAR(255),
  tracking_url       TEXT,
  carrier            VARCHAR(100),
  shipped_at         TIMESTAMPTZ,
  delivered_at       TIMESTAMPTZ,
  estimated_delivery TIMESTAMPTZ,
  -- Cancellation / refund
  cancelled_at       TIMESTAMPTZ,
  cancellation_reason TEXT,
  refunded_at        TIMESTAMPTZ,
  refund_amount      NUMERIC(12,2),
  -- Notes
  customer_note      TEXT,
  internal_note      TEXT,
  tags               TEXT[] DEFAULT '{}',
  metadata           JSONB NOT NULL DEFAULT '{}',
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);
CREATE TABLE orders_2024 PARTITION OF orders FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');
CREATE TABLE orders_2025 PARTITION OF orders FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE orders_2026 PARTITION OF orders FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

CREATE UNIQUE INDEX idx_orders_number ON orders(tenant_id, order_number, created_at);
CREATE INDEX idx_orders_tenant ON orders(tenant_id, created_at DESC);
CREATE INDEX idx_orders_customer ON orders(customer_id, created_at DESC);
CREATE INDEX idx_orders_status ON orders(tenant_id, status, created_at DESC);
CREATE INDEX idx_orders_payment_status ON orders(tenant_id, payment_status);

-- ─────────────────────────────────────────────
-- ORDER ITEMS
-- ─────────────────────────────────────────────
CREATE TABLE order_items (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id         UUID NOT NULL,
  order_created_at TIMESTAMPTZ NOT NULL,
  tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  product_id       UUID REFERENCES products(id),
  variant_id       UUID REFERENCES product_variants(id),
  supplier_id      UUID REFERENCES suppliers(id),
  product_name     VARCHAR(500) NOT NULL,
  product_image    TEXT,
  sku              VARCHAR(100),
  quantity         INTEGER NOT NULL DEFAULT 1,
  unit_price       NUMERIC(10,2) NOT NULL,
  cost_price       NUMERIC(10,2) NOT NULL DEFAULT 0,
  discount         NUMERIC(10,2) NOT NULL DEFAULT 0,
  tax              NUMERIC(10,2) NOT NULL DEFAULT 0,
  total            NUMERIC(10,2) NOT NULL,
  fulfillment_status VARCHAR(50) DEFAULT 'pending',
  metadata         JSONB NOT NULL DEFAULT '{}',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  FOREIGN KEY (order_id, order_created_at) REFERENCES orders(id, created_at)
);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);
CREATE INDEX idx_order_items_tenant ON order_items(tenant_id);

-- ─────────────────────────────────────────────
-- PAYMENTS
-- ─────────────────────────────────────────────
CREATE TABLE payments (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id          UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  order_id           UUID NOT NULL,
  order_created_at   TIMESTAMPTZ NOT NULL,
  provider           payment_provider NOT NULL,
  provider_payment_id VARCHAR(255),
  provider_charge_id  VARCHAR(255),
  status             payment_status NOT NULL DEFAULT 'pending',
  amount             NUMERIC(12,2) NOT NULL,
  currency           currency_code NOT NULL DEFAULT 'USD',
  amount_usd         NUMERIC(12,2),
  exchange_rate      NUMERIC(10,6) DEFAULT 1.0,
  metadata           JSONB NOT NULL DEFAULT '{}',
  provider_response  JSONB,
  failed_reason      TEXT,
  refunded_amount    NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  FOREIGN KEY (order_id, order_created_at) REFERENCES orders(id, created_at)
);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_payments_tenant ON payments(tenant_id, created_at DESC);
CREATE INDEX idx_payments_provider ON payments(provider, provider_payment_id);

-- ─────────────────────────────────────────────
-- TRENDS (Product Research AI)
-- ─────────────────────────────────────────────
CREATE TABLE trends (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id     UUID REFERENCES tenants(id) ON DELETE SET NULL,
  product_id    UUID REFERENCES products(id) ON DELETE SET NULL,
  keyword       VARCHAR(255) NOT NULL,
  platform      VARCHAR(100) NOT NULL,  -- tiktok, instagram, amazon, aliexpress, google
  score         NUMERIC(5,2) NOT NULL,
  search_volume BIGINT,
  growth_rate   NUMERIC(6,2),
  sentiment     NUMERIC(3,2),            -- -1 to 1
  category      VARCHAR(100),
  data_snapshot JSONB NOT NULL DEFAULT '{}',
  recorded_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (recorded_at);
CREATE TABLE trends_2025 PARTITION OF trends FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE trends_2026 PARTITION OF trends FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE INDEX idx_trends_keyword ON trends(keyword, recorded_at DESC);
CREATE INDEX idx_trends_product ON trends(product_id, recorded_at DESC);
CREATE INDEX idx_trends_score ON trends(tenant_id, score DESC, recorded_at DESC);

-- ─────────────────────────────────────────────
-- ADS (Marketing AI)
-- ─────────────────────────────────────────────
CREATE TABLE ads (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  product_id      UUID REFERENCES products(id),
  campaign_name   VARCHAR(255) NOT NULL,
  platform        ad_platform NOT NULL,
  status          ad_status NOT NULL DEFAULT 'draft',
  ad_type         VARCHAR(50) NOT NULL,  -- image, video, carousel, story
  headline        VARCHAR(255),
  body_copy       TEXT,
  cta             VARCHAR(100),
  media_urls      JSONB NOT NULL DEFAULT '[]',
  target_audience JSONB NOT NULL DEFAULT '{}',
  budget          NUMERIC(10,2),
  spent           NUMERIC(10,2) NOT NULL DEFAULT 0,
  -- Metrics
  impressions     BIGINT NOT NULL DEFAULT 0,
  clicks          BIGINT NOT NULL DEFAULT 0,
  conversions     BIGINT NOT NULL DEFAULT 0,
  ctr             NUMERIC(6,4) GENERATED ALWAYS AS (
                    CASE WHEN impressions > 0 THEN (clicks::NUMERIC / impressions) ELSE 0 END
                  ) STORED,
  roas            NUMERIC(8,2),
  -- AI
  ai_generated    BOOLEAN NOT NULL DEFAULT false,
  ab_test_id      UUID,
  ab_variant      VARCHAR(10),
  ai_score        NUMERIC(5,2),
  -- Dates
  starts_at       TIMESTAMPTZ,
  ends_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ads_tenant ON ads(tenant_id, created_at DESC);
CREATE INDEX idx_ads_product ON ads(product_id);
CREATE INDEX idx_ads_platform ON ads(tenant_id, platform, status);

-- ─────────────────────────────────────────────
-- AI LOGS
-- ─────────────────────────────────────────────
CREATE TABLE ai_logs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE SET NULL,
  module          VARCHAR(100) NOT NULL,  -- product_research, pricing, marketing, support, supplier_sync
  task_type       VARCHAR(100) NOT NULL,
  status          ai_task_status NOT NULL DEFAULT 'queued',
  input_data      JSONB,
  output_data     JSONB,
  model_used      VARCHAR(100),
  tokens_used     INTEGER,
  cost_usd        NUMERIC(8,6),
  duration_ms     INTEGER,
  error_message   TEXT,
  retry_count     INTEGER NOT NULL DEFAULT 0,
  reference_id    UUID,                  -- product_id, order_id, etc.
  reference_type  VARCHAR(50),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at    TIMESTAMPTZ
) PARTITION BY RANGE (created_at);
CREATE TABLE ai_logs_2025 PARTITION OF ai_logs FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE ai_logs_2026 PARTITION OF ai_logs FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE INDEX idx_ai_logs_tenant ON ai_logs(tenant_id, created_at DESC);
CREATE INDEX idx_ai_logs_module ON ai_logs(module, status, created_at DESC);
CREATE INDEX idx_ai_logs_reference ON ai_logs(reference_id, reference_type);

-- ─────────────────────────────────────────────
-- CUSTOMER SUPPORT TICKETS
-- ─────────────────────────────────────────────
CREATE TABLE support_tickets (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  customer_id     UUID REFERENCES customers(id),
  order_id        UUID,
  ticket_number   VARCHAR(50) NOT NULL,
  subject         VARCHAR(500) NOT NULL,
  description     TEXT,
  status          ticket_status NOT NULL DEFAULT 'open',
  priority        ticket_priority NOT NULL DEFAULT 'medium',
  assigned_to     UUID REFERENCES users(id),
  category        VARCHAR(100),
  tags            TEXT[] DEFAULT '{}',
  ai_suggested_response TEXT,
  ai_confidence   NUMERIC(3,2),
  resolved_at     TIMESTAMPTZ,
  first_response_at TIMESTAMPTZ,
  escalated_at    TIMESTAMPTZ,
  metadata        JSONB NOT NULL DEFAULT '{}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_tickets_tenant ON support_tickets(tenant_id, created_at DESC);
CREATE INDEX idx_tickets_customer ON support_tickets(customer_id);
CREATE INDEX idx_tickets_status ON support_tickets(tenant_id, status, priority);

-- ─────────────────────────────────────────────
-- TICKET MESSAGES
-- ─────────────────────────────────────────────
CREATE TABLE ticket_messages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_id   UUID NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  sender_id   UUID REFERENCES users(id),
  sender_type VARCHAR(20) NOT NULL DEFAULT 'customer',  -- customer, staff, ai
  message     TEXT NOT NULL,
  attachments JSONB NOT NULL DEFAULT '[]',
  is_internal BOOLEAN NOT NULL DEFAULT false,
  is_ai       BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ticket_messages_ticket ON ticket_messages(ticket_id, created_at);

-- ─────────────────────────────────────────────
-- AUDIT LOGS
-- ─────────────────────────────────────────────
CREATE TABLE audit_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   UUID REFERENCES tenants(id) ON DELETE SET NULL,
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id   UUID,
  old_value   JSONB,
  new_value   JSONB,
  ip_address  INET,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);
CREATE TABLE audit_logs_2025 PARTITION OF audit_logs FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE audit_logs_2026 PARTITION OF audit_logs FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE INDEX idx_audit_logs_tenant ON audit_logs(tenant_id, created_at DESC);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id, created_at DESC);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);

-- ─────────────────────────────────────────────
-- COUPONS / DISCOUNTS
-- ─────────────────────────────────────────────
CREATE TABLE coupons (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code             VARCHAR(50) NOT NULL,
  description      TEXT,
  discount_type    VARCHAR(20) NOT NULL,  -- percentage, fixed, free_shipping
  discount_value   NUMERIC(10,2) NOT NULL,
  min_order_amount NUMERIC(10,2),
  max_discount     NUMERIC(10,2),
  usage_limit      INTEGER,
  used_count       INTEGER NOT NULL DEFAULT 0,
  per_user_limit   INTEGER DEFAULT 1,
  is_active        BOOLEAN NOT NULL DEFAULT true,
  applicable_to    JSONB NOT NULL DEFAULT '{}',  -- products, categories, all
  starts_at        TIMESTAMPTZ,
  expires_at       TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, code)
);
CREATE INDEX idx_coupons_tenant ON coupons(tenant_id, is_active);
CREATE INDEX idx_coupons_code ON coupons(code);

-- ─────────────────────────────────────────────
-- ANALYTICS SNAPSHOTS (pre-aggregated)
-- ─────────────────────────────────────────────
CREATE TABLE analytics_daily (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id          UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  date               DATE NOT NULL,
  revenue            NUMERIC(14,2) NOT NULL DEFAULT 0,
  orders_count       INTEGER NOT NULL DEFAULT 0,
  avg_order_value    NUMERIC(10,2) NOT NULL DEFAULT 0,
  new_customers      INTEGER NOT NULL DEFAULT 0,
  returning_customers INTEGER NOT NULL DEFAULT 0,
  products_sold      INTEGER NOT NULL DEFAULT 0,
  refund_amount      NUMERIC(12,2) NOT NULL DEFAULT 0,
  ad_spend           NUMERIC(12,2) NOT NULL DEFAULT 0,
  ad_revenue         NUMERIC(12,2) NOT NULL DEFAULT 0,
  top_products       JSONB NOT NULL DEFAULT '[]',
  channel_breakdown  JSONB NOT NULL DEFAULT '{}',
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, date)
);
CREATE INDEX idx_analytics_daily_tenant ON analytics_daily(tenant_id, date DESC);

-- ─────────────────────────────────────────────
-- WEBHOOKS
-- ─────────────────────────────────────────────
CREATE TABLE webhooks (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id    UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name         VARCHAR(255) NOT NULL,
  url          TEXT NOT NULL,
  secret       TEXT,
  events       TEXT[] NOT NULL DEFAULT '{}',
  is_active    BOOLEAN NOT NULL DEFAULT true,
  headers      JSONB NOT NULL DEFAULT '{}',
  retry_count  INTEGER NOT NULL DEFAULT 3,
  timeout_ms   INTEGER NOT NULL DEFAULT 5000,
  last_used_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_webhooks_tenant ON webhooks(tenant_id, is_active);

-- ─────────────────────────────────────────────
-- FUNCTIONS & TRIGGERS
-- ─────────────────────────────────────────────

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_at
DO $$
DECLARE
  t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'tenants','users','products','product_variants','suppliers','categories',
    'customers','addresses','payments','ads','support_tickets','coupons',
    'analytics_daily','webhooks'
  ] LOOP
    EXECUTE format('
      CREATE TRIGGER trg_%s_updated_at
      BEFORE UPDATE ON %s
      FOR EACH ROW EXECUTE FUNCTION update_updated_at();
    ', t, t);
  END LOOP;
END;
$$;

-- Auto-generate order numbers
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.order_number IS NULL OR NEW.order_number = '' THEN
    NEW.order_number = 'ORD-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' ||
      LPAD(NEXTVAL('order_number_seq')::TEXT, 6, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE SEQUENCE IF NOT EXISTS order_number_seq START 100000;

CREATE TRIGGER trg_orders_number
  BEFORE INSERT ON orders
  FOR EACH ROW EXECUTE FUNCTION generate_order_number();

-- Update customer stats on order status change
CREATE OR REPLACE FUNCTION update_customer_stats()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'delivered' AND OLD.status != 'delivered' THEN
    UPDATE customers
    SET
      total_spent = total_spent + NEW.total,
      order_count = order_count + 1,
      avg_order_value = (total_spent + NEW.total) / (order_count + 1),
      last_ordered_at = NOW()
    WHERE id = NEW.customer_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_customer_stats
  AFTER UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_customer_stats();

-- ─────────────────────────────────────────────
-- SEED: DEFAULT TENANT
-- ─────────────────────────────────────────────
INSERT INTO tenants (name, slug, plan, currency, settings) VALUES
  ('Demo Store', 'demo', 'pro', 'USD', '{"theme": "default", "features": ["ai_pricing", "ai_marketing", "ai_support"]}');
