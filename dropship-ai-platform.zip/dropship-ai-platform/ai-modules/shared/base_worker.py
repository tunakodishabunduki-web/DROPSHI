"""Shared utilities for all AI module workers."""

import os
import json
import time
import logging
import functools
from typing import Any, Callable, Optional
from datetime import datetime

import pika
import redis
import psycopg2
from psycopg2.extras import RealDictCursor
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# ── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
    datefmt='%Y-%m-%dT%H:%M:%S',
)


# ── Config ─────────────────────────────────────────────────────────────────────
class Config:
    RABBITMQ_URL: str = os.getenv('RABBITMQ_URL', 'amqp://dropship:rabbitmq_secret@localhost:5672/dropship')
    REDIS_URL: str = os.getenv('REDIS_URL', 'redis://:redis_secret@localhost:6379')
    DATABASE_URL: str = os.getenv('DATABASE_URL', 'postgresql://dropship:dropship_secret@localhost:5432/dropship_db')
    OPENAI_API_KEY: str = os.getenv('OPENAI_API_KEY', '')
    MODULE_NAME: str = os.getenv('MODULE_NAME', 'unknown')


# ── Redis Client ───────────────────────────────────────────────────────────────
def get_redis_client() -> redis.Redis:
    return redis.from_url(Config.REDIS_URL, decode_responses=True)


# ── PostgreSQL Connection ──────────────────────────────────────────────────────
def get_db_connection():
    return psycopg2.connect(Config.DATABASE_URL, cursor_factory=RealDictCursor)


# ── RabbitMQ Connection (with reconnect) ───────────────────────────────────────
class RabbitMQConnection:
    def __init__(self):
        self.connection: Optional[pika.BlockingConnection] = None
        self.channel: Optional[pika.channel.Channel] = None
        self.logger = logging.getLogger('rabbitmq')

    @retry(
        stop=stop_after_attempt(10),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((pika.exceptions.AMQPConnectionError, Exception)),
    )
    def connect(self):
        params = pika.URLParameters(Config.RABBITMQ_URL)
        params.heartbeat = 600
        params.blocked_connection_timeout = 300
        self.connection = pika.BlockingConnection(params)
        self.channel = self.connection.channel()
        self.logger.info('Connected to RabbitMQ')
        return self

    def setup_queues(self, queues: list[str]):
        for queue in queues:
            # Dead-letter exchange
            self.channel.exchange_declare(
                exchange=f'{queue}.dlx',
                exchange_type='direct',
                durable=True,
            )
            self.channel.queue_declare(
                queue=f'{queue}.dead',
                durable=True,
            )
            self.channel.queue_bind(
                queue=f'{queue}.dead',
                exchange=f'{queue}.dlx',
                routing_key=queue,
            )
            # Main queue with DLX
            self.channel.queue_declare(
                queue=queue,
                durable=True,
                arguments={
                    'x-dead-letter-exchange': f'{queue}.dlx',
                    'x-dead-letter-routing-key': queue,
                    'x-message-ttl': 3600000,  # 1 hour TTL
                },
            )

    def publish(self, queue: str, payload: dict, priority: int = 0):
        self.channel.basic_publish(
            exchange='',
            routing_key=queue,
            body=json.dumps(payload),
            properties=pika.BasicProperties(
                delivery_mode=2,  # persistent
                priority=priority,
                timestamp=int(time.time()),
                content_type='application/json',
            ),
        )

    def close(self):
        if self.connection and not self.connection.is_closed:
            self.connection.close()


# ── Base Worker ────────────────────────────────────────────────────────────────
class BaseWorker:
    def __init__(self, queue_name: str):
        self.queue_name = queue_name
        self.logger = logging.getLogger(self.__class__.__name__)
        self.rmq = RabbitMQConnection()
        self.redis = get_redis_client()
        self.prefetch_count = int(os.getenv('WORKER_PREFETCH', '1'))

    def start(self):
        self.logger.info(f'Starting {self.__class__.__name__} — queue: {self.queue_name}')
        while True:
            try:
                self.rmq.connect()
                self.rmq.setup_queues([self.queue_name])
                self.rmq.channel.basic_qos(prefetch_count=self.prefetch_count)
                self.rmq.channel.basic_consume(
                    queue=self.queue_name,
                    on_message_callback=self._safe_process,
                )
                self.logger.info('Waiting for messages...')
                self.rmq.channel.start_consuming()
            except pika.exceptions.AMQPConnectionError as e:
                self.logger.error(f'RabbitMQ connection error: {e}. Retrying in 5s...')
                time.sleep(5)
            except KeyboardInterrupt:
                self.logger.info('Shutting down worker...')
                self.rmq.close()
                break
            except Exception as e:
                self.logger.error(f'Unexpected error: {e}. Retrying in 10s...')
                time.sleep(10)

    def _safe_process(self, ch, method, properties, body: bytes):
        start = time.time()
        task_id = None
        try:
            payload = json.loads(body)
            task_id = payload.get('jobId') or payload.get('taskId')
            self.logger.info(f'Processing task {task_id}: {payload.get("type", "unknown")}')

            self.process(payload)

            ch.basic_ack(delivery_tag=method.delivery_tag)
            self.logger.info(f'Task {task_id} completed in {(time.time() - start)*1000:.0f}ms')

        except Exception as e:
            self.logger.error(f'Task {task_id} failed: {e}', exc_info=True)
            # Requeue up to 3 times, then send to DLQ
            retry_count = (properties.headers or {}).get('x-retry-count', 0)
            if retry_count < 3:
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                # Re-publish with incremented retry count
                self.rmq.channel.basic_publish(
                    exchange='',
                    routing_key=self.queue_name,
                    body=body,
                    properties=pika.BasicProperties(
                        delivery_mode=2,
                        headers={'x-retry-count': retry_count + 1},
                        expiration=str(5000 * (2 ** retry_count)),  # exponential delay
                    ),
                )
            else:
                self.logger.error(f'Task {task_id} exceeded retry limit — sending to DLQ')
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

    def process(self, payload: dict):
        raise NotImplementedError('Subclasses must implement process()')

    def log_to_db(self, tenant_id: str, module: str, task_type: str,
                   status: str, input_data: dict = None, output_data: dict = None,
                   error: str = None, duration_ms: int = None):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        INSERT INTO ai_logs (tenant_id, module, task_type, status,
                            input_data, output_data, error_message, duration_ms, completed_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
                        """,
                        (
                            tenant_id, module, task_type, status,
                            json.dumps(input_data) if input_data else None,
                            json.dumps(output_data) if output_data else None,
                            error, duration_ms,
                        ),
                    )
                    conn.commit()
        except Exception as e:
            self.logger.error(f'Failed to write AI log: {e}')
