"""Product Research AI Worker — discovers trending products."""

import json
import time
import logging
import os
from typing import Optional

from openai import OpenAI
import psycopg2
from psycopg2.extras import RealDictCursor

import sys
sys.path.insert(0, '/app')
from shared.base_worker import BaseWorker, Config, get_db_connection, get_redis_client

logger = logging.getLogger('product_research.worker')


class ProductResearchWorker(BaseWorker):
    def __init__(self):
        super().__init__(queue_name='ai_tasks_queue')
        self.openai = OpenAI(api_key=Config.OPENAI_API_KEY)
        self.TASK_HANDLERS = {
            'analyze_product': self.analyze_product,
            'discover_trending': self.discover_trending,
            'import_supplier_products': self.import_supplier_products,
        }

    def process(self, payload: dict):
        task_type = payload.get('type') or payload.get('taskType', 'analyze_product')
        handler = self.TASK_HANDLERS.get(task_type)
        if handler:
            handler(payload)
        else:
            # Only handle research tasks, let other workers handle their own
            if task_type in ('batch_pricing', 'launch_campaign', 'sync_supplier'):
                return  # skip silently
            logger.warning(f'Unknown task type: {task_type}')

    # ── Analyze Product ────────────────────────────────────────────────────────
    def analyze_product(self, payload: dict):
        product_id = payload.get('productId')
        tenant_id = payload.get('tenantId')
        start = time.time()

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    'SELECT * FROM products WHERE id = %s AND tenant_id = %s',
                    (product_id, tenant_id),
                )
                product = cur.fetchone()

        if not product:
            logger.error(f'Product {product_id} not found')
            return

        product = dict(product)
        cache_key = f'ai:analysis:{product_id}'
        cached = self.redis.get(cache_key)

        if cached:
            result = json.loads(cached)
        else:
            result = self._run_product_analysis(product)
            self.redis.setex(cache_key, 3600, json.dumps(result))

        # Update product
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE products
                    SET ai_score = %s,
                        ai_tags = %s,
                        ai_last_analyzed_at = NOW()
                    WHERE id = %s AND tenant_id = %s
                    """,
                    (
                        result.get('viabilityScore', 0),
                        result.get('tags', []),
                        product_id,
                        tenant_id,
                    ),
                )
                conn.commit()

        self.log_to_db(
            tenant_id, 'product_research', 'analyze_product', 'completed',
            input_data={'productId': product_id},
            output_data=result,
            duration_ms=int((time.time() - start) * 1000),
        )

    def _run_product_analysis(self, product: dict) -> dict:
        prompt = f"""Analyze this dropshipping product for viability:
Product: {product.get('name')}
Price: ${product.get('base_price')}
Cost: ${product.get('cost_price')}
Category: {product.get('category_id', 'Unknown')}

Return JSON only:
{{
  "viabilityScore": 0-100,
  "marketSaturation": "low|medium|high",
  "demandTrend": "rising|stable|declining",
  "competitionLevel": "low|medium|high",
  "recommendedAction": "sell|avoid|watchlist",
  "tags": ["tag1", "tag2"],
  "pros": ["pro1"],
  "cons": ["con1"],
  "estimatedMonthlySales": number
}}"""

        try:
            response = self.openai.chat.completions.create(
                model='gpt-4o-mini',
                messages=[{'role': 'user', 'content': prompt}],
                response_format={'type': 'json_object'},
                max_tokens=500,
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            logger.error(f'OpenAI analysis failed: {e}')
            return {'viabilityScore': 50, 'tags': [], 'error': str(e)}

    # ── Discover Trending ──────────────────────────────────────────────────────
    def discover_trending(self, payload: dict):
        tenant_id = payload.get('tenantId')
        category = payload.get('category', 'general')
        limit = payload.get('limit', 20)
        start = time.time()

        prompt = f"""Generate {limit} trending product ideas for dropshipping in {category} category (2025-2026).
Focus on products with:
- High demand growth
- Good profit margins (50%+)
- Lightweight/easy to ship
- TikTok/Instagram viral potential

Return JSON only:
{{
  "trends": [
    {{
      "keyword": "product name",
      "score": 0-100,
      "platform": "tiktok|instagram|amazon",
      "growthRate": percentage,
      "sentiment": -1 to 1,
      "category": "category name",
      "estimatedMargin": percentage,
      "targetAudience": "description"
    }}
  ]
}}"""

        try:
            response = self.openai.chat.completions.create(
                model='gpt-4o',
                messages=[{'role': 'user', 'content': prompt}],
                response_format={'type': 'json_object'},
                max_tokens=2000,
            )
            data = json.loads(response.choices[0].message.content)
            trends = data.get('trends', [])

            # Save trends to DB
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    for trend in trends:
                        cur.execute(
                            """
                            INSERT INTO trends (tenant_id, keyword, platform, score, growth_rate, sentiment, category, data_snapshot)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                            ON CONFLICT DO NOTHING
                            """,
                            (
                                tenant_id,
                                trend.get('keyword'),
                                trend.get('platform'),
                                trend.get('score'),
                                trend.get('growthRate'),
                                trend.get('sentiment'),
                                trend.get('category'),
                                json.dumps(trend),
                            ),
                        )
                    conn.commit()

            # Cache top trends
            cache_key = f'trending:{tenant_id}:{category}'
            self.redis.setex(cache_key, 600, json.dumps(trends[:20]))

            self.log_to_db(
                tenant_id, 'product_research', 'discover_trending', 'completed',
                output_data={'trendsFound': len(trends)},
                duration_ms=int((time.time() - start) * 1000),
            )

        except Exception as e:
            logger.error(f'Trend discovery failed: {e}')
            self.log_to_db(tenant_id, 'product_research', 'discover_trending', 'failed', error=str(e))

    # ── Import Supplier Products ───────────────────────────────────────────────
    def import_supplier_products(self, payload: dict):
        tenant_id = payload.get('tenantId')
        supplier_id = payload.get('supplierId')
        product_ids = payload.get('productIds', [])

        logger.info(f'Importing {len(product_ids)} products from supplier {supplier_id}')
        # TODO: Implement actual supplier product import
        # This would fetch product details from supplier API and insert into products table
        self.log_to_db(
            tenant_id, 'product_research', 'import_supplier_products', 'completed',
            input_data={'supplierId': supplier_id, 'count': len(product_ids)},
        )


if __name__ == '__main__':
    worker = ProductResearchWorker()
    worker.start()
