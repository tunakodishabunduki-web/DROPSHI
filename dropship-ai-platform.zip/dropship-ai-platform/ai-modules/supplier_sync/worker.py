"""Supplier Sync AI Worker — inventory sync and failover."""

import json
import time
import logging
import requests
import sys

sys.path.insert(0, '/app')
from shared.base_worker import BaseWorker, Config, get_db_connection

logger = logging.getLogger('supplier_sync.worker')


class SupplierSyncWorker(BaseWorker):
    def __init__(self):
        super().__init__(queue_name='supplier_sync_queue')

    def process(self, payload: dict):
        task_type = payload.get('type', 'sync_supplier')
        if task_type == 'sync_supplier':
            self.sync_supplier(payload)
        elif task_type == 'sync_all':
            self.sync_all(payload)
        elif task_type == 'check_health':
            self.check_health(payload)

    def sync_supplier(self, payload: dict):
        supplier_id = payload.get('supplierId')
        tenant_id = payload.get('tenantId')
        start = time.time()

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT * FROM suppliers WHERE id = %s AND tenant_id = %s', (supplier_id, tenant_id))
                supplier = cur.fetchone()

        if not supplier:
            logger.error(f'Supplier {supplier_id} not found')
            return

        supplier = dict(supplier)
        logger.info(f'Syncing supplier: {supplier["name"]} ({supplier["api_type"]})')

        try:
            products = self._fetch_supplier_products(supplier)
            updated, out_of_stock = self._apply_updates(tenant_id, supplier_id, products)

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE suppliers SET last_synced_at = NOW(), reliability_score = LEAST(1.0, COALESCE(reliability_score, 0.5) * 0.9 + 0.1) WHERE id = %s",
                        (supplier_id,),
                    )
                    conn.commit()

            self.log_to_db(
                tenant_id, 'supplier_sync', 'sync_supplier', 'completed',
                output_data={'updated': updated, 'outOfStock': out_of_stock},
                duration_ms=int((time.time() - start) * 1000),
            )
            logger.info(f'Supplier {supplier["name"]}: {updated} updated, {out_of_stock} out of stock')

        except Exception as e:
            logger.error(f'Sync failed for {supplier["name"]}: {e}')
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE suppliers SET reliability_score = GREATEST(0, COALESCE(reliability_score, 0.5) - 0.05) WHERE id = %s",
                        (supplier_id,),
                    )
                    conn.commit()

            # Check for failover
            if supplier.get('failover_supplier_id'):
                self._trigger_failover(tenant_id, supplier)

            self.log_to_db(tenant_id, 'supplier_sync', 'sync_supplier', 'failed', error=str(e))
            raise

    def sync_all(self, payload: dict):
        tenant_id = payload.get('tenantId')
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM suppliers WHERE tenant_id = %s AND status = 'active'", (tenant_id,))
                suppliers = cur.fetchall()

        for s in suppliers:
            self.rmq.publish('supplier_sync_queue', {
                'type': 'sync_supplier',
                'supplierId': str(s['id']),
                'tenantId': tenant_id,
            })
        logger.info(f'Queued sync for {len(suppliers)} suppliers')

    def check_health(self, payload: dict):
        tenant_id = payload.get('tenantId')
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id, name, website FROM suppliers WHERE tenant_id = %s AND status = 'active'", (tenant_id,))
                suppliers = cur.fetchall()

        for s in suppliers:
            try:
                url = s['website'] or 'https://httpstat.us/200'
                resp = requests.head(url, timeout=5)
                healthy = resp.status_code < 500
            except Exception:
                healthy = False

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE suppliers SET status = %s WHERE id = %s",
                        ('active' if healthy else 'inactive', s['id']),
                    )
                    conn.commit()

    def _fetch_supplier_products(self, supplier: dict) -> list:
        api_type = supplier.get('api_type')
        credentials = supplier.get('api_credentials') or {}
        if isinstance(credentials, str):
            credentials = json.loads(credentials)

        if api_type == 'aliexpress':
            return self._fetch_aliexpress(credentials)
        elif api_type == 'shopify':
            return self._fetch_shopify(credentials, supplier.get('website', ''))
        else:
            return self._fetch_custom(credentials, supplier.get('website', ''))

    def _fetch_aliexpress(self, creds: dict) -> list:
        # Stub — real implementation uses AliExpress Open Platform API
        return []

    def _fetch_shopify(self, creds: dict, domain: str) -> list:
        token = creds.get('accessToken')
        if not token or not domain:
            return []
        try:
            resp = requests.get(
                f'https://{domain}/admin/api/2024-01/variants.json',
                headers={'X-Shopify-Access-Token': token},
                params={'limit': 250},
                timeout=30,
            )
            variants = resp.json().get('variants', [])
            return [{'sku': v['sku'], 'stock': v['inventory_quantity'], 'costPrice': float(v['price']) * 0.5} for v in variants if v.get('sku')]
        except Exception as e:
            logger.error(f'Shopify fetch failed: {e}')
            return []

    def _fetch_custom(self, creds: dict, base_url: str) -> list:
        if not base_url:
            return []
        try:
            resp = requests.get(f'{base_url}/inventory', headers={'Authorization': f'Bearer {creds.get("apiKey", "")}'}, timeout=30)
            return resp.json().get('products', [])
        except Exception as e:
            logger.error(f'Custom API fetch failed: {e}')
            return []

    def _apply_updates(self, tenant_id: str, supplier_id: str, products: list) -> tuple:
        updated = 0
        out_of_stock = 0
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                for p in products:
                    cur.execute(
                        "SELECT id, stock_quantity, cost_price FROM products WHERE tenant_id = %s AND supplier_id = %s AND supplier_sku = %s",
                        (tenant_id, supplier_id, p.get('sku')),
                    )
                    row = cur.fetchone()
                    if not row:
                        continue
                    new_stock = p.get('stock', 0)
                    new_cost = p.get('costPrice')
                    if row['stock_quantity'] != new_stock or (new_cost and row['cost_price'] != new_cost):
                        status = 'out_of_stock' if new_stock == 0 else 'active'
                        cur.execute(
                            "UPDATE products SET stock_quantity = %s, cost_price = COALESCE(%s, cost_price), status = %s WHERE id = %s",
                            (new_stock, new_cost, status, row['id']),
                        )
                        updated += 1
                        if new_stock == 0:
                            out_of_stock += 1
                conn.commit()
        return updated, out_of_stock

    def _trigger_failover(self, tenant_id: str, supplier: dict):
        failover_id = supplier.get('failover_supplier_id')
        logger.warning(f'Triggering failover: {supplier["id"]} -> {failover_id}')
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE products SET supplier_id = %s WHERE tenant_id = %s AND supplier_id = %s",
                    (failover_id, tenant_id, supplier['id']),
                )
                conn.commit()


if __name__ == '__main__':
    worker = SupplierSyncWorker()
    worker.start()
