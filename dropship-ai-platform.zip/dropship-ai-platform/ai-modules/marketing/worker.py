"""Marketing AI Worker — ad generation and campaign scheduling."""

import json
import time
import logging
import sys

from openai import OpenAI
sys.path.insert(0, '/app')
from shared.base_worker import BaseWorker, Config, get_db_connection

logger = logging.getLogger('marketing.worker')


class MarketingWorker(BaseWorker):
    def __init__(self):
        super().__init__(queue_name='marketing_campaign_queue')
        self.openai = OpenAI(api_key=Config.OPENAI_API_KEY)

    def process(self, payload: dict):
        task_type = payload.get('type', 'launch_campaign')
        if task_type == 'launch_campaign':
            self.launch_campaign(payload)
        elif task_type == 'optimize_ad':
            self.optimize_ad(payload)

    def launch_campaign(self, payload: dict):
        ad_id = payload.get('adId')
        tenant_id = payload.get('tenantId')
        logger.info(f'Launching campaign for ad {ad_id}')

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE ads SET status = 'active' WHERE id = %s AND tenant_id = %s",
                    (ad_id, tenant_id),
                )
                conn.commit()

        self.log_to_db(tenant_id, 'marketing', 'launch_campaign', 'completed',
                       input_data={'adId': ad_id})

    def optimize_ad(self, payload: dict):
        ad_id = payload.get('adId')
        tenant_id = payload.get('tenantId')
        reason = payload.get('reason', 'low_ctr')

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT * FROM ads WHERE id = %s AND tenant_id = %s', (ad_id, tenant_id))
                ad = cur.fetchone()

        if not ad:
            return

        ad = dict(ad)
        try:
            resp = self.openai.chat.completions.create(
                model='gpt-4o-mini',
                messages=[{
                    'role': 'user',
                    'content': f'Improve this underperforming ad (reason: {reason}):\nHeadline: {ad.get("headline")}\nBody: {ad.get("body_copy")}\nPlatform: {ad.get("platform")}\n\nReturn JSON: {{headline, body, cta}}',
                }],
                response_format={'type': 'json_object'},
                max_tokens=300,
            )
            improved = json.loads(resp.choices[0].message.content)
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE ads SET headline = %s, body_copy = %s, cta = %s, status = 'active' WHERE id = %s",
                        (improved.get('headline'), improved.get('body'), improved.get('cta'), ad_id),
                    )
                    conn.commit()
            logger.info(f'Ad {ad_id} optimized and re-activated')
        except Exception as e:
            logger.error(f'Ad optimization failed: {e}')

        self.log_to_db(tenant_id, 'marketing', 'optimize_ad', 'completed', input_data={'adId': ad_id, 'reason': reason})


if __name__ == '__main__':
    worker = MarketingWorker()
    worker.start()
