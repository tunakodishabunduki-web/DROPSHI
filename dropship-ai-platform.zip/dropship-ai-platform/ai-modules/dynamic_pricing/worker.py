"""Dynamic Pricing AI Worker — price optimization across strategies."""

import json
import time
import logging
import sys

from openai import OpenAI
import psycopg2
from psycopg2.extras import RealDictCursor

sys.path.insert(0, '/app')
from shared.base_worker import BaseWorker, Config, get_db_connection, get_redis_client

logger = logging.getLogger('dynamic_pricing.worker')


class DynamicPricingWorker(BaseWorker):
    def __init__(self):
        super().__init__(queue_name='ai_tasks_queue')
        self.openai = OpenAI(api_key=Config.OPENAI_API_KEY)

    def process(self, payload: dict):
        task_type = payload.get('type') or payload.get('taskType', '')
        if task_type == 'batch_pricing':
            self.run_batch(payload)
        # Other task types are handled by other workers

    def run_batch(self, payload: dict):
        tenant_id = payload.get('tenantId')
        strategy = payload.get('strategy', 'cost_plus')
        product_ids = payload.get('productIds', [])
        start = time.time()

        updated = 0
        for pid in product_ids:
            try:
                updated += self._update_price(tenant_id, pid, strategy)
            except Exception as e:
                logger.error(f'Failed to price product {pid}: {e}')

        self.log_to_db(
            tenant_id, 'dynamic_pricing', 'batch_pricing', 'completed',
            output_data={'updated': updated, 'strategy': strategy},
            duration_ms=int((time.time() - start) * 1000),
        )
        logger.info(f'Batch pricing complete: {updated}/{len(product_ids)} products updated')

    def _update_price(self, tenant_id: str, product_id: str, strategy: str) -> int:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    'SELECT id, name, base_price, cost_price FROM products WHERE id = %s AND tenant_id = %s AND status = %s',
                    (product_id, tenant_id, 'active'),
                )
                product = cur.fetchone()

        if not product:
            return 0

        product = dict(product)
        new_price = self._calculate_price(product, strategy)

        if abs(new_price - float(product['base_price'])) < 0.01:
            return 0

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO pricing_history (product_id, tenant_id, old_price, new_price, strategy, change_reason)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (product_id, tenant_id, product['base_price'], new_price, strategy, 'AI batch pricing'),
                )
                cur.execute(
                    'UPDATE products SET base_price = %s WHERE id = %s AND tenant_id = %s',
                    (new_price, product_id, tenant_id),
                )
                conn.commit()

        return 1

    def _calculate_price(self, product: dict, strategy: str) -> float:
        cost = float(product.get('cost_price') or 0)
        current = float(product.get('base_price') or 0)

        if strategy == 'cost_plus':
            return round(max(cost * 2.5, cost * 1.2), 2)

        if strategy == 'ai_optimal' and Config.OPENAI_API_KEY:
            try:
                resp = self.openai.chat.completions.create(
                    model='gpt-4o-mini',
                    messages=[{
                        'role': 'user',
                        'content': f'Suggest optimal price for: {product["name"]}, cost ${cost}, current ${current}. Return just the number.',
                    }],
                    max_tokens=20,
                )
                price = float(resp.choices[0].message.content.strip().replace('$', ''))
                return round(max(price, cost * 1.15), 2)
            except Exception:
                return round(cost * 2.0, 2)

        return round(current, 2)


if __name__ == '__main__':
    worker = DynamicPricingWorker()
    worker.start()
