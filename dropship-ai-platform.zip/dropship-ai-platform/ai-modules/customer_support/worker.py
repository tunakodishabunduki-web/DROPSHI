"""Customer Support AI Worker — auto-triage and respond to tickets."""

import json
import time
import logging
import sys

from openai import OpenAI
sys.path.insert(0, '/app')
from shared.base_worker import BaseWorker, Config, get_db_connection

logger = logging.getLogger('customer_support.worker')

SYSTEM_PROMPT = """You are a helpful e-commerce customer support agent.
Be empathetic, concise, and solution-focused.
If you cannot resolve, offer to escalate.
Always maintain a professional and friendly tone."""

URGENT_PATTERNS = ['fraud', 'stolen', 'charge', 'broken', 'urgent', 'asap', 'immediately']
HIGH_PATTERNS = ['refund', 'damaged', 'wrong item', 'never received', 'cancel']


class CustomerSupportWorker(BaseWorker):
    def __init__(self):
        super().__init__(queue_name='customer_support_queue')
        self.openai = OpenAI(api_key=Config.OPENAI_API_KEY)

    def process(self, payload: dict):
        task_type = payload.get('type', 'triage_ticket')
        if task_type == 'triage_ticket':
            self.triage_ticket(payload)
        elif task_type == 'bulk_triage':
            self.bulk_triage(payload)
        elif task_type == 'respond':
            self.auto_respond(payload)

    def triage_ticket(self, payload: dict):
        ticket_id = payload.get('ticketId')
        tenant_id = payload.get('tenantId')
        start = time.time()

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    'SELECT * FROM support_tickets WHERE id = %s AND tenant_id = %s',
                    (ticket_id, tenant_id),
                )
                ticket = cur.fetchone()

        if not ticket:
            logger.error(f'Ticket {ticket_id} not found')
            return

        ticket = dict(ticket)
        text = f"{ticket.get('subject', '')} {ticket.get('description', '')}".lower()

        # Priority classification
        priority = 'medium'
        if any(p in text for p in URGENT_PATTERNS):
            priority = 'urgent'
        elif any(p in text for p in HIGH_PATTERNS):
            priority = 'high'

        # Generate AI response
        ai_response, confidence, can_auto_resolve = self._generate_response(ticket)

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE support_tickets
                    SET priority = %s, ai_suggested_response = %s, ai_confidence = %s,
                        first_response_at = COALESCE(first_response_at, NOW())
                    WHERE id = %s AND tenant_id = %s
                    """,
                    (priority, ai_response, confidence, ticket_id, tenant_id),
                )

                if can_auto_resolve and confidence > 0.85:
                    cur.execute(
                        """
                        INSERT INTO ticket_messages (ticket_id, tenant_id, sender_type, message, is_ai)
                        VALUES (%s, %s, 'ai', %s, true)
                        """,
                        (ticket_id, tenant_id, ai_response),
                    )
                    cur.execute(
                        "UPDATE support_tickets SET status = 'in_progress' WHERE id = %s",
                        (ticket_id,),
                    )

                conn.commit()

        self.log_to_db(
            tenant_id, 'customer_support', 'triage_ticket', 'completed',
            output_data={'priority': priority, 'confidence': confidence, 'autoResolved': can_auto_resolve},
            duration_ms=int((time.time() - start) * 1000),
        )

    def bulk_triage(self, payload: dict):
        tenant_id = payload.get('tenantId')
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id FROM support_tickets WHERE tenant_id = %s AND status = 'open' AND ai_suggested_response IS NULL LIMIT 50",
                    (tenant_id,),
                )
                tickets = cur.fetchall()

        processed = 0
        for t in tickets:
            try:
                self.triage_ticket({'ticketId': str(t['id']), 'tenantId': tenant_id})
                processed += 1
            except Exception as e:
                logger.error(f'Bulk triage error for {t["id"]}: {e}')

        logger.info(f'Bulk triage: {processed}/{len(tickets)} tickets processed')

    def auto_respond(self, payload: dict):
        ticket_id = payload.get('ticketId')
        tenant_id = payload.get('tenantId')
        message = payload.get('message', '')

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    'SELECT tm.message, tm.sender_type FROM ticket_messages tm WHERE tm.ticket_id = %s ORDER BY tm.created_at DESC LIMIT 10',
                    (ticket_id,),
                )
                history = cur.fetchall()

        messages = [
            {'role': 'system', 'content': SYSTEM_PROMPT},
            *[{'role': 'user' if h['sender_type'] == 'customer' else 'assistant', 'content': h['message']} for h in reversed(history)],
            {'role': 'user', 'content': message},
        ]

        try:
            resp = self.openai.chat.completions.create(
                model='gpt-4o',
                messages=messages,
                max_tokens=400,
            )
            ai_reply = resp.choices[0].message.content
            should_escalate = any(word in ai_reply.lower() for word in ['escalate', 'supervisor', 'cannot help'])

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    for sender, msg in [('customer', message), ('ai', ai_reply)]:
                        cur.execute(
                            "INSERT INTO ticket_messages (ticket_id, tenant_id, sender_type, message, is_ai) VALUES (%s, %s, %s, %s, %s)",
                            (ticket_id, tenant_id, sender, msg, sender == 'ai'),
                        )
                    if should_escalate:
                        cur.execute(
                            "UPDATE support_tickets SET status = 'escalated', escalated_at = NOW(), priority = 'high' WHERE id = %s",
                            (ticket_id,),
                        )
                    conn.commit()
        except Exception as e:
            logger.error(f'Auto-respond failed for ticket {ticket_id}: {e}')

    def _generate_response(self, ticket: dict):
        try:
            resp = self.openai.chat.completions.create(
                model='gpt-4o-mini',
                messages=[
                    {'role': 'system', 'content': SYSTEM_PROMPT},
                    {'role': 'user', 'content': f'Subject: {ticket.get("subject")}\nDescription: {ticket.get("description", "")}\nGenerate a helpful response. Return JSON: {{response, canAutoResolve: bool, confidence: 0-1}}'},
                ],
                response_format={'type': 'json_object'},
                max_tokens=400,
            )
            result = json.loads(resp.choices[0].message.content)
            return result.get('response', ''), result.get('confidence', 0.5), result.get('canAutoResolve', False)
        except Exception as e:
            logger.error(f'Response generation failed: {e}')
            return 'Thank you for contacting us. Our team will respond shortly.', 0.3, False


if __name__ == '__main__':
    worker = CustomerSupportWorker()
    worker.start()
