// ─── database.config.ts ───────────────────────────────────────────────────────
import { registerAs } from '@nestjs/config';

export const databaseConfig = registerAs('database', () => ({
  url: process.env.DATABASE_URL,
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT, 10) || 5432,
  username: process.env.POSTGRES_USER || 'dropship',
  password: process.env.POSTGRES_PASSWORD || 'dropship_secret',
  database: process.env.POSTGRES_DB || 'dropship_db',
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  pool: { max: 20, idleTimeoutMillis: 30000 },
}));
