// ─── coupons.module.ts ────────────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CouponsController } from './coupons.controller';
import { CouponsService } from './coupons.service';
import { Coupon } from './entities/coupon.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Coupon])],
  controllers: [CouponsController],
  providers: [CouponsService],
  exports: [CouponsService],
})
export class CouponsModule {}

// ─── coupon.entity.ts ─────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, Unique } from 'typeorm';

@Entity('coupons')
@Unique(['tenantId', 'code'])
export class Coupon {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 50 }) code: string;
  @Column({ nullable: true }) description: string;
  @Column({ name: 'discount_type', length: 20 }) discountType: string;
  @Column({ name: 'discount_value', type: 'numeric', precision: 10, scale: 2 }) discountValue: number;
  @Column({ name: 'min_order_amount', type: 'numeric', precision: 10, scale: 2, nullable: true }) minOrderAmount: number;
  @Column({ name: 'max_discount', type: 'numeric', precision: 10, scale: 2, nullable: true }) maxDiscount: number;
  @Column({ name: 'usage_limit', nullable: true }) usageLimit: number;
  @Column({ name: 'used_count', default: 0 }) usedCount: number;
  @Column({ name: 'per_user_limit', default: 1 }) perUserLimit: number;
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @Column({ name: 'applicable_to', type: 'jsonb', default: {} }) applicableTo: object;
  @Column({ name: 'starts_at', nullable: true }) startsAt: Date;
  @Column({ name: 'expires_at', nullable: true }) expiresAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── coupons.service.ts ───────────────────────────────────────────────────────
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class CouponsService {
  constructor(@InjectRepository(Coupon) private repo: Repository<Coupon>) {}
  findAll(tenantId: string) { return this.repo.find({ where: { tenantId }, order: { createdAt: 'DESC' } }); }
  async findOne(tenantId: string, id: string) {
    const c = await this.repo.findOne({ where: { id, tenantId } });
    if (!c) throw new NotFoundException('Coupon not found');
    return c;
  }
  async validateCode(tenantId: string, code: string) {
    const c = await this.repo.findOne({ where: { tenantId, code: code.toUpperCase(), isActive: true } });
    if (!c) throw new NotFoundException('Invalid or expired coupon');
    if (c.expiresAt && c.expiresAt < new Date()) throw new NotFoundException('Coupon has expired');
    if (c.usageLimit && c.usedCount >= c.usageLimit) throw new NotFoundException('Coupon usage limit reached');
    return c;
  }
  create(tenantId: string, dto: any) {
    return this.repo.save(this.repo.create({ ...dto, tenantId, code: dto.code?.toUpperCase() }));
  }
  async update(tenantId: string, id: string, dto: any) {
    await this.findOne(tenantId, id);
    await this.repo.update({ id, tenantId }, dto);
    return this.findOne(tenantId, id);
  }
  async delete(tenantId: string, id: string) {
    await this.findOne(tenantId, id);
    await this.repo.delete({ id, tenantId });
  }
}

// ─── coupons.controller.ts ────────────────────────────────────────────────────
import { Controller, Get, Post, Put, Delete, Param, Body, UseGuards, ParseUUIDPipe, HttpCode, HttpStatus, Query } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';
import { Public } from '../../common/decorators/index';

@ApiTags('coupons') @ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'coupons', version: '1' })
export class CouponsController {
  constructor(private svc: CouponsService) {}
  @Get() findAll(@CurrentTenant() t: string) { return this.svc.findAll(t); }
  @Get('validate') @Public() validate(@Query('code') code: string, @CurrentTenant() t: string) { return this.svc.validateCode(t, code); }
  @Post() @Roles('tenant_admin','manager') @HttpCode(HttpStatus.CREATED) create(@Body() dto: any, @CurrentTenant() t: string) { return this.svc.create(t, dto); }
  @Put(':id') @Roles('tenant_admin','manager') update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any, @CurrentTenant() t: string) { return this.svc.update(t, id, dto); }
  @Delete(':id') @Roles('tenant_admin') @HttpCode(HttpStatus.NO_CONTENT) delete(@Param('id', ParseUUIDPipe) id: string, @CurrentTenant() t: string) { return this.svc.delete(t, id); }
}
