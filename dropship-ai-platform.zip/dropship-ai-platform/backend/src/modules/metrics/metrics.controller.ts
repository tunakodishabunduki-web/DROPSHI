import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Public } from '../../common/decorators/index';
import * as client from 'prom-client';

const register = new client.Registry();
client.collectDefaultMetrics({ register });

@ApiTags('metrics')
@Controller({ path: 'metrics', version: '1' })
export class MetricsController {
  @Get()
  @Public()
  async getMetrics() {
    return register.metrics();
  }
}
