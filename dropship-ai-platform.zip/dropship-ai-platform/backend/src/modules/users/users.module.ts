// ─── users.module.ts ──────────────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User])],
  exports: [TypeOrmModule],
})
export class UsersModule {}

// ─── customer.entity.ts ───────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('customers')
export class Customer {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'user_id', nullable: true }) userId: string;
  @Column({ length: 255 }) email: string;
  @Column({ name: 'first_name', nullable: true }) firstName: string;
  @Column({ name: 'last_name', nullable: true }) lastName: string;
  @Column({ nullable: true }) phone: string;
  @Column({ name: 'total_spent', type: 'numeric', precision: 12, scale: 2, default: 0 }) totalSpent: number;
  @Column({ name: 'order_count', default: 0 }) orderCount: number;
  @Column({ name: 'avg_order_value', type: 'numeric', precision: 10, scale: 2, default: 0 }) avgOrderValue: number;
  @Column({ name: 'last_ordered_at', nullable: true }) lastOrderedAt: Date;
  @Column({ type: 'text', array: true, default: [] }) tags: string[];
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
