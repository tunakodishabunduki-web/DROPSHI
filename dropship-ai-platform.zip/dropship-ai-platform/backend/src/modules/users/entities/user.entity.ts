// ─── user.entity.ts ───────────────────────────────────────────────────────────
import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn, DeleteDateColumn,
} from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 255 }) email: string;
  @Column({ name: 'password_hash', nullable: true }) passwordHash: string;
  @Column({ name: 'first_name', length: 100 }) firstName: string;
  @Column({ name: 'last_name', length: 100 }) lastName: string;
  @Column({ name: 'avatar_url', nullable: true }) avatarUrl: string;
  @Column({ nullable: true }) phone: string;
  @Column({ default: 'customer' }) role: string;
  @Column({ default: 'pending_verification' }) status: string;
  @Column({ name: 'email_verified', default: false }) emailVerified: boolean;
  @Column({ name: 'email_verified_at', nullable: true }) emailVerifiedAt: Date;
  @Column({ name: 'two_factor_enabled', default: false }) twoFactorEnabled: boolean;
  @Column({ name: 'two_factor_secret', nullable: true }) twoFactorSecret: string;
  @Column({ name: 'oauth_provider', nullable: true }) oauthProvider: string;
  @Column({ name: 'oauth_provider_id', nullable: true }) oauthProviderId: string;
  @Column({ type: 'jsonb', default: {} }) preferences: object;
  @Column({ name: 'last_login_at', nullable: true }) lastLoginAt: Date;
  @Column({ name: 'last_login_ip', nullable: true }) lastLoginIp: string;
  @Column({ name: 'failed_login_attempts', default: 0 }) failedLoginAttempts: number;
  @Column({ name: 'locked_until', nullable: true }) lockedUntil: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
  @DeleteDateColumn({ name: 'deleted_at' }) deletedAt: Date;
}

// ─── refresh-token.entity.ts ──────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';

@Entity('refresh_tokens')
export class RefreshToken {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'user_id' }) userId: string;
  @Column({ name: 'token_hash', unique: true }) tokenHash: string;
  @Column({ type: 'uuid', default: () => 'uuid_generate_v4()' }) family: string;
  @Column({ name: 'expires_at' }) expiresAt: Date;
  @Column({ default: false }) revoked: boolean;
  @Column({ name: 'user_agent', nullable: true }) userAgent: string;
  @Column({ name: 'ip_address', nullable: true }) ipAddress: string;
  @ManyToOne(() => User) @JoinColumn({ name: 'user_id' }) user: User;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}

// ─── ai-log.entity.ts ─────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('ai_logs')
export class AiLog {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id', nullable: true }) tenantId: string;
  @Column({ length: 100 }) module: string;
  @Column({ name: 'task_type', length: 100 }) taskType: string;
  @Column({ default: 'queued' }) status: string;
  @Column({ name: 'input_data', type: 'jsonb', nullable: true }) inputData: object;
  @Column({ name: 'output_data', type: 'jsonb', nullable: true }) outputData: object;
  @Column({ name: 'model_used', nullable: true }) modelUsed: string;
  @Column({ name: 'tokens_used', nullable: true }) tokensUsed: number;
  @Column({ name: 'cost_usd', type: 'numeric', precision: 8, scale: 6, nullable: true }) costUsd: number;
  @Column({ name: 'duration_ms', nullable: true }) durationMs: number;
  @Column({ name: 'error_message', nullable: true }) errorMessage: string;
  @Column({ name: 'retry_count', default: 0 }) retryCount: number;
  @Column({ name: 'reference_id', nullable: true }) referenceId: string;
  @Column({ name: 'reference_type', nullable: true }) referenceType: string;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @Column({ name: 'completed_at', nullable: true }) completedAt: Date;
}

// ─── payment.entity.ts ────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('payments')
export class Payment {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'order_id' }) orderId: string;
  @Column({ name: 'order_created_at' }) orderCreatedAt: Date;
  @Column() provider: string;
  @Column({ name: 'provider_payment_id', nullable: true }) providerPaymentId: string;
  @Column({ name: 'provider_charge_id', nullable: true }) providerChargeId: string;
  @Column({ default: 'pending' }) status: string;
  @Column({ type: 'numeric', precision: 12, scale: 2 }) amount: number;
  @Column({ default: 'USD' }) currency: string;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @Column({ name: 'provider_response', type: 'jsonb', nullable: true }) providerResponse: object;
  @Column({ name: 'failed_reason', nullable: true }) failedReason: string;
  @Column({ name: 'refunded_amount', type: 'numeric', precision: 12, scale: 2, default: 0 }) refundedAmount: number;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;

  order: any; // relation loaded lazily
}
