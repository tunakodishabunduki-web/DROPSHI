import {
  Controller, Get, Post, Put, Patch, Delete,
  Param, Body, Query, UseGuards, ParseUUIDPipe,
  HttpCode, HttpStatus, UploadedFiles, UseInterceptors,
  Version,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { BulkUpdatePriceDto } from './dto/bulk-update-price.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentTenant } from '../../common/decorators/current-tenant.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuditLog } from '../../common/decorators/audit-log.decorator';

@ApiTags('products')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'products', version: '1' })
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  // ── GET /products ─────────────────────────────────────────
  @Get()
  @ApiOperation({ summary: 'List all products with filtering & pagination' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'category', required: false })
  @ApiQuery({ name: 'supplierId', required: false })
  @ApiQuery({ name: 'sortBy', required: false })
  @ApiQuery({ name: 'sortOrder', required: false, enum: ['ASC', 'DESC'] })
  findAll(@Query() query: ProductQueryDto, @CurrentTenant() tenantId: string) {
    return this.productsService.findAll(tenantId, query);
  }

  // ── GET /products/trending ────────────────────────────────
  @Get('trending')
  @ApiOperation({ summary: 'Get AI-ranked trending products' })
  getTrending(
    @CurrentTenant() tenantId: string,
    @Query('limit') limit = 20,
  ) {
    return this.productsService.getTrending(tenantId, limit);
  }

  // ── GET /products/search ──────────────────────────────────
  @Get('search')
  @Throttle({ default: { limit: 30, ttl: 60000 } })
  @ApiOperation({ summary: 'Full-text search products' })
  search(
    @Query('q') query: string,
    @CurrentTenant() tenantId: string,
    @Query('limit') limit = 20,
  ) {
    return this.productsService.search(tenantId, query, limit);
  }

  // ── GET /products/analytics ───────────────────────────────
  @Get('analytics')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Product performance analytics' })
  getAnalytics(@CurrentTenant() tenantId: string) {
    return this.productsService.getAnalytics(tenantId);
  }

  // ── GET /products/:id ─────────────────────────────────────
  @Get(':id')
  @ApiOperation({ summary: 'Get product by ID' })
  findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.findOne(tenantId, id);
  }

  // ── GET /products/:id/pricing-history ─────────────────────
  @Get(':id/pricing-history')
  @Roles('tenant_admin', 'manager')
  getPricingHistory(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.getPricingHistory(tenantId, id);
  }

  // ── GET /products/:id/variants ────────────────────────────
  @Get(':id/variants')
  getVariants(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.getVariants(tenantId, id);
  }

  // ── POST /products ────────────────────────────────────────
  @Post()
  @Roles('tenant_admin', 'manager', 'staff')
  @HttpCode(HttpStatus.CREATED)
  @AuditLog('CREATE_PRODUCT')
  @ApiOperation({ summary: 'Create new product' })
  create(
    @Body() dto: CreateProductDto,
    @CurrentTenant() tenantId: string,
    @CurrentUser() user: any,
  ) {
    return this.productsService.create(tenantId, dto, user.id);
  }

  // ── POST /products/import ─────────────────────────────────
  @Post('import')
  @Roles('tenant_admin', 'manager')
  @AuditLog('IMPORT_PRODUCTS')
  @ApiOperation({ summary: 'Import products from supplier' })
  importFromSupplier(
    @Body() body: { supplierId: string; productIds: string[] },
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.importFromSupplier(tenantId, body.supplierId, body.productIds);
  }

  // ── POST /products/bulk ───────────────────────────────────
  @Post('bulk/price-update')
  @Roles('tenant_admin', 'manager')
  @AuditLog('BULK_PRICE_UPDATE')
  @ApiOperation({ summary: 'Bulk update product prices' })
  bulkUpdatePrices(
    @Body() dto: BulkUpdatePriceDto,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.bulkUpdatePrices(tenantId, dto);
  }

  // ── PUT /products/:id ─────────────────────────────────────
  @Put(':id')
  @Roles('tenant_admin', 'manager', 'staff')
  @AuditLog('UPDATE_PRODUCT')
  @ApiOperation({ summary: 'Update product' })
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateProductDto,
    @CurrentTenant() tenantId: string,
    @CurrentUser() user: any,
  ) {
    return this.productsService.update(tenantId, id, dto, user.id);
  }

  // ── PATCH /products/:id/status ────────────────────────────
  @Patch(':id/status')
  @Roles('tenant_admin', 'manager')
  @AuditLog('UPDATE_PRODUCT_STATUS')
  updateStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @Body('status') status: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.updateStatus(tenantId, id, status);
  }

  // ── PATCH /products/:id/ai-analyze ───────────────────────
  @Patch(':id/ai-analyze')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Trigger AI analysis for product' })
  triggerAiAnalysis(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.triggerAiAnalysis(tenantId, id);
  }

  // ── DELETE /products/:id ──────────────────────────────────
  @Delete(':id')
  @Roles('tenant_admin', 'manager')
  @HttpCode(HttpStatus.NO_CONTENT)
  @AuditLog('DELETE_PRODUCT')
  @ApiOperation({ summary: 'Soft delete product' })
  remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.productsService.softDelete(tenantId, id);
  }
}
