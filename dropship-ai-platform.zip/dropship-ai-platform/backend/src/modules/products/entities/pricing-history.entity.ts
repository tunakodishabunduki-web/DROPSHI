import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('pricing_history')
export class PricingHistory {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'product_id' }) productId: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'old_price', type: 'numeric', precision: 10, scale: 2 }) oldPrice: number;
  @Column({ name: 'new_price', type: 'numeric', precision: 10, scale: 2 }) newPrice: number;
  @Column({ length: 50 }) strategy: string;
  @Column({ name: 'change_reason', nullable: true }) changeReason: string;
  @Column({ name: 'ai_confidence', type: 'numeric', precision: 3, scale: 2, nullable: true }) aiConfidence: number;
  @Column({ name: 'applied_by', nullable: true }) appliedBy: string;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
