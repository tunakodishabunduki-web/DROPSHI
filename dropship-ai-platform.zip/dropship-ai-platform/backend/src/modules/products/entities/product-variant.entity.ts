import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('product_variants')
export class ProductVariant {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'product_id' }) productId: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 100 }) sku: string;
  @Column({ length: 255 }) name: string;
  @Column({ type: 'jsonb', default: {} }) attributes: object;
  @Column({ type: 'numeric', precision: 10, scale: 2 }) price: number;
  @Column({ name: 'cost_price', type: 'numeric', precision: 10, scale: 2, default: 0 }) costPrice: number;
  @Column({ name: 'stock_quantity', default: 0 }) stockQuantity: number;
  @Column({ name: 'image_url', nullable: true }) imageUrl: string;
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
