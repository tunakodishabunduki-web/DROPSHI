import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, DeleteDateColumn, ManyToOne, OneToMany, JoinColumn, Index,
} from 'typeorm';
import { Tenant } from '../../tenants/entities/tenant.entity';
import { Supplier } from '../../suppliers/entities/supplier.entity';
import { Category } from '../../categories/entities/category.entity';
import { ProductVariant } from './product-variant.entity';

@Entity('products')
@Index(['tenantId', 'status'])
@Index(['tenantId', 'aiScore'])
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'tenant_id' })
  tenantId: string;

  @Column({ name: 'supplier_id', nullable: true })
  supplierId: string;

  @Column({ name: 'category_id', nullable: true })
  categoryId: string;

  @Column({ length: 100 })
  sku: string;

  @Column({ name: 'supplier_sku', length: 100, nullable: true })
  supplierSku: string;

  @Column({ length: 500 })
  name: string;

  @Column({ length: 500 })
  slug: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ name: 'short_description', length: 500, nullable: true })
  shortDescription: string;

  @Column({ type: 'jsonb', default: [] })
  images: string[];

  @Column({ type: 'text', array: true, default: [] })
  tags: string[];

  @Column({ default: 'draft' })
  status: 'active' | 'inactive' | 'draft' | 'out_of_stock' | 'discontinued';

  @Column({ name: 'cost_price', type: 'numeric', precision: 10, scale: 2, default: 0 })
  costPrice: number;

  @Column({ name: 'base_price', type: 'numeric', precision: 10, scale: 2, default: 0 })
  basePrice: number;

  @Column({ name: 'sale_price', type: 'numeric', precision: 10, scale: 2, nullable: true })
  salePrice: number;

  @Column({ default: 'USD' })
  currency: string;

  @Column({ name: 'stock_quantity', default: 0 })
  stockQuantity: number;

  @Column({ name: 'stock_reserved', default: 0 })
  stockReserved: number;

  @Column({ name: 'low_stock_threshold', default: 10 })
  lowStockThreshold: number;

  @Column({ name: 'track_inventory', default: true })
  trackInventory: boolean;

  @Column({ type: 'numeric', precision: 8, scale: 2, nullable: true })
  weight: number;

  @Column({ name: 'weight_unit', length: 5, default: 'kg' })
  weightUnit: string;

  @Column({ type: 'jsonb', nullable: true })
  dimensions: object;

  @Column({ name: 'ai_score', type: 'numeric', precision: 5, scale: 2, nullable: true })
  aiScore: number;

  @Column({ name: 'ai_tags', type: 'text', array: true, default: [] })
  aiTags: string[];

  @Column({ name: 'ai_last_analyzed_at', nullable: true })
  aiLastAnalyzedAt: Date;

  @Column({ name: 'seo_title', length: 255, nullable: true })
  seoTitle: string;

  @Column({ name: 'seo_description', length: 500, nullable: true })
  seoDescription: string;

  @Column({ name: 'supplier_url', type: 'text', nullable: true })
  supplierUrl: string;

  @Column({ name: 'supplier_data', type: 'jsonb', default: {} })
  supplierData: object;

  @Column({ type: 'jsonb', default: {} })
  attributes: object;

  @Column({ name: 'variants_enabled', default: false })
  variantsEnabled: boolean;

  @Column({ type: 'jsonb', default: {} })
  metadata: object;

  @Column({ name: 'view_count', default: 0 })
  viewCount: number;

  @Column({ name: 'sales_count', default: 0 })
  salesCount: number;

  @ManyToOne(() => Tenant) @JoinColumn({ name: 'tenant_id' }) tenant: Tenant;
  @ManyToOne(() => Supplier, { nullable: true }) @JoinColumn({ name: 'supplier_id' }) supplier: Supplier;
  @ManyToOne(() => Category, { nullable: true }) @JoinColumn({ name: 'category_id' }) category: Category;
  @OneToMany(() => ProductVariant, (v) => v.product) variants: ProductVariant[];

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
  @DeleteDateColumn({ name: 'deleted_at' }) deletedAt: Date;
}
