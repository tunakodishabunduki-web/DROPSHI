// ─── products.spec.ts ────────────────────────────────────────────────────────
import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { getQueueToken } from '@nestjs/bull';
import { ProductsService } from '../../src/modules/products/products.service';
import { Product } from '../../src/modules/products/entities/product.entity';
import { PricingHistory } from '../../src/modules/products/entities/pricing-history.entity';
import { ProductVariant } from '../../src/modules/products/entities/product-variant.entity';

const mockRepo = () => ({
  find: jest.fn(),
  findOne: jest.fn(),
  save: jest.fn(),
  create: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
  increment: jest.fn(),
  decrement: jest.fn(),
  createQueryBuilder: jest.fn(() => ({
    leftJoinAndSelect: jest.fn().mockReturnThis(),
    where: jest.fn().mockReturnThis(),
    andWhere: jest.fn().mockReturnThis(),
    orderBy: jest.fn().mockReturnThis(),
    skip: jest.fn().mockReturnThis(),
    take: jest.fn().mockReturnThis(),
    getManyAndCount: jest.fn().mockResolvedValue([[], 0]),
  })),
});

describe('ProductsService', () => {
  let service: ProductsService;
  let productsRepo: ReturnType<typeof mockRepo>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ProductsService,
        { provide: getRepositoryToken(Product), useFactory: mockRepo },
        { provide: getRepositoryToken(PricingHistory), useFactory: mockRepo },
        { provide: getRepositoryToken(ProductVariant), useFactory: mockRepo },
        { provide: getQueueToken('ai_tasks_queue'), useValue: { add: jest.fn() } },
        { provide: CACHE_MANAGER, useValue: { get: jest.fn(), set: jest.fn(), del: jest.fn(), store: { keys: jest.fn().mockResolvedValue([]) } } },
        { provide: 'DataSource', useValue: { query: jest.fn(), createQueryRunner: jest.fn(() => ({ connect: jest.fn(), startTransaction: jest.fn(), commitTransaction: jest.fn(), rollbackTransaction: jest.fn(), release: jest.fn(), manager: { findOne: jest.fn(), save: jest.fn(), update: jest.fn() } })) } },
      ],
    }).compile();

    service = module.get<ProductsService>(ProductsService);
    productsRepo = module.get(getRepositoryToken(Product));
  });

  describe('findAll', () => {
    it('should return paginated products', async () => {
      productsRepo.createQueryBuilder.mockReturnValue({
        leftJoinAndSelect: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
        getManyAndCount: jest.fn().mockResolvedValue([[{ id: '1', name: 'Test' }], 1]),
      });

      const result = await service.findAll('tenant-1', { page: 1, limit: 20 }) as any;
      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });
  });

  describe('findOne', () => {
    it('should throw NotFoundException when product not found', async () => {
      productsRepo.findOne.mockResolvedValue(null);
      await expect(service.findOne('tenant-1', 'non-existent')).rejects.toThrow('Product not found');
    });

    it('should return product when found', async () => {
      const product = { id: '1', name: 'Test Product', tenantId: 'tenant-1' };
      productsRepo.findOne.mockResolvedValue(product);
      productsRepo.increment.mockResolvedValue(undefined);
      const result = await service.findOne('tenant-1', '1');
      expect(result).toEqual(product);
    });
  });

  describe('create', () => {
    it('should create a product and queue AI analysis', async () => {
      const dto = { name: 'New Product', basePrice: 29.99, sku: 'SKU001' };
      const created = { id: '1', ...dto, tenantId: 'tenant-1' };
      productsRepo.create.mockReturnValue(created);
      productsRepo.save.mockResolvedValue(created);

      const result = await service.create('tenant-1', dto as any, 'user-1');
      expect(result).toEqual(created);
    });
  });

  describe('softDelete', () => {
    it('should soft delete existing product', async () => {
      const product = { id: '1', name: 'Test', tenantId: 'tenant-1' };
      productsRepo.findOne.mockResolvedValue(product);
      productsRepo.increment.mockResolvedValue(undefined);
      productsRepo.update.mockResolvedValue(undefined);

      await service.softDelete('tenant-1', '1');
      expect(productsRepo.update).toHaveBeenCalledWith(
        { id: '1', tenantId: 'tenant-1' },
        expect.objectContaining({ deletedAt: expect.any(Date) }),
      );
    });
  });
});
