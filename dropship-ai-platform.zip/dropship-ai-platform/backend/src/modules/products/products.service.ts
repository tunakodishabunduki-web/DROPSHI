import { Injectable, NotFoundException, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, ILike, In } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { Product } from './entities/product.entity';
import { PricingHistory } from './entities/pricing-history.entity';
import { ProductVariant } from './entities/product-variant.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { BulkUpdatePriceDto } from './dto/bulk-update-price.dto';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product) private productsRepo: Repository<Product>,
    @InjectRepository(PricingHistory) private pricingRepo: Repository<PricingHistory>,
    @InjectRepository(ProductVariant) private variantsRepo: Repository<ProductVariant>,
    @InjectQueue('ai_tasks_queue') private aiQueue: Queue,
    @Inject(CACHE_MANAGER) private cache: Cache,
    private dataSource: DataSource,
  ) {}

  // ── List Products ─────────────────────────────────────────
  async findAll(tenantId: string, query: ProductQueryDto) {
    const {
      page = 1, limit = 20, search, status, categoryId,
      supplierId, sortBy = 'createdAt', sortOrder = 'DESC',
      minPrice, maxPrice, tags,
    } = query;

    const cacheKey = `products:${tenantId}:${JSON.stringify(query)}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) return cached;

    const qb = this.productsRepo
      .createQueryBuilder('p')
      .leftJoinAndSelect('p.category', 'category')
      .leftJoinAndSelect('p.supplier', 'supplier')
      .where('p.tenantId = :tenantId', { tenantId })
      .andWhere('p.deletedAt IS NULL');

    if (search) {
      qb.andWhere(
        `(p.name ILIKE :search OR p.description ILIKE :search OR p.sku ILIKE :search)`,
        { search: `%${search}%` },
      );
    }
    if (status) qb.andWhere('p.status = :status', { status });
    if (categoryId) qb.andWhere('p.categoryId = :categoryId', { categoryId });
    if (supplierId) qb.andWhere('p.supplierId = :supplierId', { supplierId });
    if (minPrice) qb.andWhere('p.basePrice >= :minPrice', { minPrice });
    if (maxPrice) qb.andWhere('p.basePrice <= :maxPrice', { maxPrice });
    if (tags?.length) qb.andWhere('p.tags && :tags', { tags });

    const validSortFields = ['createdAt', 'name', 'basePrice', 'aiScore', 'salesCount', 'stockQuantity'];
    const safeSortBy = validSortFields.includes(sortBy) ? sortBy : 'createdAt';
    qb.orderBy(`p.${safeSortBy}`, sortOrder as 'ASC' | 'DESC');
    qb.skip((page - 1) * limit).take(limit);

    const [data, total] = await qb.getManyAndCount();

    const result = {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasMore: page * limit < total,
      },
    };

    await this.cache.set(cacheKey, result, 300); // 5 min cache
    return result;
  }

  // ── Get Trending ──────────────────────────────────────────
  async getTrending(tenantId: string, limit: number) {
    const cacheKey = `products:trending:${tenantId}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) return cached;

    const products = await this.productsRepo.find({
      where: { tenantId, status: 'active' },
      order: { aiScore: 'DESC', salesCount: 'DESC' },
      take: limit,
      relations: ['category'],
    });

    await this.cache.set(cacheKey, products, 600); // 10 min
    return products;
  }

  // ── Full-text Search ──────────────────────────────────────
  async search(tenantId: string, query: string, limit: number) {
    if (!query?.trim()) return [];

    return this.dataSource.query(
      `
      SELECT p.*, ts_rank(
        to_tsvector('english', p.name || ' ' || COALESCE(p.description, '')),
        plainto_tsquery('english', $1)
      ) AS rank
      FROM products p
      WHERE p.tenant_id = $2
        AND p.deleted_at IS NULL
        AND to_tsvector('english', p.name || ' ' || COALESCE(p.description, ''))
            @@ plainto_tsquery('english', $1)
      ORDER BY rank DESC
      LIMIT $3
      `,
      [query, tenantId, limit],
    );
  }

  // ── Get One ───────────────────────────────────────────────
  async findOne(tenantId: string, id: string) {
    const product = await this.productsRepo.findOne({
      where: { id, tenantId },
      relations: ['category', 'supplier', 'variants'],
    });
    if (!product) throw new NotFoundException('Product not found');

    // Increment view count (fire & forget)
    this.productsRepo.increment({ id, tenantId }, 'viewCount', 1).catch(() => {});

    return product;
  }

  // ── Create ────────────────────────────────────────────────
  async create(tenantId: string, dto: CreateProductDto, userId: string) {
    const product = this.productsRepo.create({ ...dto, tenantId });
    const saved = await this.productsRepo.save(product);

    // Queue AI analysis
    await this.aiQueue.add('analyze_product', {
      productId: saved.id,
      tenantId,
      triggeredBy: userId,
    }, { priority: 5 });

    await this.invalidateProductCache(tenantId);
    return saved;
  }

  // ── Update ────────────────────────────────────────────────
  async update(tenantId: string, id: string, dto: UpdateProductDto, userId: string) {
    const product = await this.findOne(tenantId, id);

    // Record price change
    if (dto.basePrice && dto.basePrice !== product.basePrice) {
      await this.pricingRepo.save(
        this.pricingRepo.create({
          productId: id,
          tenantId,
          oldPrice: product.basePrice,
          newPrice: dto.basePrice,
          strategy: 'manual',
          changeReason: dto.priceChangeReason || 'Manual update',
          appliedBy: userId,
        }),
      );
    }

    Object.assign(product, dto);
    const saved = await this.productsRepo.save(product);
    await this.invalidateProductCache(tenantId);
    return saved;
  }

  // ── Bulk Update Prices ────────────────────────────────────
  async bulkUpdatePrices(tenantId: string, dto: BulkUpdatePriceDto) {
    const qr = this.dataSource.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();

    try {
      const updated = [];
      for (const item of dto.updates) {
        const product = await qr.manager.findOne(Product, {
          where: { id: item.productId, tenantId },
        });
        if (!product) continue;

        await qr.manager.save(PricingHistory, {
          productId: item.productId,
          tenantId,
          oldPrice: product.basePrice,
          newPrice: item.price,
          strategy: dto.strategy,
          changeReason: dto.reason,
        });

        await qr.manager.update(Product, { id: item.productId, tenantId }, {
          basePrice: item.price,
        });
        updated.push(item.productId);
      }

      await qr.commitTransaction();
      await this.invalidateProductCache(tenantId);
      return { updated: updated.length, productIds: updated };
    } catch (e) {
      await qr.rollbackTransaction();
      throw e;
    } finally {
      await qr.release();
    }
  }

  // ── Import from Supplier ──────────────────────────────────
  async importFromSupplier(tenantId: string, supplierId: string, productIds: string[]) {
    const job = await this.aiQueue.add('import_supplier_products', {
      tenantId,
      supplierId,
      productIds,
    }, { priority: 3 });

    return { jobId: job.id, message: 'Import queued', productCount: productIds.length };
  }

  // ── Analytics ─────────────────────────────────────────────
  async getAnalytics(tenantId: string) {
    return this.dataSource.query(
      `
      SELECT
        COUNT(*) as total_products,
        COUNT(*) FILTER (WHERE status = 'active') as active_products,
        COUNT(*) FILTER (WHERE status = 'out_of_stock') as out_of_stock,
        COUNT(*) FILTER (WHERE stock_quantity <= low_stock_threshold) as low_stock,
        AVG(base_price) as avg_price,
        SUM(sales_count) as total_sales,
        AVG(ai_score) as avg_ai_score
      FROM products
      WHERE tenant_id = $1 AND deleted_at IS NULL
      `,
      [tenantId],
    );
  }

  // ── Trigger AI Analysis ───────────────────────────────────
  async triggerAiAnalysis(tenantId: string, productId: string) {
    await this.findOne(tenantId, productId); // validates exists

    const job = await this.aiQueue.add('analyze_product', {
      productId,
      tenantId,
      priority: 'high',
    });

    return { jobId: job.id, message: 'AI analysis queued' };
  }

  // ── Get Pricing History ───────────────────────────────────
  async getPricingHistory(tenantId: string, productId: string) {
    return this.pricingRepo.find({
      where: { productId, tenantId },
      order: { createdAt: 'DESC' },
      take: 50,
    });
  }

  // ── Get Variants ──────────────────────────────────────────
  async getVariants(tenantId: string, productId: string) {
    return this.variantsRepo.find({
      where: { productId, tenantId },
      order: { createdAt: 'ASC' },
    });
  }

  // ── Status ────────────────────────────────────────────────
  async updateStatus(tenantId: string, id: string, status: string) {
    await this.productsRepo.update({ id, tenantId }, { status: status as any });
    await this.invalidateProductCache(tenantId);
    return { success: true };
  }

  // ── Soft Delete ───────────────────────────────────────────
  async softDelete(tenantId: string, id: string) {
    await this.findOne(tenantId, id);
    await this.productsRepo.update({ id, tenantId }, { deletedAt: new Date() });
    await this.invalidateProductCache(tenantId);
  }

  // ── Cache invalidation ────────────────────────────────────
  private async invalidateProductCache(tenantId: string) {
    const keys = await this.cache.store.keys?.(`products:${tenantId}:*`) || [];
    await Promise.all([
      ...keys.map((k) => this.cache.del(k)),
      this.cache.del(`products:trending:${tenantId}`),
    ]);
  }
}
