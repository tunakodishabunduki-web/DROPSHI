// ─── trend.entity.ts ──────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';
import { Product } from '../../products/entities/product.entity';
import { ManyToOne, JoinColumn } from 'typeorm';

@Entity('trends')
export class Trend {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id', nullable: true }) tenantId: string;
  @Column({ name: 'product_id', nullable: true }) productId: string;
  @Column({ length: 255 }) keyword: string;
  @Column({ length: 100 }) platform: string;
  @Column({ type: 'numeric', precision: 5, scale: 2 }) score: number;
  @Column({ name: 'search_volume', type: 'bigint', nullable: true }) searchVolume: number;
  @Column({ name: 'growth_rate', type: 'numeric', precision: 6, scale: 2, nullable: true }) growthRate: number;
  @Column({ nullable: true }) sentiment: number;
  @Column({ nullable: true }) category: string;
  @Column({ name: 'data_snapshot', type: 'jsonb', default: {} }) dataSnapshot: object;
  @Column({ name: 'recorded_at', default: () => 'NOW()' }) recordedAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @ManyToOne(() => Product, { nullable: true }) @JoinColumn({ name: 'product_id' }) product: Product;
}

// ─── ad.entity.ts ─────────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('ads')
export class Ad {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'product_id', nullable: true }) productId: string;
  @Column({ name: 'campaign_name', length: 255 }) campaignName: string;
  @Column() platform: string;
  @Column({ default: 'draft' }) status: string;
  @Column({ name: 'ad_type', length: 50 }) adType: string;
  @Column({ nullable: true }) headline: string;
  @Column({ name: 'body_copy', type: 'text', nullable: true }) bodyCopy: string;
  @Column({ nullable: true }) cta: string;
  @Column({ name: 'media_urls', type: 'jsonb', default: [] }) mediaUrls: string[];
  @Column({ name: 'target_audience', type: 'jsonb', default: {} }) targetAudience: object;
  @Column({ type: 'numeric', precision: 10, scale: 2, nullable: true }) budget: number;
  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 }) spent: number;
  @Column({ type: 'bigint', default: 0 }) impressions: number;
  @Column({ type: 'bigint', default: 0 }) clicks: number;
  @Column({ type: 'bigint', default: 0 }) conversions: number;
  @Column({ type: 'numeric', precision: 8, scale: 2, nullable: true }) roas: number;
  @Column({ name: 'ai_generated', default: false }) aiGenerated: boolean;
  @Column({ name: 'ab_test_id', nullable: true }) abTestId: string;
  @Column({ name: 'ab_variant', nullable: true }) abVariant: string;
  @Column({ name: 'ai_score', type: 'numeric', precision: 5, scale: 2, nullable: true }) aiScore: number;
  @Column({ name: 'starts_at', nullable: true }) startsAt: Date;
  @Column({ name: 'ends_at', nullable: true }) endsAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── pricing-history.entity.ts ────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('pricing_history')
export class PricingHistory {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'product_id' }) productId: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'old_price', type: 'numeric', precision: 10, scale: 2 }) oldPrice: number;
  @Column({ name: 'new_price', type: 'numeric', precision: 10, scale: 2 }) newPrice: number;
  @Column({ length: 50 }) strategy: string;
  @Column({ name: 'change_reason', nullable: true }) changeReason: string;
  @Column({ name: 'ai_confidence', type: 'numeric', precision: 3, scale: 2, nullable: true }) aiConfidence: number;
  @Column({ name: 'competitor_data', type: 'jsonb', nullable: true }) competitorData: object;
  @Column({ default: false }) simulated: boolean;
  @Column({ name: 'applied_by', nullable: true }) appliedBy: string;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}

// ─── product-variant.entity.ts ────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';

@Entity('product_variants')
export class ProductVariant {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'product_id' }) productId: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 100 }) sku: string;
  @Column({ length: 255 }) name: string;
  @Column({ type: 'jsonb', default: {} }) attributes: object;
  @Column({ type: 'numeric', precision: 10, scale: 2 }) price: number;
  @Column({ name: 'cost_price', type: 'numeric', precision: 10, scale: 2, default: 0 }) costPrice: number;
  @Column({ name: 'stock_quantity', default: 0 }) stockQuantity: number;
  @Column({ name: 'image_url', nullable: true }) imageUrl: string;
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── tenant.entity.ts ─────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('tenants')
export class Tenant {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ length: 255 }) name: string;
  @Column({ length: 100, unique: true }) slug: string;
  @Column({ default: 'free' }) plan: string;
  @Column({ nullable: true }) domain: string;
  @Column({ name: 'logo_url', nullable: true }) logoUrl: string;
  @Column({ default: 'USD' }) currency: string;
  @Column({ default: 'UTC' }) timezone: string;
  @Column({ default: 'en' }) locale: string;
  @Column({ type: 'jsonb', default: {} }) settings: object;
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @Column({ name: 'trial_ends_at', nullable: true }) trialEndsAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── category.entity.ts ───────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';

@Entity('categories')
export class Category {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'parent_id', nullable: true }) parentId: string;
  @Column({ length: 255 }) name: string;
  @Column({ length: 255 }) slug: string;
  @Column({ nullable: true }) description: string;
  @Column({ name: 'image_url', nullable: true }) imageUrl: string;
  @Column({ name: 'sort_order', default: 0 }) sortOrder: number;
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
