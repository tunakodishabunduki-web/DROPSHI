// ─── supplier.entity.ts ───────────────────────────────────────────────────────
import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn,
} from 'typeorm';

@Entity('suppliers')
export class Supplier {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 255 }) name: string;
  @Column({ length: 100 }) slug: string;
  @Column({ type: 'text', nullable: true }) description: string;
  @Column({ name: 'logo_url', nullable: true }) logoUrl: string;
  @Column({ nullable: true }) website: string;
  @Column({ name: 'api_type', length: 50 }) apiType: string;
  @Column({ name: 'api_credentials', type: 'jsonb', nullable: true }) apiCredentials: object;
  @Column({ name: 'contact_email', nullable: true }) contactEmail: string;
  @Column({ nullable: true }) country: string;
  @Column({ default: 'pending_review' }) status: string;
  @Column({ name: 'reliability_score', type: 'numeric', precision: 3, scale: 2, default: 0 }) reliabilityScore: number;
  @Column({ name: 'avg_ship_days', nullable: true }) avgShipDays: number;
  @Column({ name: 'is_primary', default: false }) isPrimary: boolean;
  @Column({ name: 'failover_supplier_id', nullable: true }) failoverSupplierId: string;
  @Column({ name: 'sync_frequency', default: 60 }) syncFrequency: number;
  @Column({ name: 'last_synced_at', nullable: true }) lastSyncedAt: Date;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
