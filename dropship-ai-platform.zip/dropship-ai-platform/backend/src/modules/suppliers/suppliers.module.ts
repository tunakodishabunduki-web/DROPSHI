// ─── suppliers.module.ts ──────────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SuppliersController } from './suppliers.controller';
import { SuppliersService } from './suppliers.service';
import { Supplier } from './entities/supplier.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Supplier])],
  controllers: [SuppliersController],
  providers: [SuppliersService],
  exports: [SuppliersService],
})
export class SuppliersModule {}

// ─── suppliers.service.ts ─────────────────────────────────────────────────────
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Supplier } from './entities/supplier.entity';

@Injectable()
export class SuppliersService {
  constructor(@InjectRepository(Supplier) private repo: Repository<Supplier>) {}

  findAll(tenantId: string, query: any = {}) {
    return this.repo.find({ where: { tenantId }, order: { isPrimary: 'DESC', name: 'ASC' } });
  }

  async findOne(tenantId: string, id: string) {
    const s = await this.repo.findOne({ where: { id, tenantId } });
    if (!s) throw new NotFoundException('Supplier not found');
    return s;
  }

  create(tenantId: string, dto: any) {
    const supplier = this.repo.create({ ...dto, tenantId });
    return this.repo.save(supplier);
  }

  async update(tenantId: string, id: string, dto: any) {
    await this.findOne(tenantId, id);
    await this.repo.update({ id, tenantId }, dto);
    return this.findOne(tenantId, id);
  }

  async remove(tenantId: string, id: string) {
    await this.findOne(tenantId, id);
    await this.repo.delete({ id, tenantId });
  }
}

// ─── suppliers.controller.ts ──────────────────────────────────────────────────
import { Controller, Get, Post, Put, Delete, Param, Body, UseGuards, ParseUUIDPipe, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { SuppliersService } from './suppliers.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('suppliers') @ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'suppliers', version: '1' })
export class SuppliersController {
  constructor(private svc: SuppliersService) {}
  @Get() findAll(@CurrentTenant() t: string) { return this.svc.findAll(t); }
  @Get(':id') findOne(@Param('id', ParseUUIDPipe) id: string, @CurrentTenant() t: string) { return this.svc.findOne(t, id); }
  @Post() @Roles('tenant_admin','manager') @HttpCode(HttpStatus.CREATED) create(@Body() dto: any, @CurrentTenant() t: string) { return this.svc.create(t, dto); }
  @Put(':id') @Roles('tenant_admin','manager') update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any, @CurrentTenant() t: string) { return this.svc.update(t, id, dto); }
  @Delete(':id') @Roles('tenant_admin') @HttpCode(HttpStatus.NO_CONTENT) remove(@Param('id', ParseUUIDPipe) id: string, @CurrentTenant() t: string) { return this.svc.remove(t, id); }
}
