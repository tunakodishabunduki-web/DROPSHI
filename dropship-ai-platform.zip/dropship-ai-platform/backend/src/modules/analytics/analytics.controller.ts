// ─── analytics.controller.ts ──────────────────────────────────────────────────
import { Controller, Get, Query, UseGuards, Res } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { Response } from 'express';
import { AnalyticsService } from './analytics.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';
import { downloadBlob } from '../../common/utils/download';

@ApiTags('analytics') @ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller({ path: 'analytics', version: '1' })
export class AnalyticsController {
  constructor(private svc: AnalyticsService) {}

  @Get('dashboard')
  dashboard(@CurrentTenant() t: string) { return this.svc.getDashboardStats(t); }

  @Get('sales-timeseries')
  timeSeries(@CurrentTenant() t: string, @Query('period') period: any = '30d') {
    return this.svc.getSalesTimeSeries(t, period);
  }

  @Get('top-products')
  topProducts(@CurrentTenant() t: string, @Query('limit') limit = 10) {
    return this.svc.getTopProducts(t, +limit);
  }

  @Get('ads')
  adPerformance(@CurrentTenant() t: string, @Query('period') period = '30d') {
    return this.svc.getAdPerformance(t, period);
  }

  @Get('suppliers')
  supplierPerf(@CurrentTenant() t: string) { return this.svc.getSupplierPerformance(t); }

  @Get('export/orders')
  async exportOrders(
    @CurrentTenant() t: string,
    @Query('dateFrom') dateFrom: string,
    @Query('dateTo') dateTo: string,
    @Res() res: Response,
  ) {
    const csv = await this.svc.exportOrdersCsv(t, new Date(dateFrom), new Date(dateTo));
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="orders-${Date.now()}.csv"`);
    res.send(csv);
  }
}
