import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { AnalyticsDaily } from './entities/analytics-daily.entity';
import { Order } from '../orders/entities/order.entity';
import { AiLog } from '../ai/entities/ai-log.entity';

@Injectable()
export class AnalyticsService {
  constructor(
    @InjectRepository(AnalyticsDaily) private analyticsRepo: Repository<AnalyticsDaily>,
    private dataSource: DataSource,
  ) {}

  // ── Dashboard Overview ────────────────────────────────────
  async getDashboardStats(tenantId: string) {
    const [
      revenueStats, orderStats, productStats,
      customerStats, aiStats, recentOrders,
    ] = await Promise.all([
      this.getRevenueStats(tenantId),
      this.getOrderStats(tenantId),
      this.getProductStats(tenantId),
      this.getCustomerStats(tenantId),
      this.getAiStats(tenantId),
      this.getRecentOrders(tenantId),
    ]);

    return {
      revenue: revenueStats,
      orders: orderStats,
      products: productStats,
      customers: customerStats,
      ai: aiStats,
      recentOrders,
    };
  }

  // ── Revenue Stats ─────────────────────────────────────────
  async getRevenueStats(tenantId: string) {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

    const [current, previous] = await Promise.all([
      this.dataSource.query(
        `SELECT COALESCE(SUM(total), 0) as revenue, COUNT(*) as orders
         FROM orders WHERE tenant_id = $1 AND created_at >= $2
         AND status NOT IN ('cancelled', 'refunded')`,
        [tenantId, thirtyDaysAgo],
      ),
      this.dataSource.query(
        `SELECT COALESCE(SUM(total), 0) as revenue, COUNT(*) as orders
         FROM orders WHERE tenant_id = $1 AND created_at BETWEEN $2 AND $3
         AND status NOT IN ('cancelled', 'refunded')`,
        [tenantId, sixtyDaysAgo, thirtyDaysAgo],
      ),
    ]);

    const currentRevenue = parseFloat(current[0]?.revenue || 0);
    const previousRevenue = parseFloat(previous[0]?.revenue || 0);
    const growth = previousRevenue > 0
      ? ((currentRevenue - previousRevenue) / previousRevenue) * 100
      : 0;

    return {
      current: currentRevenue,
      previous: previousRevenue,
      growth: parseFloat(growth.toFixed(2)),
      orders: parseInt(current[0]?.orders || 0),
    };
  }

  // ── Order Stats ───────────────────────────────────────────
  async getOrderStats(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        status,
        COUNT(*) as count,
        SUM(total) as total_value
       FROM orders
       WHERE tenant_id = $1
         AND created_at >= NOW() - INTERVAL '30 days'
       GROUP BY status`,
      [tenantId],
    );
  }

  // ── Sales Over Time ───────────────────────────────────────
  async getSalesTimeSeries(tenantId: string, period: '7d' | '30d' | '90d' | '1y' = '30d') {
    const intervals: Record<string, string> = {
      '7d': '7 days', '30d': '30 days', '90d': '90 days', '1y': '1 year',
    };
    const truncBy: Record<string, string> = {
      '7d': 'day', '30d': 'day', '90d': 'week', '1y': 'month',
    };

    return this.dataSource.query(
      `SELECT
        DATE_TRUNC($3, created_at) as period,
        COALESCE(SUM(total), 0) as revenue,
        COUNT(*) as orders,
        AVG(total) as avg_order_value
       FROM orders
       WHERE tenant_id = $1
         AND created_at >= NOW() - INTERVAL '${intervals[period]}'
         AND status NOT IN ('cancelled', 'refunded')
       GROUP BY DATE_TRUNC($3, created_at)
       ORDER BY period ASC`,
      [tenantId, intervals[period], truncBy[period]],
    );
  }

  // ── Top Products ──────────────────────────────────────────
  async getTopProducts(tenantId: string, limit = 10) {
    return this.dataSource.query(
      `SELECT
        p.id, p.name, p.images, p.base_price,
        COUNT(oi.id) as order_count,
        SUM(oi.quantity) as units_sold,
        SUM(oi.total) as total_revenue,
        AVG(oi.unit_price - oi.cost_price) as avg_profit
       FROM order_items oi
       JOIN products p ON p.id = oi.product_id
       JOIN orders o ON o.id = oi.order_id
       WHERE oi.tenant_id = $1
         AND o.status NOT IN ('cancelled', 'refunded')
         AND o.created_at >= NOW() - INTERVAL '30 days'
       GROUP BY p.id, p.name, p.images, p.base_price
       ORDER BY total_revenue DESC
       LIMIT $2`,
      [tenantId, limit],
    );
  }

  // ── Product Stats ─────────────────────────────────────────
  async getProductStats(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'active') as active,
        COUNT(*) FILTER (WHERE status = 'out_of_stock') as out_of_stock,
        COUNT(*) FILTER (WHERE stock_quantity <= low_stock_threshold AND status = 'active') as low_stock,
        AVG(ai_score) FILTER (WHERE ai_score IS NOT NULL) as avg_ai_score
       FROM products WHERE tenant_id = $1 AND deleted_at IS NULL`,
      [tenantId],
    );
  }

  // ── Customer Stats ────────────────────────────────────────
  async getCustomerStats(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days') as new_this_month,
        AVG(total_spent) as avg_lifetime_value,
        AVG(order_count) as avg_orders_per_customer,
        COUNT(*) FILTER (WHERE order_count > 1) as returning_customers
       FROM customers WHERE tenant_id = $1`,
      [tenantId],
    );
  }

  // ── AI Performance Stats ──────────────────────────────────
  async getAiStats(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        module,
        COUNT(*) as total_tasks,
        COUNT(*) FILTER (WHERE status = 'completed') as completed,
        COUNT(*) FILTER (WHERE status = 'failed') as failed,
        AVG(duration_ms) as avg_duration_ms,
        SUM(tokens_used) as total_tokens,
        SUM(cost_usd) as total_cost
       FROM ai_logs
       WHERE tenant_id = $1
         AND created_at >= NOW() - INTERVAL '30 days'
       GROUP BY module`,
      [tenantId],
    );
  }

  // ── Recent Orders ─────────────────────────────────────────
  async getRecentOrders(tenantId: string, limit = 10) {
    return this.dataSource.query(
      `SELECT o.id, o.order_number, o.total, o.status, o.created_at,
              c.email as customer_email,
              CONCAT(c.first_name, ' ', c.last_name) as customer_name
       FROM orders o
       LEFT JOIN customers c ON c.id = o.customer_id
       WHERE o.tenant_id = $1
       ORDER BY o.created_at DESC
       LIMIT $2`,
      [tenantId, limit],
    );
  }

  // ── Supplier Performance ───────────────────────────────────
  async getSupplierPerformance(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        s.id, s.name, s.reliability_score,
        COUNT(oi.id) as items_fulfilled,
        AVG(EXTRACT(EPOCH FROM (o.shipped_at - o.created_at))/86400) as avg_processing_days
       FROM suppliers s
       LEFT JOIN order_items oi ON oi.supplier_id = s.id
       LEFT JOIN orders o ON o.id = oi.order_id
       WHERE s.tenant_id = $1
       GROUP BY s.id, s.name, s.reliability_score
       ORDER BY items_fulfilled DESC`,
      [tenantId],
    );
  }

  // ── Ad Performance ────────────────────────────────────────
  async getAdPerformance(tenantId: string, period = '30d') {
    return this.dataSource.query(
      `SELECT
        platform,
        SUM(impressions) as impressions,
        SUM(clicks) as clicks,
        SUM(conversions) as conversions,
        SUM(spent) as spent,
        CASE WHEN SUM(impressions) > 0 THEN SUM(clicks)::NUMERIC/SUM(impressions) ELSE 0 END as ctr,
        AVG(roas) as avg_roas
       FROM ads
       WHERE tenant_id = $1
         AND created_at >= NOW() - INTERVAL '30 days'
       GROUP BY platform`,
      [tenantId],
    );
  }

  // ── Aggregate Daily Stats (cron job) ──────────────────────
  async aggregateDailyStats(tenantId: string, date: Date) {
    const dateStr = date.toISOString().split('T')[0];

    const stats = await this.dataSource.query(
      `SELECT
        COALESCE(SUM(o.total), 0) as revenue,
        COUNT(DISTINCT o.id) as orders_count,
        COALESCE(AVG(o.total), 0) as avg_order_value,
        COUNT(DISTINCT CASE WHEN c.created_at::date = $2 THEN c.id END) as new_customers,
        COUNT(DISTINCT CASE WHEN c.order_count > 1 THEN c.id END) as returning_customers,
        COALESCE(SUM(oi.quantity), 0) as products_sold,
        COALESCE(SUM(CASE WHEN o.status = 'refunded' THEN o.refund_amount ELSE 0 END), 0) as refund_amount
       FROM orders o
       LEFT JOIN customers c ON c.id = o.customer_id
       LEFT JOIN order_items oi ON oi.order_id = o.id
       WHERE o.tenant_id = $1
         AND o.created_at::date = $2`,
      [tenantId, dateStr],
    );

    await this.analyticsRepo
      .createQueryBuilder()
      .insert()
      .values({
        tenantId,
        date: new Date(dateStr),
        revenue: stats[0]?.revenue || 0,
        ordersCount: stats[0]?.orders_count || 0,
        avgOrderValue: stats[0]?.avg_order_value || 0,
        newCustomers: stats[0]?.new_customers || 0,
        returningCustomers: stats[0]?.returning_customers || 0,
        productsSold: stats[0]?.products_sold || 0,
        refundAmount: stats[0]?.refund_amount || 0,
      })
      .orUpdate(['revenue', 'orders_count', 'avg_order_value', 'new_customers'], ['tenant_id', 'date'])
      .execute();
  }

  // ── Export CSV ────────────────────────────────────────────
  async exportOrdersCsv(tenantId: string, dateFrom: Date, dateTo: Date): Promise<string> {
    const orders = await this.dataSource.query(
      `SELECT o.order_number, o.status, o.total, o.currency, o.created_at,
              c.email, c.first_name, c.last_name
       FROM orders o
       LEFT JOIN customers c ON c.id = o.customer_id
       WHERE o.tenant_id = $1 AND o.created_at BETWEEN $2 AND $3
       ORDER BY o.created_at DESC`,
      [tenantId, dateFrom, dateTo],
    );

    const headers = ['Order #', 'Status', 'Total', 'Currency', 'Date', 'Customer Email', 'Customer Name'];
    const rows = orders.map((o: any) => [
      o.order_number, o.status, o.total, o.currency,
      o.created_at, o.email, `${o.first_name} ${o.last_name}`,
    ]);

    return [headers, ...rows]
      .map((r) => r.map((v: any) => `"${v || ''}"`).join(','))
      .join('\n');
  }
}
