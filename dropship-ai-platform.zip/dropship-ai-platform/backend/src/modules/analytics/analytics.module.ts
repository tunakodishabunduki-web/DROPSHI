// ─── analytics.module.ts ──────────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AnalyticsController } from './analytics.controller';
import { AnalyticsService } from './analytics.service';
import { AnalyticsDaily } from './entities/analytics-daily.entity';
import { ScheduleModule } from '@nestjs/schedule';

@Module({
  imports: [TypeOrmModule.forFeature([AnalyticsDaily])],
  controllers: [AnalyticsController],
  providers: [AnalyticsService],
  exports: [AnalyticsService],
})
export class AnalyticsModule {}

// ─── analytics-daily.entity.ts ────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, Unique } from 'typeorm';

@Entity('analytics_daily')
@Unique(['tenantId', 'date'])
export class AnalyticsDaily {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ type: 'date' }) date: Date;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) revenue: number;
  @Column({ name: 'orders_count', default: 0 }) ordersCount: number;
  @Column({ name: 'avg_order_value', type: 'numeric', precision: 10, scale: 2, default: 0 }) avgOrderValue: number;
  @Column({ name: 'new_customers', default: 0 }) newCustomers: number;
  @Column({ name: 'returning_customers', default: 0 }) returningCustomers: number;
  @Column({ name: 'products_sold', default: 0 }) productsSold: number;
  @Column({ name: 'refund_amount', type: 'numeric', precision: 12, scale: 2, default: 0 }) refundAmount: number;
  @Column({ name: 'ad_spend', type: 'numeric', precision: 12, scale: 2, default: 0 }) adSpend: number;
  @Column({ name: 'top_products', type: 'jsonb', default: [] }) topProducts: object[];
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
