import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';
import { Ad } from '../../ads/entities/ad.entity';
import { Product } from '../../products/entities/product.entity';

export interface GenerateAdDto {
  productId: string;
  platforms: ('tiktok' | 'instagram' | 'facebook' | 'google')[];
  tone: 'urgent' | 'playful' | 'professional' | 'luxury' | 'minimal';
  targetAudience: {
    ageRange?: string;
    interests?: string[];
    gender?: string;
    location?: string[];
  };
  budget?: number;
  generateVariants?: number;
}

@Injectable()
export class MarketingAiService {
  private readonly logger = new Logger(MarketingAiService.name);
  private openai: OpenAI;

  constructor(
    @InjectRepository(Ad) private adsRepo: Repository<Ad>,
    @InjectRepository(Product) private productsRepo: Repository<Product>,
    @InjectQueue('marketing_campaign_queue') private marketingQueue: Queue,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Generate Ad Copy ──────────────────────────────────────
  async generateAdCopy(tenantId: string, dto: GenerateAdDto) {
    const product = await this.productsRepo.findOne({
      where: { id: dto.productId, tenantId },
      relations: ['category'],
    });
    if (!product) throw new Error('Product not found');

    const creatives = await Promise.all(
      dto.platforms.map((platform) =>
        this.generateForPlatform(product, platform, dto),
      ),
    );

    // Save to DB
    const savedAds = await Promise.all(
      creatives.map(async (creative) => {
        const ad = this.adsRepo.create({
          tenantId,
          productId: product.id,
          campaignName: `AI Campaign - ${product.name} - ${creative.platform}`,
          platform: creative.platform as any,
          status: 'draft',
          adType: 'image',
          headline: creative.headline,
          bodyCopy: creative.body,
          cta: creative.cta,
          targetAudience: dto.targetAudience as any,
          budget: dto.budget,
          aiGenerated: true,
          aiScore: creative.score,
        });
        return this.adsRepo.save(ad);
      }),
    );

    return {
      ads: savedAds,
      creatives,
      productName: product.name,
    };
  }

  // ── Generate A/B Test Variants ────────────────────────────
  async generateABVariants(tenantId: string, adId: string, variantCount = 3) {
    const baseAd = await this.adsRepo.findOne({ where: { id: adId, tenantId } });
    if (!baseAd) throw new Error('Ad not found');

    const abTestId = `ab_${Date.now()}`;
    const variants = [];

    for (let i = 0; i < variantCount; i++) {
      const prompt = `
Create ad copy variant ${i + 1} for "${baseAd.campaignName}".
Base headline: "${baseAd.headline}"
Base body: "${baseAd.bodyCopy}"
Platform: ${baseAd.platform}

Create a meaningfully different variant that tests a different angle:
- Variant A: Benefit-focused
- Variant B: Fear of missing out (FOMO)
- Variant C: Social proof

Return JSON: {headline, body, cta, angle}`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        max_tokens: 400,
      });

      const variant = JSON.parse(response.choices[0].message.content);
      const saved = await this.adsRepo.save(this.adsRepo.create({
        ...baseAd,
        id: undefined,
        campaignName: `${baseAd.campaignName} (Variant ${String.fromCharCode(65 + i)})`,
        headline: variant.headline,
        bodyCopy: variant.body,
        cta: variant.cta,
        abTestId,
        abVariant: String.fromCharCode(65 + i),
        status: 'draft',
      }));
      variants.push(saved);
    }

    return { abTestId, variants };
  }

  // ── Track Ad Performance ──────────────────────────────────
  async updateAdMetrics(tenantId: string, adId: string, metrics: {
    impressions?: number;
    clicks?: number;
    conversions?: number;
    spent?: number;
    roas?: number;
  }) {
    const ad = await this.adsRepo.findOne({ where: { id: adId, tenantId } });
    if (!ad) throw new Error('Ad not found');

    await this.adsRepo.update({ id: adId, tenantId }, {
      impressions: (ad.impressions || 0) + (metrics.impressions || 0),
      clicks: (ad.clicks || 0) + (metrics.clicks || 0),
      conversions: (ad.conversions || 0) + (metrics.conversions || 0),
      spent: (ad.spent || 0) + (metrics.spent || 0),
      roas: metrics.roas ?? ad.roas,
    });

    // Auto-pause low performers
    await this.checkAndOptimizeAd(adId, tenantId);
    return { success: true };
  }

  // ── Get Campaign Analytics ────────────────────────────────
  async getCampaignAnalytics(tenantId: string, filters?: any) {
    const qb = this.adsRepo.createQueryBuilder('a')
      .where('a.tenantId = :tenantId', { tenantId })
      .select([
        'a.platform',
        'SUM(a.impressions) as total_impressions',
        'SUM(a.clicks) as total_clicks',
        'SUM(a.conversions) as total_conversions',
        'SUM(a.spent) as total_spent',
        'AVG(a.roas) as avg_roas',
        'COUNT(a.id) as ad_count',
      ])
      .groupBy('a.platform');

    return qb.getRawMany();
  }

  // ── Schedule Campaign ─────────────────────────────────────
  async scheduleCampaign(tenantId: string, adId: string, schedule: {
    startsAt: Date;
    endsAt?: Date;
    dailyBudget?: number;
  }) {
    await this.adsRepo.update({ id: adId, tenantId }, {
      status: 'active',
      startsAt: schedule.startsAt,
      endsAt: schedule.endsAt,
      budget: schedule.dailyBudget,
    });

    await this.marketingQueue.add(
      'launch_campaign',
      { tenantId, adId, schedule },
      { delay: Math.max(0, schedule.startsAt.getTime() - Date.now()) },
    );

    return { success: true, scheduledFor: schedule.startsAt };
  }

  // ── Platform-specific generation ──────────────────────────
  private async generateForPlatform(product: Product, platform: string, dto: GenerateAdDto) {
    const platformSpecs: Record<string, any> = {
      tiktok: { maxHeadline: 100, maxBody: 150, format: 'video-optimized, trend-aware, Gen Z friendly' },
      instagram: { maxHeadline: 150, maxBody: 300, format: 'visual-first, aesthetic, aspirational' },
      facebook: { maxHeadline: 255, maxBody: 125, format: 'detailed, benefit-focused, clear CTA' },
      google: { maxHeadline: 30, maxBody: 90, format: 'keyword-rich, direct, actionable' },
    };

    const spec = platformSpecs[platform] || platformSpecs.facebook;

    const prompt = `
Generate high-converting ad copy for ${platform.toUpperCase()}.

Product: ${product.name}
Description: ${product.shortDescription || product.description?.slice(0, 200)}
Price: $${product.basePrice}
Category: ${product.category?.name || 'General'}
Tone: ${dto.tone}
Target Audience: ${JSON.stringify(dto.targetAudience)}

Platform specs: ${spec.format}
Max headline: ${spec.maxHeadline} chars
Max body: ${spec.maxBody} chars

Return JSON:
{
  "platform": "${platform}",
  "headline": "compelling headline",
  "body": "ad body copy",
  "cta": "call to action text",
  "hashtags": ["relevant", "hashtags"],
  "score": 0-100,
  "bestTimeToPost": "e.g. 6-9pm weekdays"
}`;

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      response_format: { type: 'json_object' },
      max_tokens: 500,
    });

    return JSON.parse(response.choices[0].message.content);
  }

  // ── Auto-optimize poor performers ─────────────────────────
  private async checkAndOptimizeAd(adId: string, tenantId: string) {
    const ad = await this.adsRepo.findOne({ where: { id: adId, tenantId } });
    if (!ad || ad.impressions < 1000) return;

    const ctr = (ad.clicks || 0) / ad.impressions;
    if (ctr < 0.005 && ad.status === 'active') {
      // CTR below 0.5% — pause and queue for optimization
      await this.adsRepo.update({ id: adId }, { status: 'paused' });
      await this.marketingQueue.add('optimize_ad', { adId, tenantId, reason: 'low_ctr' });
      this.logger.warn(`Ad ${adId} paused due to low CTR: ${(ctr * 100).toFixed(2)}%`);
    }
  }
}
