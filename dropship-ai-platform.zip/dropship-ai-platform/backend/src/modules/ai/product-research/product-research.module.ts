// ─── product-research.module.ts ───────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { CacheModule } from '@nestjs/cache-manager';
import { ProductResearchService } from './product-research.service';
import { Trend } from '../../trends/entities/trend.entity';
import { Product } from '../../products/entities/product.entity';
import { AiLog } from '../entities/ai-log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Trend, Product, AiLog]),
    BullModule.registerQueue({ name: 'ai_tasks_queue' }),
    CacheModule.register(),
  ],
  providers: [ProductResearchService],
  exports: [ProductResearchService],
})
export class ProductResearchModule {}

// ─── dynamic-pricing.module.ts ────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { DynamicPricingService } from './dynamic-pricing.service';
import { PricingHistory } from '../../products/entities/pricing-history.entity';
import { AiLog } from '../entities/ai-log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Product, PricingHistory, Trend, AiLog]),
    BullModule.registerQueue({ name: 'ai_tasks_queue' }),
  ],
  providers: [DynamicPricingService],
  exports: [DynamicPricingService],
})
export class DynamicPricingModule {}

// ─── marketing-ai.module.ts ───────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { MarketingAiService } from './marketing-ai.service';
import { Ad } from '../../ads/entities/ad.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Ad, Product]),
    BullModule.registerQueue({ name: 'marketing_campaign_queue' }),
  ],
  providers: [MarketingAiService],
  exports: [MarketingAiService],
})
export class MarketingAiModule {}

// ─── customer-support-ai.module.ts ────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomerSupportAiService } from './customer-support-ai.service';
import { SupportTicket } from '../../support/entities/support-ticket.entity';
import { TicketMessage } from '../../support/entities/ticket-message.entity';

@Module({
  imports: [TypeOrmModule.forFeature([SupportTicket, TicketMessage])],
  providers: [CustomerSupportAiService],
  exports: [CustomerSupportAiService],
})
export class CustomerSupportAiModule {}

// ─── supplier-sync.module.ts ──────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { SupplierSyncService } from './supplier-sync.service';
import { Supplier } from '../../suppliers/entities/supplier.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Supplier, Product, AiLog]),
    BullModule.registerQueue({ name: 'supplier_sync_queue' }),
  ],
  providers: [SupplierSyncService],
  exports: [SupplierSyncService],
})
export class SupplierSyncModule {}
