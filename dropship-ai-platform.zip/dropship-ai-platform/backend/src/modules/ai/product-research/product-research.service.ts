import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { Inject } from '@nestjs/common';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import OpenAI from 'openai';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';
import { Trend } from '../../trends/entities/trend.entity';
import { Product } from '../../products/entities/product.entity';
import { AiLog } from '../entities/ai-log.entity';

export interface ResearchResult {
  keyword: string;
  score: number;
  platform: string;
  searchVolume?: number;
  growthRate?: number;
  sentiment?: number;
  category?: string;
  relatedKeywords?: string[];
  topProducts?: any[];
}

@Injectable()
export class ProductResearchService {
  private readonly logger = new Logger(ProductResearchService.name);
  private openai: OpenAI;

  constructor(
    @InjectRepository(Trend) private trendsRepo: Repository<Trend>,
    @InjectRepository(Product) private productsRepo: Repository<Product>,
    @InjectRepository(AiLog) private aiLogsRepo: Repository<AiLog>,
    @InjectQueue('ai_tasks_queue') private aiQueue: Queue,
    @Inject(CACHE_MANAGER) private cache: Cache,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Discover Trending Products ────────────────────────────
  async discoverTrending(tenantId: string, options: {
    category?: string;
    platforms?: string[];
    limit?: number;
    region?: string;
  } = {}) {
    const { category, platforms = ['tiktok', 'instagram', 'amazon'], limit = 20 } = options;
    const cacheKey = `trending:${tenantId}:${category || 'all'}`;

    const cached = await this.cache.get<ResearchResult[]>(cacheKey);
    if (cached) return cached;

    const job = await this.aiQueue.add('discover_trending', {
      tenantId,
      category,
      platforms,
      limit,
    }, { priority: 3 });

    // Return existing trends while new ones are being fetched
    const existingTrends = await this.trendsRepo.find({
      where: tenantId ? { tenantId } : {},
      order: { score: 'DESC', recordedAt: 'DESC' },
      take: limit,
    });

    return { trends: existingTrends, refreshJobId: job.id };
  }

  // ── Analyze Product Viability ─────────────────────────────
  async analyzeProduct(tenantId: string, productId: string) {
    const product = await this.productsRepo.findOne({
      where: { id: productId, tenantId },
    });
    if (!product) throw new Error('Product not found');

    const log = await this.aiLogsRepo.save(
      this.aiLogsRepo.create({
        tenantId,
        module: 'product_research',
        taskType: 'analyze_product',
        status: 'processing',
        referenceId: productId,
        referenceType: 'product',
        inputData: { productId, productName: product.name },
      }),
    );

    try {
      const [trendData, marketData] = await Promise.all([
        this.getTrendScore(product.name),
        this.getMarketData(product.name),
      ]);

      const analysis = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{
          role: 'user',
          content: `Analyze this drop shipping product for viability:
Product: ${product.name}
Category: ${product.category?.name || 'Unknown'}
Price: $${product.basePrice}
Cost: $${product.costPrice}
Margin: ${(((product.basePrice - product.costPrice) / product.basePrice) * 100).toFixed(1)}%

Market Data: ${JSON.stringify(marketData)}
Trend Data: ${JSON.stringify(trendData)}

Score 1-100 and provide:
- viabilityScore (number)
- marketSaturation: low/medium/high
- demandTrend: rising/stable/declining
- competitionLevel: low/medium/high
- recommendedAction: sell/avoid/watchlist/research_more
- pros: string[]
- cons: string[]
- suggestedTargetAudience: string
- seasonality: string
- estimatedMonthlySales: number

JSON only.`,
        }],
        response_format: { type: 'json_object' },
        max_tokens: 800,
      });

      const result = JSON.parse(analysis.choices[0].message.content);
      const aiScore = result.viabilityScore;

      // Update product AI score
      await this.productsRepo.update({ id: productId }, {
        aiScore,
        aiTags: [
          result.recommendedAction,
          result.marketSaturation,
          result.demandTrend,
        ],
        aiLastAnalyzedAt: new Date(),
      });

      // Save trend record
      await this.trendsRepo.save(
        this.trendsRepo.create({
          tenantId,
          productId,
          keyword: product.name,
          platform: 'internal',
          score: aiScore,
          growthRate: trendData.growthRate,
          sentiment: trendData.sentiment,
          category: product.category?.name,
          dataSnapshot: result,
        }),
      );

      await this.aiLogsRepo.update(log.id, {
        status: 'completed',
        outputData: result,
        completedAt: new Date(),
      });

      return { productId, aiScore, analysis: result };
    } catch (error) {
      await this.aiLogsRepo.update(log.id, {
        status: 'failed',
        errorMessage: error.message,
        completedAt: new Date(),
      });
      throw error;
    }
  }

  // ── Keyword Research ──────────────────────────────────────
  async researchKeywords(tenantId: string, seed: string) {
    const cacheKey = `keywords:${seed}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) return cached;

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{
        role: 'user',
        content: `Generate 15 high-value e-commerce keywords for "${seed}".
Focus on buying intent, long-tail variations, and trending searches.
Return JSON: {
  keywords: [{keyword, searchVolume: "estimate", competition: low/med/high, intent: informational/commercial/transactional, trend: rising/stable/declining}]
}`,
      }],
      response_format: { type: 'json_object' },
      max_tokens: 600,
    });

    const result = JSON.parse(response.choices[0].message.content);
    await this.cache.set(cacheKey, result, 3600); // 1 hour
    return result;
  }

  // ── Get Top Trends ────────────────────────────────────────
  async getTopTrends(tenantId: string, limit = 20) {
    return this.trendsRepo.find({
      order: { score: 'DESC', recordedAt: 'DESC' },
      take: limit,
      relations: ['product'],
    });
  }

  // ── Competitor Analysis ───────────────────────────────────
  async analyzeCompetitors(productName: string) {
    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{
        role: 'user',
        content: `Analyze competitive landscape for "${productName}" in drop shipping.
Return JSON: {
  marketOverview: string,
  priceRange: {min: number, max: number, avg: number},
  topCompetitors: [{name, estimatedMarketShare, strengths, weaknesses}],
  differentiationOpportunities: string[],
  saturationLevel: low/medium/high,
  recommendedNiche: string
}`,
      }],
      response_format: { type: 'json_object' },
      max_tokens: 700,
    });

    return JSON.parse(response.choices[0].message.content);
  }

  // ── Helpers ───────────────────────────────────────────────
  private async getTrendScore(keyword: string) {
    // In production: integrate with Google Trends API, TikTok API, etc.
    const cached = await this.trendsRepo.findOne({
      where: { keyword },
      order: { recordedAt: 'DESC' },
    });

    if (cached) {
      return { score: cached.score, growthRate: cached.growthRate, sentiment: cached.sentiment };
    }

    // Fallback: use AI to estimate
    const estimate = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{
        role: 'user',
        content: `Estimate trend metrics for "${keyword}" as a consumer product in 2025-2026.
JSON: {score: 0-100, growthRate: percentage, sentiment: -1 to 1, platforms: string[]}`,
      }],
      response_format: { type: 'json_object' },
      max_tokens: 150,
    });

    return JSON.parse(estimate.choices[0].message.content);
  }

  private async getMarketData(productName: string) {
    return {
      estimatedMonthlySearches: Math.floor(Math.random() * 50000) + 1000,
      avgCPC: (Math.random() * 2 + 0.3).toFixed(2),
      competitorCount: Math.floor(Math.random() * 500) + 10,
    };
  }
}
