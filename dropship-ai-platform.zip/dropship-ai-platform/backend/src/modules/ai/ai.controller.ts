import {
  Controller, Get, Post, Patch, Body, Param,
  Query, UseGuards, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';
import { ProductResearchService } from './product-research/product-research.service';
import { DynamicPricingService } from './dynamic-pricing/dynamic-pricing.service';
import { MarketingAiService } from './marketing/marketing-ai.service';
import { CustomerSupportAiService } from './customer-support/customer-support-ai.service';
import { SupplierSyncService } from './supplier-sync/supplier-sync.service';
import { AiService } from './ai.service';

@ApiTags('ai')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'ai', version: '1' })
export class AiController {
  constructor(
    private researchSvc: ProductResearchService,
    private pricingSvc: DynamicPricingService,
    private marketingSvc: MarketingAiService,
    private supportSvc: CustomerSupportAiService,
    private supplierSvc: SupplierSyncService,
    private aiSvc: AiService,
  ) {}

  // ── Product Research ─────────────────────────────────────
  @Get('research/trending')
  @ApiOperation({ summary: 'Discover trending products via AI' })
  discoverTrending(@CurrentTenant() t: string, @Query() opts: any) {
    return this.researchSvc.discoverTrending(t, opts);
  }

  @Post('research/analyze/:productId')
  @ApiOperation({ summary: 'AI viability analysis for a product' })
  analyzeProduct(
    @Param('productId', ParseUUIDPipe) productId: string,
    @CurrentTenant() t: string,
  ) {
    return this.researchSvc.analyzeProduct(t, productId);
  }

  @Get('research/keywords')
  @ApiOperation({ summary: 'Keyword research for a seed term' })
  researchKeywords(@CurrentTenant() t: string, @Query('seed') seed: string) {
    return this.researchSvc.researchKeywords(t, seed);
  }

  @Post('research/competitors')
  @ApiOperation({ summary: 'Competitor analysis for product name' })
  analyzeCompetitors(@Body('productName') productName: string) {
    return this.researchSvc.analyzeCompetitors(productName);
  }

  // ── Dynamic Pricing ──────────────────────────────────────
  @Get('pricing/suggest/:productId')
  @ApiOperation({ summary: 'Get AI price suggestion' })
  suggestPrice(
    @Param('productId', ParseUUIDPipe) productId: string,
    @Query('strategy') strategy: any,
    @CurrentTenant() t: string,
  ) {
    return this.pricingSvc.suggestPrice(t, productId, strategy);
  }

  @Post('pricing/apply/:productId')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Apply suggested price to product' })
  applyPrice(
    @Param('productId', ParseUUIDPipe) productId: string,
    @Body() body: { newPrice: number; strategy: string; reason: string },
    @CurrentTenant() t: string,
  ) {
    return this.pricingSvc.applyPrice(t, productId, body.newPrice, body.strategy, body.reason);
  }

  @Post('pricing/simulate/:productId')
  @ApiOperation({ summary: 'Simulate revenue impact of price change' })
  simulateImpact(
    @Param('productId', ParseUUIDPipe) productId: string,
    @Body('newPrice') newPrice: number,
    @CurrentTenant() t: string,
  ) {
    return this.pricingSvc.simulateImpact(t, productId, newPrice);
  }

  @Post('pricing/batch')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Run batch AI pricing across all active products' })
  batchPricing(
    @Body('strategy') strategy: any,
    @CurrentTenant() t: string,
  ) {
    return this.pricingSvc.runBatchPricing(t, strategy);
  }

  // ── Marketing AI ─────────────────────────────────────────
  @Post('marketing/generate-ad')
  @ApiOperation({ summary: 'Generate AI ad copy for multiple platforms' })
  generateAd(@Body() dto: any, @CurrentTenant() t: string) {
    return this.marketingSvc.generateAdCopy(t, dto);
  }

  @Post('marketing/ab-variants/:adId')
  @ApiOperation({ summary: 'Generate A/B test variants for an ad' })
  generateVariants(
    @Param('adId', ParseUUIDPipe) adId: string,
    @Body('count') count: number,
    @CurrentTenant() t: string,
  ) {
    return this.marketingSvc.generateABVariants(t, adId, count);
  }

  @Post('marketing/schedule/:adId')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Schedule ad campaign' })
  scheduleCampaign(
    @Param('adId', ParseUUIDPipe) adId: string,
    @Body() schedule: any,
    @CurrentTenant() t: string,
  ) {
    return this.marketingSvc.scheduleCampaign(t, adId, schedule);
  }

  @Get('marketing/analytics')
  @ApiOperation({ summary: 'Get campaign analytics by platform' })
  adAnalytics(@CurrentTenant() t: string) {
    return this.marketingSvc.getCampaignAnalytics(t);
  }

  // ── Customer Support AI ──────────────────────────────────
  @Post('support/triage/:ticketId')
  @ApiOperation({ summary: 'AI triage a support ticket' })
  triageTicket(
    @Param('ticketId', ParseUUIDPipe) ticketId: string,
    @CurrentTenant() t: string,
  ) {
    return this.supportSvc.triageTicket(t, ticketId);
  }

  @Post('support/chat/:ticketId')
  @ApiOperation({ summary: 'AI chat response for a ticket message' })
  processMessage(
    @Param('ticketId', ParseUUIDPipe) ticketId: string,
    @Body('message') message: string,
    @CurrentTenant() t: string,
  ) {
    return this.supportSvc.processMessage(t, ticketId, message);
  }

  @Post('support/bulk-triage')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Bulk AI triage all open tickets' })
  bulkTriage(@CurrentTenant() t: string) {
    return this.supportSvc.bulkTriage(t);
  }

  @Get('support/analytics')
  @ApiOperation({ summary: 'Support ticket analytics' })
  supportAnalytics(@CurrentTenant() t: string) {
    return this.supportSvc.getTicketAnalytics(t);
  }

  // ── Supplier Sync ────────────────────────────────────────
  @Post('supplier-sync/all')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Queue sync for all active suppliers' })
  syncAll(@CurrentTenant() t: string) {
    return this.supplierSvc.syncAll(t);
  }

  @Post('supplier-sync/:supplierId')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Sync a specific supplier' })
  syncSupplier(
    @Param('supplierId', ParseUUIDPipe) supplierId: string,
    @CurrentTenant() t: string,
  ) {
    return this.supplierSvc.syncSupplier(supplierId, t);
  }

  @Get('supplier-sync/health')
  @ApiOperation({ summary: 'Monitor all supplier health status' })
  supplierHealth(@CurrentTenant() t: string) {
    return this.supplierSvc.monitorHealth(t);
  }

  // ── AI Logs ──────────────────────────────────────────────
  @Get('logs')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Get AI task logs' })
  getLogs(@CurrentTenant() t: string, @Query() query: any) {
    return this.aiSvc.getLogs(t, query);
  }
}
