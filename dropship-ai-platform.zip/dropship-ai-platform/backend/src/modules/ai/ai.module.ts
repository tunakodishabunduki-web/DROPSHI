import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { ProductResearchModule } from './product-research/product-research.module';
import { DynamicPricingModule } from './dynamic-pricing/dynamic-pricing.module';
import { MarketingAiModule } from './marketing/marketing-ai.module';
import { CustomerSupportAiModule } from './customer-support/customer-support-ai.module';
import { SupplierSyncModule } from './supplier-sync/supplier-sync.module';
import { AiLog } from './entities/ai-log.entity';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([AiLog]),
    BullModule.registerQueue(
      { name: 'ai_tasks_queue' },
      { name: 'supplier_sync_queue' },
      { name: 'marketing_campaign_queue' },
    ),
    ProductResearchModule,
    DynamicPricingModule,
    MarketingAiModule,
    CustomerSupportAiModule,
    SupplierSyncModule,
  ],
  controllers: [AiController],
  providers: [AiService],
  exports: [AiService],
})
export class AiModule {}
