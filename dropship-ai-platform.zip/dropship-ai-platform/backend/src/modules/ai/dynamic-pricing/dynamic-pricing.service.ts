import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';
import { Product } from '../../products/entities/product.entity';
import { PricingHistory } from '../../products/entities/pricing-history.entity';
import { Trend } from '../../trends/entities/trend.entity';

export type PricingStrategy = 'cost_plus' | 'competitor' | 'demand_based' | 'ai_optimal' | 'penetration' | 'premium';

@Injectable()
export class DynamicPricingService {
  private readonly logger = new Logger(DynamicPricingService.name);
  private openai: OpenAI;

  constructor(
    @InjectRepository(Product) private productsRepo: Repository<Product>,
    @InjectRepository(PricingHistory) private pricingRepo: Repository<PricingHistory>,
    @InjectRepository(Trend) private trendsRepo: Repository<Trend>,
    @InjectQueue('ai_tasks_queue') private aiQueue: Queue,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Analyze & Suggest Price ───────────────────────────────
  async suggestPrice(tenantId: string, productId: string, strategy: PricingStrategy = 'ai_optimal') {
    const product = await this.productsRepo.findOne({
      where: { id: productId, tenantId },
    });
    if (!product) throw new Error(`Product ${productId} not found`);

    const [competitorData, trendData, salesHistory] = await Promise.all([
      this.fetchCompetitorPrices(product),
      this.getTrendData(product.name, tenantId),
      this.getSalesHistory(productId),
    ]);

    const analysis = await this.runPricingStrategy(
      product, competitorData, trendData, salesHistory, strategy,
    );

    return {
      currentPrice: product.basePrice,
      suggestedPrice: analysis.price,
      confidence: analysis.confidence,
      strategy,
      rationale: analysis.rationale,
      competitorData,
      trendData: trendData.slice(0, 5),
      projectedImpact: analysis.impact,
    };
  }

  // ── Apply Price ───────────────────────────────────────────
  async applyPrice(tenantId: string, productId: string, newPrice: number, strategy: string, reason: string) {
    const product = await this.productsRepo.findOne({ where: { id: productId, tenantId } });
    if (!product) throw new Error('Product not found');

    await this.pricingRepo.save({
      productId,
      tenantId,
      oldPrice: product.basePrice,
      newPrice,
      strategy,
      changeReason: reason,
      aiConfidence: 0.85,
    });

    await this.productsRepo.update({ id: productId, tenantId }, { basePrice: newPrice });
    this.logger.log(`Price updated: ${productId} ${product.basePrice} → ${newPrice} (${strategy})`);

    return { success: true, oldPrice: product.basePrice, newPrice };
  }

  // ── Batch Pricing Run ─────────────────────────────────────
  async runBatchPricing(tenantId: string, strategy: PricingStrategy, filters?: any) {
    const products = await this.productsRepo.find({
      where: { tenantId, status: 'active' },
      take: 100,
    });

    const job = await this.aiQueue.add('batch_pricing', {
      tenantId,
      strategy,
      productIds: products.map((p) => p.id),
      filters,
    }, { priority: 2 });

    return { jobId: job.id, productCount: products.length };
  }

  // ── Simulate Price Impact ─────────────────────────────────
  async simulateImpact(tenantId: string, productId: string, newPrice: number) {
    const product = await this.productsRepo.findOne({ where: { id: productId, tenantId } });
    const history = await this.getSalesHistory(productId);

    const priceDiff = (newPrice - product.basePrice) / product.basePrice;
    const elasticity = -1.5; // typical ecom price elasticity

    const demandChange = priceDiff * elasticity;
    const projectedSales = (history.avgMonthlySales || 10) * (1 + demandChange);
    const projectedRevenue = projectedSales * newPrice;
    const currentRevenue = (history.avgMonthlySales || 10) * product.basePrice;

    return {
      currentPrice: product.basePrice,
      newPrice,
      priceDiff: `${(priceDiff * 100).toFixed(1)}%`,
      projectedSalesChange: `${(demandChange * 100).toFixed(1)}%`,
      projectedMonthlySales: Math.round(projectedSales),
      projectedRevenue: projectedRevenue.toFixed(2),
      currentRevenue: currentRevenue.toFixed(2),
      revenueDiff: `${(((projectedRevenue - currentRevenue) / currentRevenue) * 100).toFixed(1)}%`,
      breakEven: (product.costPrice / (1 - 0.3)).toFixed(2), // 30% min margin
    };
  }

  // ── Pricing Strategies ────────────────────────────────────
  private async runPricingStrategy(
    product: Product, competitors: any[], trends: any[], sales: any, strategy: PricingStrategy,
  ) {
    switch (strategy) {
      case 'cost_plus':
        return this.costPlusStrategy(product);

      case 'competitor':
        return this.competitorStrategy(product, competitors);

      case 'demand_based':
        return this.demandStrategy(product, trends, sales);

      case 'ai_optimal':
        return this.aiOptimalStrategy(product, competitors, trends, sales);

      case 'penetration':
        const competitorAvg = competitors.reduce((a, c) => a + c.price, 0) / (competitors.length || 1);
        return {
          price: Math.max(product.costPrice * 1.1, competitorAvg * 0.85),
          confidence: 0.7,
          rationale: 'Penetration pricing: 15% below competitor average',
          impact: { sales: '+25%', margin: '-15%' },
        };

      case 'premium':
        return {
          price: product.basePrice * 1.25,
          confidence: 0.6,
          rationale: 'Premium pricing strategy',
          impact: { sales: '-10%', margin: '+25%' },
        };
    }
  }

  private costPlusStrategy(product: Product) {
    const price = product.costPrice * 2.5;
    return {
      price: Math.max(price, product.costPrice * 1.2),
      confidence: 0.95,
      rationale: `Cost-plus pricing: 150% markup on cost price of $${product.costPrice}`,
      impact: { margin: '60%', risk: 'low' },
    };
  }

  private competitorStrategy(product: Product, competitors: any[]) {
    if (!competitors.length) return this.costPlusStrategy(product);
    const prices = competitors.map((c) => c.price);
    const min = Math.min(...prices);
    const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
    const suggested = Math.max(product.costPrice * 1.15, min * 0.98);

    return {
      price: parseFloat(suggested.toFixed(2)),
      confidence: 0.8,
      rationale: `Competitive pricing: slightly below market minimum ($${min.toFixed(2)})`,
      impact: { sales: '+15%', margin: `${(((suggested - product.costPrice) / suggested) * 100).toFixed(0)}%` },
    };
  }

  private demandStrategy(product: Product, trends: any[], sales: any) {
    const avgScore = trends.reduce((a, t) => a + (t.score || 0), 0) / (trends.length || 1);
    const multiplier = 1 + (avgScore / 100) * 0.3;
    const price = product.basePrice * multiplier;

    return {
      price: parseFloat(Math.max(price, product.costPrice * 1.15).toFixed(2)),
      confidence: 0.75,
      rationale: `Demand-based: trend score ${avgScore.toFixed(0)}/100, ${(multiplier - 1) * 100}% premium applied`,
      impact: { sales: 'stable', revenue: `+${((multiplier - 1) * 100).toFixed(0)}%` },
    };
  }

  private async aiOptimalStrategy(product: Product, competitors: any[], trends: any[], sales: any) {
    try {
      const prompt = `
You are a pricing AI for an e-commerce drop shipping platform.

Product: ${product.name}
Current Price: $${product.basePrice}
Cost Price: $${product.costPrice}
Sales History: ${JSON.stringify(sales)}
Competitor Prices: ${JSON.stringify(competitors.slice(0, 5))}
Trend Score: ${trends[0]?.score || 'N/A'}/100

Suggest the optimal price in USD. Consider:
1. Profit margin (minimum 20%)
2. Market competitiveness
3. Demand trends
4. Price elasticity

Respond with JSON only:
{
  "price": number,
  "confidence": number (0-1),
  "rationale": "brief explanation",
  "impact": {"sales": "estimate", "margin": "estimate"}
}`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        max_tokens: 300,
      });

      const result = JSON.parse(response.choices[0].message.content);
      const price = Math.max(result.price, product.costPrice * 1.15);
      return { ...result, price };
    } catch (err) {
      this.logger.error('AI pricing failed, falling back to cost-plus', err);
      return this.costPlusStrategy(product);
    }
  }

  private async fetchCompetitorPrices(product: Product) {
    // TODO: Integrate with real competitor APIs (Amazon, AliExpress)
    // Mock data for now
    return [
      { source: 'amazon', price: product.basePrice * 1.1, name: product.name },
      { source: 'aliexpress', price: product.basePrice * 0.95, name: product.name },
    ];
  }

  private async getTrendData(productName: string, tenantId: string) {
    return this.trendsRepo.find({
      where: { keyword: productName },
      order: { recordedAt: 'DESC' },
      take: 10,
    });
  }

  private async getSalesHistory(productId: string) {
    // TODO: Query from order_items
    return { avgMonthlySales: 45, trend: 'increasing', velocity: 1.2 };
  }
}
