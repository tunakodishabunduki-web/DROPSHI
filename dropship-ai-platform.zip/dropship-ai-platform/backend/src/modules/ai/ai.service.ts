// ─── ai.service.ts ────────────────────────────────────────────────────────────
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AiLog } from './entities/ai-log.entity';

@Injectable()
export class AiService {
  constructor(@InjectRepository(AiLog) private logsRepo: Repository<AiLog>) {}

  async getLogs(tenantId: string, query: any = {}) {
    const { page = 1, limit = 50, module, status } = query;
    const qb = this.logsRepo.createQueryBuilder('l')
      .where('l.tenantId = :tenantId', { tenantId })
      .orderBy('l.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);
    if (module) qb.andWhere('l.module = :module', { module });
    if (status) qb.andWhere('l.status = :status', { status });
    const [data, total] = await qb.getManyAndCount();
    return { data, meta: { total, page: +page, limit: +limit } };
  }
}
