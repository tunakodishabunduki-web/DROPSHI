import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import { Supplier } from '../../suppliers/entities/supplier.entity';
import { Product } from '../../products/entities/product.entity';
import { AiLog } from '../entities/ai-log.entity';

@Injectable()
export class SupplierSyncService {
  private readonly logger = new Logger(SupplierSyncService.name);

  constructor(
    @InjectRepository(Supplier) private suppliersRepo: Repository<Supplier>,
    @InjectRepository(Product) private productsRepo: Repository<Product>,
    @InjectRepository(AiLog) private aiLogsRepo: Repository<AiLog>,
    @InjectQueue('supplier_sync_queue') private syncQueue: Queue,
    private config: ConfigService,
    private dataSource: DataSource,
  ) {}

  // ── Full Sync All Active Suppliers ────────────────────────
  async syncAll(tenantId: string) {
    const suppliers = await this.suppliersRepo.find({
      where: { tenantId, status: 'active' },
    });

    const jobs = await Promise.all(
      suppliers.map((s) =>
        this.syncQueue.add(
          'sync_supplier',
          { supplierId: s.id, tenantId },
          { priority: 5, attempts: 3, backoff: { type: 'exponential', delay: 5000 } },
        ),
      ),
    );

    return { queued: jobs.length, supplierIds: suppliers.map((s) => s.id) };
  }

  // ── Sync Single Supplier ──────────────────────────────────
  async syncSupplier(supplierId: string, tenantId: string) {
    const supplier = await this.suppliersRepo.findOne({
      where: { id: supplierId, tenantId },
    });
    if (!supplier) throw new Error('Supplier not found');

    const startTime = Date.now();
    const log = await this.aiLogsRepo.save(
      this.aiLogsRepo.create({
        tenantId,
        module: 'supplier_sync',
        taskType: 'sync_inventory',
        status: 'processing',
        referenceId: supplierId,
        referenceType: 'supplier',
      }),
    );

    try {
      let result;
      switch (supplier.apiType) {
        case 'aliexpress':
          result = await this.syncAliExpress(supplier);
          break;
        case 'shopify':
          result = await this.syncShopify(supplier);
          break;
        case 'amazon':
          result = await this.syncAmazon(supplier);
          break;
        default:
          result = await this.syncCustomApi(supplier);
      }

      await this.applyInventoryUpdates(tenantId, supplierId, result.products);

      await this.suppliersRepo.update(supplierId, {
        lastSyncedAt: new Date(),
        reliabilityScore: Math.min(
          1.0,
          (supplier.reliabilityScore || 0.5) * 0.9 + 0.1,
        ),
      });

      await this.aiLogsRepo.update(log.id, {
        status: 'completed',
        outputData: { synced: result.products.length, errors: result.errors },
        durationMs: Date.now() - startTime,
        completedAt: new Date(),
      });

      return result;
    } catch (error) {
      await this.aiLogsRepo.update(log.id, {
        status: 'failed',
        errorMessage: error.message,
        durationMs: Date.now() - startTime,
        completedAt: new Date(),
      });

      // Trigger failover if available
      if (supplier.failoverSupplierId) {
        await this.triggerFailover(tenantId, supplier);
      }

      throw error;
    }
  }

  // ── Apply Inventory Updates ───────────────────────────────
  private async applyInventoryUpdates(
    tenantId: string,
    supplierId: string,
    supplierProducts: any[],
  ) {
    const qr = this.dataSource.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();

    let updated = 0;
    let outOfStock = 0;

    try {
      for (const sp of supplierProducts) {
        const product = await qr.manager.findOne(Product, {
          where: { tenantId, supplierId, supplierSku: sp.sku },
        });

        if (!product) continue;

        const stockChanged = product.stockQuantity !== sp.stock;
        const priceChanged = product.costPrice !== sp.costPrice;

        if (stockChanged || priceChanged) {
          const update: Partial<Product> = {};
          if (stockChanged) {
            update.stockQuantity = sp.stock;
            update.status = sp.stock === 0 ? 'out_of_stock' : 'active';
            if (sp.stock === 0) outOfStock++;
          }
          if (priceChanged) update.costPrice = sp.costPrice;

          await qr.manager.update(Product, { id: product.id }, update);
          updated++;
        }
      }

      await qr.commitTransaction();
      this.logger.log(`Supplier ${supplierId}: ${updated} products updated, ${outOfStock} out of stock`);
      return { updated, outOfStock };
    } catch (e) {
      await qr.rollbackTransaction();
      throw e;
    } finally {
      await qr.release();
    }
  }

  // ── Failover Handler ──────────────────────────────────────
  private async triggerFailover(tenantId: string, failedSupplier: Supplier) {
    this.logger.warn(`Triggering failover from supplier ${failedSupplier.id}`);

    const failoverSupplier = await this.suppliersRepo.findOne({
      where: { id: failedSupplier.failoverSupplierId, tenantId },
    });
    if (!failoverSupplier) return;

    // Move products to failover supplier
    await this.productsRepo.update(
      { tenantId, supplierId: failedSupplier.id },
      { supplierId: failoverSupplier.id },
    );

    // Decrease reliability score
    await this.suppliersRepo.update(failedSupplier.id, {
      reliabilityScore: Math.max(0, (failedSupplier.reliabilityScore || 0.5) - 0.1),
    });

    this.logger.log(`Failover complete: ${failedSupplier.id} → ${failoverSupplier.id}`);
  }

  // ── Monitor Supplier Health ───────────────────────────────
  async monitorHealth(tenantId: string) {
    const suppliers = await this.suppliersRepo.find({ where: { tenantId } });

    const health = await Promise.all(
      suppliers.map(async (s) => {
        const isHealthy = await this.checkSupplierHealth(s);
        return {
          supplierId: s.id,
          name: s.name,
          status: isHealthy ? 'healthy' : 'degraded',
          reliabilityScore: s.reliabilityScore,
          lastSyncedAt: s.lastSyncedAt,
          avgShipDays: s.avgShipDays,
        };
      }),
    );

    return health;
  }

  // ── Supplier API Connectors ───────────────────────────────
  private async syncAliExpress(supplier: Supplier) {
    // AliExpress API integration
    const { appKey, appSecret } = supplier.apiCredentials as any || {};
    try {
      const response = await axios.get('https://api.aliexpress.com/v1/products', {
        params: { app_key: appKey, fields: 'sku,price,inventory' },
        timeout: 30000,
      });
      return { products: response.data?.products || [], errors: [] };
    } catch (e) {
      this.logger.error(`AliExpress sync failed: ${e.message}`);
      return { products: [], errors: [e.message] };
    }
  }

  private async syncShopify(supplier: Supplier) {
    const { shopDomain, accessToken } = supplier.apiCredentials as any || {};
    try {
      const response = await axios.get(
        `https://${shopDomain}/admin/api/2024-01/variants.json`,
        {
          headers: { 'X-Shopify-Access-Token': accessToken },
          params: { limit: 250 },
          timeout: 30000,
        },
      );
      const variants = response.data?.variants || [];
      return {
        products: variants.map((v: any) => ({
          sku: v.sku,
          stock: v.inventory_quantity,
          costPrice: parseFloat(v.price) * 0.5,
        })),
        errors: [],
      };
    } catch (e) {
      return { products: [], errors: [e.message] };
    }
  }

  private async syncAmazon(supplier: Supplier) {
    // Amazon SP-API stub
    return { products: [], errors: ['Amazon sync not configured'] };
  }

  private async syncCustomApi(supplier: Supplier) {
    const { baseUrl, apiKey } = supplier.apiCredentials as any || {};
    if (!baseUrl) return { products: [], errors: ['No base URL configured'] };

    try {
      const response = await axios.get(`${baseUrl}/inventory`, {
        headers: { Authorization: `Bearer ${apiKey}` },
        timeout: 30000,
      });
      return { products: response.data?.products || [], errors: [] };
    } catch (e) {
      return { products: [], errors: [e.message] };
    }
  }

  private async checkSupplierHealth(supplier: Supplier): Promise<boolean> {
    try {
      const url = supplier.website || 'https://httpstat.us/200';
      await axios.head(url, { timeout: 5000 });
      return true;
    } catch {
      return false;
    }
  }
}
