import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';
import { SupportTicket } from '../../support/entities/support-ticket.entity';
import { TicketMessage } from '../../support/entities/ticket-message.entity';

@Injectable()
export class CustomerSupportAiService {
  private readonly logger = new Logger(CustomerSupportAiService.name);
  private openai: OpenAI;

  // Common FAQ patterns for quick resolution
  private readonly faqPatterns = [
    { pattern: /track|tracking|where.*order/i, category: 'tracking', autoResolve: true },
    { pattern: /refund|return|cancel/i, category: 'refund', autoResolve: false },
    { pattern: /payment|charge|billing/i, category: 'payment', autoResolve: false },
    { pattern: /shipping|deliver|arrival/i, category: 'shipping', autoResolve: true },
    { pattern: /size|fit|dimension/i, category: 'product_info', autoResolve: true },
    { pattern: /broken|damaged|defect/i, category: 'damage', autoResolve: false },
  ];

  constructor(
    @InjectRepository(SupportTicket) private ticketsRepo: Repository<SupportTicket>,
    @InjectRepository(TicketMessage) private messagesRepo: Repository<TicketMessage>,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Auto-triage Ticket ────────────────────────────────────
  async triageTicket(tenantId: string, ticketId: string) {
    const ticket = await this.ticketsRepo.findOne({
      where: { id: ticketId, tenantId },
      relations: ['customer', 'messages'],
    });
    if (!ticket) throw new Error('Ticket not found');

    const category = this.detectCategory(ticket.subject + ' ' + (ticket.description || ''));
    const priority = await this.classifyPriority(ticket);
    const suggestedResponse = await this.generateResponse(ticket);

    await this.ticketsRepo.update({ id: ticketId, tenantId }, {
      category,
      priority: priority as any,
      aiSuggestedResponse: suggestedResponse.response,
      aiConfidence: suggestedResponse.confidence,
      firstResponseAt: new Date(),
    });

    // Auto-resolve low-risk tickets
    if (suggestedResponse.confidence > 0.9 && suggestedResponse.canAutoResolve) {
      await this.sendAutoResponse(tenantId, ticketId, suggestedResponse.response);
    }

    return { category, priority, suggestedResponse };
  }

  // ── Generate AI Response ──────────────────────────────────
  async generateResponse(ticket: SupportTicket) {
    const conversationHistory = ticket.messages?.map((m) => ({
      role: m.senderType === 'customer' ? 'user' : 'assistant',
      content: m.message,
    })) || [];

    const systemPrompt = `You are a helpful customer support agent for an e-commerce store.
Be empathetic, concise, and solution-focused.
If you cannot resolve the issue, offer to escalate.
Do not make promises about specific timelines unless you have that data.
Always maintain a professional and friendly tone.`;

    const userMessage = `Customer ticket:
Subject: ${ticket.subject}
Description: ${ticket.description}
Order: ${ticket.orderId || 'N/A'}

Provide a helpful response. Also indicate:
1. Can this be auto-resolved? (yes/no)
2. Confidence level (0-1)

Respond in JSON: {response: string, canAutoResolve: boolean, confidence: number, suggestedActions: string[]}`;

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        ...conversationHistory,
        { role: 'user', content: userMessage },
      ],
      response_format: { type: 'json_object' },
      max_tokens: 600,
    });

    return JSON.parse(response.choices[0].message.content);
  }

  // ── Chat Message ──────────────────────────────────────────
  async processMessage(tenantId: string, ticketId: string, message: string) {
    const ticket = await this.ticketsRepo.findOne({
      where: { id: ticketId, tenantId },
      relations: ['messages', 'customer'],
    });

    // Get AI response
    const conversationHistory = [
      ...(ticket.messages || []).slice(-10).map((m) => ({
        role: (m.senderType === 'customer' ? 'user' : 'assistant') as any,
        content: m.message,
      })),
      { role: 'user' as const, content: message },
    ];

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: 'You are a customer support agent. Be helpful, concise, and empathetic. If you need to escalate, say so.',
        },
        ...conversationHistory,
      ],
      max_tokens: 400,
    });

    const aiResponse = response.choices[0].message.content;
    const shouldEscalate = /escalat|supervisor|manager|cannot help/i.test(aiResponse);

    // Save messages
    await this.messagesRepo.save([
      this.messagesRepo.create({
        ticketId,
        tenantId,
        senderType: 'customer',
        message,
      }),
      this.messagesRepo.create({
        ticketId,
        tenantId,
        senderType: 'ai',
        message: aiResponse,
        isAi: true,
      }),
    ]);

    if (shouldEscalate) {
      await this.ticketsRepo.update({ id: ticketId }, {
        status: 'escalated',
        escalatedAt: new Date(),
        priority: 'high',
      });
    }

    return {
      response: aiResponse,
      shouldEscalate,
      ticketStatus: shouldEscalate ? 'escalated' : ticket.status,
    };
  }

  // ── Bulk Triage Pending Tickets ────────────────────────────
  async bulkTriage(tenantId: string) {
    const pendingTickets = await this.ticketsRepo.find({
      where: { tenantId, status: 'open', aiSuggestedResponse: null as any },
      take: 50,
      order: { createdAt: 'ASC' },
    });

    const results = await Promise.allSettled(
      pendingTickets.map((t) => this.triageTicket(tenantId, t.id)),
    );

    return {
      processed: results.filter((r) => r.status === 'fulfilled').length,
      failed: results.filter((r) => r.status === 'rejected').length,
      total: pendingTickets.length,
    };
  }

  // ── Analytics ─────────────────────────────────────────────
  async getTicketAnalytics(tenantId: string) {
    const tickets = await this.ticketsRepo
      .createQueryBuilder('t')
      .select([
        'COUNT(*) as total',
        "COUNT(*) FILTER (WHERE t.status = 'open') as open_count",
        "COUNT(*) FILTER (WHERE t.status = 'resolved') as resolved_count",
        "COUNT(*) FILTER (WHERE t.status = 'escalated') as escalated_count",
        "AVG(EXTRACT(EPOCH FROM (t.resolved_at - t.created_at))/3600) FILTER (WHERE t.resolved_at IS NOT NULL) as avg_resolution_hours",
        "AVG(t.ai_confidence) as avg_ai_confidence",
      ])
      .where('t.tenant_id = :tenantId', { tenantId })
      .getRawOne();

    return tickets;
  }

  // ── Helpers ───────────────────────────────────────────────
  private detectCategory(text: string): string {
    for (const faq of this.faqPatterns) {
      if (faq.pattern.test(text)) return faq.category;
    }
    return 'general';
  }

  private async classifyPriority(ticket: SupportTicket): Promise<string> {
    const urgentSignals = /urgent|asap|immediately|broken|fraud|charge|stolen/i;
    const highSignals = /refund|damaged|wrong item|never received/i;

    if (urgentSignals.test(ticket.subject + ' ' + ticket.description)) return 'urgent';
    if (highSignals.test(ticket.subject + ' ' + ticket.description)) return 'high';
    return 'medium';
  }

  private async sendAutoResponse(tenantId: string, ticketId: string, response: string) {
    await this.messagesRepo.save(this.messagesRepo.create({
      ticketId,
      tenantId,
      senderType: 'ai',
      message: response,
      isAi: true,
    }));

    await this.ticketsRepo.update({ id: ticketId }, {
      status: 'in_progress',
    });
  }
}
