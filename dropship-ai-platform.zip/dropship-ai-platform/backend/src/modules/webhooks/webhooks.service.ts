// ─── webhooks.service.ts ──────────────────────────────────────────────────────
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import axios from 'axios';
import * as crypto from 'crypto';
import { Webhook } from './entities/webhook.entity';

@Injectable()
export class WebhooksService {
  constructor(@InjectRepository(Webhook) private repo: Repository<Webhook>) {}

  findAll(tenantId: string) { return this.repo.find({ where: { tenantId } }); }

  create(tenantId: string, dto: any) {
    return this.repo.save(this.repo.create({ ...dto, tenantId }));
  }

  async update(tenantId: string, id: string, dto: any) {
    await this.repo.update({ id, tenantId }, dto);
    return this.repo.findOne({ where: { id, tenantId } });
  }

  delete(tenantId: string, id: string) { return this.repo.delete({ id, tenantId }); }

  async dispatch(tenantId: string, event: string, payload: object) {
    const hooks = await this.repo.find({ where: { tenantId, isActive: true } });
    for (const hook of hooks) {
      if (!hook.events.includes(event) && !hook.events.includes('*')) continue;
      await this.deliver(hook, event, payload);
    }
  }

  private async deliver(hook: Webhook, event: string, payload: object) {
    const body = JSON.stringify({ event, data: payload, timestamp: new Date().toISOString() });
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Webhook-Event': event,
      ...(hook.headers as Record<string, string>),
    };
    if (hook.secret) {
      const sig = crypto.createHmac('sha256', hook.secret).update(body).digest('hex');
      headers['X-Webhook-Signature'] = `sha256=${sig}`;
    }
    try {
      await axios.post(hook.url, body, { headers, timeout: hook.timeoutMs });
      await this.repo.update(hook.id, { lastUsedAt: new Date() });
    } catch (e) {
      // Retry logic handled by queue in production
    }
  }
}

// ─── webhooks.controller.ts ───────────────────────────────────────────────────
import { Controller, Get, Post, Put, Delete, Param, Body, UseGuards, ParseUUIDPipe, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { WebhooksService } from './webhooks.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('webhooks') @ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'webhooks', version: '1' })
export class WebhooksController {
  constructor(private svc: WebhooksService) {}
  @Get() @Roles('tenant_admin') findAll(@CurrentTenant() t: string) { return this.svc.findAll(t); }
  @Post() @Roles('tenant_admin') @HttpCode(HttpStatus.CREATED) create(@Body() dto: any, @CurrentTenant() t: string) { return this.svc.create(t, dto); }
  @Put(':id') @Roles('tenant_admin') update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any, @CurrentTenant() t: string) { return this.svc.update(t, id, dto); }
  @Delete(':id') @Roles('tenant_admin') @HttpCode(HttpStatus.NO_CONTENT) delete(@Param('id', ParseUUIDPipe) id: string, @CurrentTenant() t: string) { return this.svc.delete(t, id); }
}
