// ─── webhooks.module.ts ───────────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WebhooksController } from './webhooks.controller';
import { WebhooksService } from './webhooks.service';
import { Webhook } from './entities/webhook.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Webhook])],
  controllers: [WebhooksController],
  providers: [WebhooksService],
  exports: [WebhooksService],
})
export class WebhooksModule {}

// ─── webhook.entity.ts ────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('webhooks')
export class Webhook {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 255 }) name: string;
  @Column({ type: 'text' }) url: string;
  @Column({ nullable: true }) secret: string;
  @Column({ type: 'text', array: true, default: [] }) events: string[];
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @Column({ type: 'jsonb', default: {} }) headers: object;
  @Column({ name: 'retry_count', default: 3 }) retryCount: number;
  @Column({ name: 'timeout_ms', default: 5000 }) timeoutMs: number;
  @Column({ name: 'last_used_at', nullable: true }) lastUsedAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
