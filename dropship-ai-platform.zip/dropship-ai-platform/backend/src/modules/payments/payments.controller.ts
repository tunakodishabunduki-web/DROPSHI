import {
  Controller, Post, Body, UseGuards, HttpCode, HttpStatus,
  Headers, RawBodyRequest, Req,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { Request } from 'express';
import { PaymentsService } from './payments.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';
import { Public } from '../../common/decorators/index';

@ApiTags('payments')
@Controller({ path: 'payments', version: '1' })
export class PaymentsController {
  constructor(private readonly paymentsService: PaymentsService) {}

  // ── Stripe ──────────────────────────────────────────────
  @Post('stripe/intent')
  @UseGuards(JwtAuthGuard, TenantGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create Stripe payment intent' })
  createStripeIntent(
    @Body() body: { orderId: string; amount: number; currency?: string },
    @CurrentTenant() tenantId: string,
  ) {
    return this.paymentsService.createStripePaymentIntent(
      tenantId, body.orderId, body.amount, body.currency,
    );
  }

  @Post('stripe/confirm')
  @UseGuards(JwtAuthGuard, TenantGuard)
  @ApiBearerAuth()
  confirmStripe(@Body('paymentIntentId') paymentIntentId: string) {
    return this.paymentsService.confirmStripePayment(paymentIntentId);
  }

  @Post('stripe/webhook')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Stripe webhook receiver' })
  stripeWebhook(
    @Req() req: RawBodyRequest<Request>,
    @Headers('stripe-signature') signature: string,
  ) {
    return this.paymentsService.handleStripeWebhook(req.rawBody, signature);
  }

  // ── PayPal ──────────────────────────────────────────────
  @Post('paypal/create')
  @UseGuards(JwtAuthGuard, TenantGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create PayPal order' })
  createPayPal(
    @Body() body: { orderId: string; amount: number; currency?: string },
    @CurrentTenant() tenantId: string,
  ) {
    return this.paymentsService.createPayPalOrder(
      tenantId, body.orderId, body.amount, body.currency,
    );
  }

  @Post('paypal/capture')
  @UseGuards(JwtAuthGuard, TenantGuard)
  @ApiBearerAuth()
  capturePayPal(@Body('paypalOrderId') paypalOrderId: string) {
    return this.paymentsService.capturePayPalPayment(paypalOrderId);
  }

  // ── M-Pesa ──────────────────────────────────────────────
  @Post('mpesa/stk-push')
  @UseGuards(JwtAuthGuard, TenantGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Initiate M-Pesa STK push' })
  mpesaInit(
    @Body() body: { orderId: string; amount: number; phone: string },
    @CurrentTenant() tenantId: string,
  ) {
    return this.paymentsService.initiateMpesaStkPush(
      tenantId, body.orderId, body.amount, body.phone,
    );
  }

  @Post('mpesa/callback')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'M-Pesa payment callback' })
  mpesaCallback(@Body() body: any) {
    return this.paymentsService.handleMpesaCallback(body);
  }
}
