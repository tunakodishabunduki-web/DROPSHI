import { Injectable, BadRequestException, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import axios from 'axios';
import { Payment } from './entities/payment.entity';
import { Order } from '../orders/entities/order.entity';

@Injectable()
export class PaymentsService {
  private stripe: Stripe;
  private mpesaToken: string | null = null;

  constructor(
    @InjectRepository(Payment) private paymentsRepo: Repository<Payment>,
    private config: ConfigService,
  ) {
    this.stripe = new Stripe(config.get('STRIPE_SECRET_KEY'), {
      apiVersion: '2024-06-20',
    });
  }

  // ── Create Payment Intent (Stripe) ────────────────────────
  async createStripePaymentIntent(tenantId: string, orderId: string, amount: number, currency = 'usd') {
    const intent = await this.stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // cents
      currency: currency.toLowerCase(),
      metadata: { tenantId, orderId },
      automatic_payment_methods: { enabled: true },
    });

    await this.paymentsRepo.save(this.paymentsRepo.create({
      tenantId,
      orderId,
      provider: 'stripe',
      providerPaymentId: intent.id,
      status: 'pending',
      amount,
      currency: currency.toUpperCase() as any,
    }));

    return { clientSecret: intent.client_secret, paymentIntentId: intent.id };
  }

  // ── Confirm Stripe Payment ────────────────────────────────
  async confirmStripePayment(paymentIntentId: string) {
    const intent = await this.stripe.paymentIntents.retrieve(paymentIntentId);

    const payment = await this.paymentsRepo.findOne({
      where: { providerPaymentId: paymentIntentId, provider: 'stripe' },
    });

    if (!payment) throw new BadRequestException('Payment record not found');

    const status = intent.status === 'succeeded' ? 'completed' : 'failed';
    await this.paymentsRepo.update(payment.id, {
      status,
      providerResponse: intent as any,
    });

    return { status, paymentId: payment.id };
  }

  // ── Create PayPal Order ───────────────────────────────────
  async createPayPalOrder(tenantId: string, orderId: string, amount: number, currency = 'USD') {
    const accessToken = await this.getPayPalAccessToken();

    const paypalOrder = await axios.post(
      `${this.getPayPalBaseUrl()}/v2/checkout/orders`,
      {
        intent: 'CAPTURE',
        purchase_units: [{
          reference_id: orderId,
          amount: { currency_code: currency, value: amount.toFixed(2) },
          custom_id: tenantId,
        }],
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      },
    );

    await this.paymentsRepo.save(this.paymentsRepo.create({
      tenantId,
      orderId,
      provider: 'paypal',
      providerPaymentId: paypalOrder.data.id,
      status: 'pending',
      amount,
      currency: currency as any,
    }));

    const approvalUrl = paypalOrder.data.links.find((l: any) => l.rel === 'approve')?.href;
    return { orderId: paypalOrder.data.id, approvalUrl };
  }

  // ── Capture PayPal Payment ────────────────────────────────
  async capturePayPalPayment(paypalOrderId: string) {
    const accessToken = await this.getPayPalAccessToken();

    const capture = await axios.post(
      `${this.getPayPalBaseUrl()}/v2/checkout/orders/${paypalOrderId}/capture`,
      {},
      { headers: { Authorization: `Bearer ${accessToken}` } },
    );

    const payment = await this.paymentsRepo.findOne({
      where: { providerPaymentId: paypalOrderId, provider: 'paypal' },
    });

    if (payment) {
      await this.paymentsRepo.update(payment.id, {
        status: 'completed',
        providerResponse: capture.data,
      });
    }

    return { status: 'completed', captureId: capture.data.id };
  }

  // ── M-Pesa STK Push ───────────────────────────────────────
  async initiateMpesaStkPush(tenantId: string, orderId: string, amount: number, phone: string) {
    const token = await this.getMpesaToken();
    const timestamp = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 14);
    const shortcode = this.config.get('MPESA_SHORTCODE');
    const passkey = this.config.get('MPESA_PASSKEY');
    const password = Buffer.from(`${shortcode}${passkey}${timestamp}`).toString('base64');

    const formatted_phone = phone.startsWith('0')
      ? '254' + phone.slice(1)
      : phone.replace('+', '');

    const stkResponse = await axios.post(
      'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest',
      {
        BusinessShortCode: shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: Math.ceil(amount),
        PartyA: formatted_phone,
        PartyB: shortcode,
        PhoneNumber: formatted_phone,
        CallBackURL: this.config.get('MPESA_CALLBACK_URL'),
        AccountReference: orderId.slice(0, 12),
        TransactionDesc: `Order ${orderId}`,
      },
      { headers: { Authorization: `Bearer ${token}` } },
    );

    const payment = await this.paymentsRepo.save(this.paymentsRepo.create({
      tenantId,
      orderId,
      provider: 'mpesa',
      providerPaymentId: stkResponse.data.CheckoutRequestID,
      status: 'processing',
      amount,
      currency: 'KES' as any,
      metadata: { checkoutRequestId: stkResponse.data.CheckoutRequestID, phone },
    }));

    return {
      checkoutRequestId: stkResponse.data.CheckoutRequestID,
      merchantRequestId: stkResponse.data.MerchantRequestID,
      paymentId: payment.id,
    };
  }

  // ── M-Pesa Callback ───────────────────────────────────────
  async handleMpesaCallback(body: any) {
    const { Body: { stkCallback } } = body;
    const { CheckoutRequestID, ResultCode } = stkCallback;

    const payment = await this.paymentsRepo.findOne({
      where: { providerPaymentId: CheckoutRequestID, provider: 'mpesa' },
    });

    if (!payment) return;

    const status = ResultCode === 0 ? 'completed' : 'failed';
    await this.paymentsRepo.update(payment.id, {
      status,
      providerResponse: body,
      failedReason: ResultCode !== 0 ? stkCallback.ResultDesc : undefined,
    });

    return { paymentId: payment.id, status };
  }

  // ── Handle Stripe Webhook ─────────────────────────────────
  async handleStripeWebhook(payload: Buffer, signature: string) {
    let event: Stripe.Event;

    try {
      event = this.stripe.webhooks.constructEvent(
        payload,
        signature,
        this.config.get('STRIPE_WEBHOOK_SECRET'),
      );
    } catch {
      throw new BadRequestException('Invalid Stripe signature');
    }

    switch (event.type) {
      case 'payment_intent.succeeded':
        await this.confirmStripePayment((event.data.object as Stripe.PaymentIntent).id);
        break;
      case 'payment_intent.payment_failed':
        const pi = event.data.object as Stripe.PaymentIntent;
        await this.paymentsRepo.update(
          { providerPaymentId: pi.id, provider: 'stripe' },
          { status: 'failed', failedReason: pi.last_payment_error?.message },
        );
        break;
      case 'charge.refunded':
        // Handle refund
        break;
    }

    return { received: true };
  }

  // ── Refund ────────────────────────────────────────────────
  async processRefund(tenantId: string, order: Order, amount: number) {
    const payment = await this.paymentsRepo.findOne({
      where: { orderId: order.id, tenantId, status: 'completed' },
      order: { createdAt: 'DESC' },
    });

    if (!payment) throw new BadRequestException('No completed payment found for this order');

    switch (payment.provider) {
      case 'stripe':
        const refund = await this.stripe.refunds.create({
          payment_intent: payment.providerPaymentId,
          amount: Math.round(amount * 100),
        });
        await this.paymentsRepo.update(payment.id, {
          refundedAmount: (payment.refundedAmount || 0) + amount,
          providerResponse: refund as any,
        });
        return { refundId: refund.id, amount, status: 'completed' };

      case 'paypal':
        // TODO: Implement PayPal refund
        break;

      case 'mpesa':
        // TODO: Implement M-Pesa reversal
        break;
    }
  }

  // ── Helpers ───────────────────────────────────────────────
  private async getPayPalAccessToken() {
    const clientId = this.config.get('PAYPAL_CLIENT_ID');
    const secret = this.config.get('PAYPAL_CLIENT_SECRET');
    const credentials = Buffer.from(`${clientId}:${secret}`).toString('base64');

    const response = await axios.post(
      `${this.getPayPalBaseUrl()}/v1/oauth2/token`,
      'grant_type=client_credentials',
      {
        headers: {
          Authorization: `Basic ${credentials}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      },
    );

    return response.data.access_token;
  }

  private async getMpesaToken() {
    const consumer = this.config.get('MPESA_CONSUMER_KEY');
    const secret = this.config.get('MPESA_CONSUMER_SECRET');
    const credentials = Buffer.from(`${consumer}:${secret}`).toString('base64');

    const response = await axios.get(
      'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials',
      { headers: { Authorization: `Basic ${credentials}` } },
    );

    return response.data.access_token;
  }

  private getPayPalBaseUrl() {
    return this.config.get('PAYPAL_MODE') === 'live'
      ? 'https://api-m.paypal.com'
      : 'https://api-m.sandbox.paypal.com';
  }
}
