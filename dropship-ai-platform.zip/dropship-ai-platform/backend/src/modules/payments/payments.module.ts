// ─── payments.module.ts ───────────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaymentsController } from './payments.controller';
import { PaymentsService } from './payments.service';
import { Payment } from './entities/payment.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Payment])],
  controllers: [PaymentsController],
  providers: [PaymentsService],
  exports: [PaymentsService],
})
export class PaymentsModule {}

// ─── payment.entity.ts ────────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('payments')
export class Payment {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'order_id' }) orderId: string;
  @Column({ name: 'order_created_at', nullable: true }) orderCreatedAt: Date;
  @Column() provider: string;
  @Column({ name: 'provider_payment_id', nullable: true }) providerPaymentId: string;
  @Column({ default: 'pending' }) status: string;
  @Column({ type: 'numeric', precision: 12, scale: 2 }) amount: number;
  @Column({ default: 'USD' }) currency: string;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @Column({ name: 'provider_response', type: 'jsonb', nullable: true }) providerResponse: object;
  @Column({ name: 'failed_reason', nullable: true }) failedReason: string;
  @Column({ name: 'refunded_amount', type: 'numeric', precision: 12, scale: 2, default: 0 }) refundedAmount: number;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
  order: any;
}
