// ─── support-ticket.entity.ts ─────────────────────────────────────────────────
import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, OneToMany, ManyToOne, JoinColumn,
} from 'typeorm';
import { TicketMessage } from './ticket-message.entity';
import { Customer } from '../../customers/entities/customer.entity';

@Entity('support_tickets')
export class SupportTicket {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'customer_id', nullable: true }) customerId: string;
  @Column({ name: 'order_id', nullable: true }) orderId: string;
  @Column({ name: 'ticket_number', length: 50 }) ticketNumber: string;
  @Column({ length: 500 }) subject: string;
  @Column({ type: 'text', nullable: true }) description: string;
  @Column({ default: 'open' }) status: string;
  @Column({ default: 'medium' }) priority: string;
  @Column({ name: 'assigned_to', nullable: true }) assignedTo: string;
  @Column({ nullable: true }) category: string;
  @Column({ type: 'text', array: true, default: [] }) tags: string[];
  @Column({ name: 'ai_suggested_response', type: 'text', nullable: true }) aiSuggestedResponse: string;
  @Column({ name: 'ai_confidence', type: 'numeric', precision: 3, scale: 2, nullable: true }) aiConfidence: number;
  @Column({ name: 'resolved_at', nullable: true }) resolvedAt: Date;
  @Column({ name: 'first_response_at', nullable: true }) firstResponseAt: Date;
  @Column({ name: 'escalated_at', nullable: true }) escalatedAt: Date;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @OneToMany(() => TicketMessage, (m) => m.ticket) messages: TicketMessage[];
  @ManyToOne(() => Customer, { nullable: true }) @JoinColumn({ name: 'customer_id' }) customer: Customer;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── ticket-message.entity.ts ─────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';

@Entity('ticket_messages')
export class TicketMessage {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'ticket_id' }) ticketId: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'sender_id', nullable: true }) senderId: string;
  @Column({ name: 'sender_type', default: 'customer' }) senderType: string;
  @Column({ type: 'text' }) message: string;
  @Column({ type: 'jsonb', default: [] }) attachments: object[];
  @Column({ name: 'is_internal', default: false }) isInternal: boolean;
  @Column({ name: 'is_ai', default: false }) isAi: boolean;
  @ManyToOne(() => SupportTicket) @JoinColumn({ name: 'ticket_id' }) ticket: SupportTicket;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
