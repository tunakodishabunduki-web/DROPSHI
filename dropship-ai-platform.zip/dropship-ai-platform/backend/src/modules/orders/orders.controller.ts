import {
  Controller, Get, Post, Patch, Param, Body,
  Query, UseGuards, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { OrderQueryDto } from './dto/order-query.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';
import { CurrentUser } from '../../common/decorators/index';

@ApiTags('orders')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'orders', version: '1' })
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Get()
  findAll(@Query() query: OrderQueryDto, @CurrentTenant() tenantId: string) {
    return this.ordersService.findAll(tenantId, query);
  }

  @Get('analytics')
  @Roles('tenant_admin', 'manager')
  getAnalytics(
    @CurrentTenant() tenantId: string,
    @Query('dateFrom') dateFrom: string,
    @Query('dateTo') dateTo: string,
  ) {
    return this.ordersService.getAnalytics(tenantId, new Date(dateFrom), new Date(dateTo));
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string, @CurrentTenant() tenantId: string) {
    return this.ordersService.findOne(tenantId, id);
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  create(
    @Body() dto: CreateOrderDto,
    @CurrentTenant() tenantId: string,
    @CurrentUser() user: any,
  ) {
    return this.ordersService.createOrder(tenantId, dto, user?.id);
  }

  @Patch(':id/status')
  @Roles('tenant_admin', 'manager', 'staff')
  updateStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @Body('status') status: string,
    @Body() meta: any,
    @CurrentTenant() tenantId: string,
  ) {
    return this.ordersService.updateStatus(tenantId, id, status, meta);
  }

  @Post(':id/cancel')
  cancel(
    @Param('id', ParseUUIDPipe) id: string,
    @Body('reason') reason: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.ordersService.cancel(tenantId, id, reason);
  }

  @Post(':id/refund')
  @Roles('tenant_admin', 'manager')
  refund(
    @Param('id', ParseUUIDPipe) id: string,
    @Body('amount') amount: number,
    @CurrentTenant() tenantId: string,
  ) {
    return this.ordersService.refund(tenantId, id, amount);
  }

  @Patch(':id/tracking')
  @Roles('tenant_admin', 'manager', 'staff')
  updateTracking(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() tracking: any,
    @CurrentTenant() tenantId: string,
  ) {
    return this.ordersService.updateTracking(tenantId, id, tracking);
  }
}
