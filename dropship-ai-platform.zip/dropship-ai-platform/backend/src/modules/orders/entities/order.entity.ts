// ─── order.entity.ts ──────────────────────────────────────────────────────────
import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn, ManyToOne,
  OneToMany, JoinColumn,
} from 'typeorm';
import { Customer } from '../../customers/entities/customer.entity';
import { Supplier } from '../../suppliers/entities/supplier.entity';
import { OrderItem } from './order-item.entity';
import { Payment } from '../../payments/entities/payment.entity';

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'customer_id', nullable: true }) customerId: string;
  @Column({ name: 'order_number', nullable: true }) orderNumber: string;
  @Column({ default: 'pending' }) status: string;
  @Column({ name: 'payment_status', default: 'pending' }) paymentStatus: string;
  @Column({ name: 'subtotal', type: 'numeric', precision: 12, scale: 2, default: 0 }) subtotal: number;
  @Column({ name: 'discount_total', type: 'numeric', precision: 12, scale: 2, default: 0 }) discountTotal: number;
  @Column({ name: 'shipping_total', type: 'numeric', precision: 12, scale: 2, default: 0 }) shippingTotal: number;
  @Column({ name: 'tax_total', type: 'numeric', precision: 12, scale: 2, default: 0 }) taxTotal: number;
  @Column({ type: 'numeric', precision: 12, scale: 2, default: 0 }) total: number;
  @Column({ default: 'USD' }) currency: string;
  @Column({ name: 'billing_address', type: 'jsonb', default: {} }) billingAddress: object;
  @Column({ name: 'shipping_address', type: 'jsonb', default: {} }) shippingAddress: object;
  @Column({ name: 'supplier_id', nullable: true }) supplierId: string;
  @Column({ name: 'tracking_number', nullable: true }) trackingNumber: string;
  @Column({ name: 'tracking_url', nullable: true }) trackingUrl: string;
  @Column({ nullable: true }) carrier: string;
  @Column({ name: 'shipped_at', nullable: true }) shippedAt: Date;
  @Column({ name: 'delivered_at', nullable: true }) deliveredAt: Date;
  @Column({ name: 'estimated_delivery', nullable: true }) estimatedDelivery: Date;
  @Column({ name: 'cancelled_at', nullable: true }) cancelledAt: Date;
  @Column({ name: 'cancellation_reason', nullable: true }) cancellationReason: string;
  @Column({ name: 'refunded_at', nullable: true }) refundedAt: Date;
  @Column({ name: 'refund_amount', type: 'numeric', precision: 12, scale: 2, nullable: true }) refundAmount: number;
  @Column({ name: 'customer_note', nullable: true }) customerNote: string;
  @Column({ name: 'internal_note', nullable: true }) internalNote: string;
  @Column({ type: 'jsonb', default: {} }) metadata: object;

  @ManyToOne(() => Customer, { nullable: true }) @JoinColumn({ name: 'customer_id' }) customer: Customer;
  @ManyToOne(() => Supplier, { nullable: true }) @JoinColumn({ name: 'supplier_id' }) supplier: Supplier;
  @OneToMany(() => OrderItem, (i) => i.order) items: OrderItem[];
  @OneToMany(() => Payment, (p) => p.order) payments: Payment[];

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── order-item.entity.ts ─────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Product } from '../../products/entities/product.entity';
import { ProductVariant } from '../../products/entities/product-variant.entity';

@Entity('order_items')
export class OrderItem {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'order_id' }) orderId: string;
  @Column({ name: 'order_created_at' }) orderCreatedAt: Date;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'product_id', nullable: true }) productId: string;
  @Column({ name: 'variant_id', nullable: true }) variantId: string;
  @Column({ name: 'supplier_id', nullable: true }) supplierId: string;
  @Column({ name: 'product_name', length: 500 }) productName: string;
  @Column({ name: 'product_image', nullable: true }) productImage: string;
  @Column({ nullable: true }) sku: string;
  @Column({ default: 1 }) quantity: number;
  @Column({ name: 'unit_price', type: 'numeric', precision: 10, scale: 2 }) unitPrice: number;
  @Column({ name: 'cost_price', type: 'numeric', precision: 10, scale: 2, default: 0 }) costPrice: number;
  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 }) discount: number;
  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 }) tax: number;
  @Column({ type: 'numeric', precision: 10, scale: 2 }) total: number;
  @Column({ name: 'fulfillment_status', default: 'pending' }) fulfillmentStatus: string;
  @Column({ type: 'jsonb', default: {} }) metadata: object;

  @ManyToOne(() => Order) @JoinColumn([{ name: 'order_id', referencedColumnName: 'id' }]) order: Order;
  @ManyToOne(() => Product, { nullable: true }) @JoinColumn({ name: 'product_id' }) product: Product;
  @ManyToOne(() => ProductVariant, { nullable: true }) @JoinColumn({ name: 'variant_id' }) variant: ProductVariant;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
