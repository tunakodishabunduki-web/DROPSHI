import {
  Injectable, NotFoundException, BadRequestException,
  ConflictException, Inject,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { Order } from './entities/order.entity';
import { OrderItem } from './entities/order-item.entity';
import { Customer } from '../customers/entities/customer.entity';
import { Product } from '../products/entities/product.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { OrderQueryDto } from './dto/order-query.dto';
import { PaymentsService } from '../payments/payments.service';
import { SuppliersService } from '../suppliers/suppliers.service';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order) private ordersRepo: Repository<Order>,
    @InjectRepository(OrderItem) private itemsRepo: Repository<OrderItem>,
    @InjectRepository(Customer) private customersRepo: Repository<Customer>,
    @InjectRepository(Product) private productsRepo: Repository<Product>,
    @InjectQueue('order_queue') private orderQueue: Queue,
    @Inject(CACHE_MANAGER) private cache: Cache,
    private dataSource: DataSource,
    private paymentsService: PaymentsService,
    private suppliersService: SuppliersService,
  ) {}

  // ── Create Order ──────────────────────────────────────────
  async createOrder(tenantId: string, dto: CreateOrderDto, customerId?: string) {
    const qr = this.dataSource.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();

    try {
      // Resolve or create customer
      let customer = customerId
        ? await qr.manager.findOne(Customer, { where: { id: customerId, tenantId } })
        : await this.resolveCustomer(qr, tenantId, dto.customerEmail, dto.customerName);

      // Validate and reserve stock
      const itemsWithProducts = await this.validateAndReserveStock(qr, tenantId, dto.items);

      // Calculate totals
      const subtotal = itemsWithProducts.reduce(
        (sum, i) => sum + i.unitPrice * i.quantity, 0,
      );
      const discountTotal = await this.applyDiscount(tenantId, dto.couponCode, subtotal);
      const shippingTotal = await this.calculateShipping(dto.shippingAddress, itemsWithProducts);
      const taxTotal = this.calculateTax(subtotal - discountTotal, dto.shippingAddress.countryCode);
      const total = subtotal - discountTotal + shippingTotal + taxTotal;

      // Create order
      const order = qr.manager.create(Order, {
        tenantId,
        customerId: customer?.id,
        status: 'pending',
        paymentStatus: 'pending',
        subtotal,
        discountTotal,
        shippingTotal,
        taxTotal,
        total,
        currency: dto.currency || 'USD',
        billingAddress: dto.billingAddress || dto.shippingAddress,
        shippingAddress: dto.shippingAddress,
        customerNote: dto.customerNote,
        metadata: dto.metadata || {},
      });

      const savedOrder = await qr.manager.save(Order, order);

      // Create order items
      const orderItems = itemsWithProducts.map((item) =>
        qr.manager.create(OrderItem, {
          orderId: savedOrder.id,
          orderCreatedAt: savedOrder.createdAt,
          tenantId,
          productId: item.productId,
          variantId: item.variantId,
          supplierId: item.product.supplierId,
          productName: item.product.name,
          productImage: item.product.images?.[0],
          sku: item.product.sku,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          costPrice: item.product.costPrice,
          total: item.unitPrice * item.quantity,
        }),
      );

      await qr.manager.save(OrderItem, orderItems);
      await qr.commitTransaction();

      // Queue for fulfillment processing
      await this.orderQueue.add('process_order', {
        orderId: savedOrder.id,
        tenantId,
        paymentMethod: dto.paymentMethod,
      }, { priority: 10 });

      return { ...savedOrder, items: orderItems };
    } catch (e) {
      await qr.rollbackTransaction();
      throw e;
    } finally {
      await qr.release();
    }
  }

  // ── List Orders ───────────────────────────────────────────
  async findAll(tenantId: string, query: OrderQueryDto) {
    const {
      page = 1, limit = 20, status, paymentStatus,
      customerId, dateFrom, dateTo, sortBy = 'createdAt', sortOrder = 'DESC',
    } = query;

    const qb = this.ordersRepo
      .createQueryBuilder('o')
      .leftJoinAndSelect('o.customer', 'customer')
      .leftJoinAndSelect('o.items', 'items')
      .where('o.tenantId = :tenantId', { tenantId });

    if (status) qb.andWhere('o.status = :status', { status });
    if (paymentStatus) qb.andWhere('o.paymentStatus = :paymentStatus', { paymentStatus });
    if (customerId) qb.andWhere('o.customerId = :customerId', { customerId });
    if (dateFrom) qb.andWhere('o.createdAt >= :dateFrom', { dateFrom });
    if (dateTo) qb.andWhere('o.createdAt <= :dateTo', { dateTo });

    qb.orderBy(`o.${sortBy}`, sortOrder as 'ASC' | 'DESC');
    qb.skip((page - 1) * limit).take(limit);

    const [data, total] = await qb.getManyAndCount();
    return { data, meta: { total, page, limit, totalPages: Math.ceil(total / limit) } };
  }

  // ── Find One ──────────────────────────────────────────────
  async findOne(tenantId: string, id: string) {
    const order = await this.ordersRepo.findOne({
      where: { id, tenantId } as any,
      relations: ['items', 'customer', 'supplier', 'payments'],
    });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  // ── Update Status ─────────────────────────────────────────
  async updateStatus(tenantId: string, id: string, status: string, meta?: any) {
    const order = await this.findOne(tenantId, id);
    const validTransitions: Record<string, string[]> = {
      pending: ['confirmed', 'cancelled'],
      confirmed: ['processing', 'cancelled'],
      processing: ['shipped', 'cancelled'],
      shipped: ['delivered'],
      delivered: ['refunded', 'disputed'],
    };

    if (!validTransitions[order.status]?.includes(status)) {
      throw new BadRequestException(
        `Cannot transition from ${order.status} to ${status}`,
      );
    }

    const update: Partial<Order> = { status: status as any };
    if (status === 'shipped') update.shippedAt = new Date();
    if (status === 'delivered') update.deliveredAt = new Date();
    if (status === 'cancelled') {
      update.cancelledAt = new Date();
      update.cancellationReason = meta?.reason;
      await this.releaseStockReservation(order);
    }

    await this.ordersRepo.update({ id, tenantId } as any, update);

    // Queue notifications
    await this.orderQueue.add('order_status_changed', {
      orderId: id,
      tenantId,
      oldStatus: order.status,
      newStatus: status,
    });

    return { ...order, status };
  }

  // ── Cancel Order ──────────────────────────────────────────
  async cancel(tenantId: string, id: string, reason: string) {
    return this.updateStatus(tenantId, id, 'cancelled', { reason });
  }

  // ── Process Refund ────────────────────────────────────────
  async refund(tenantId: string, id: string, amount?: number) {
    const order = await this.findOne(tenantId, id);

    if (!['delivered', 'shipped'].includes(order.status)) {
      throw new BadRequestException('Order cannot be refunded in current status');
    }

    const refundAmount = amount || order.total;
    const refund = await this.paymentsService.processRefund(
      tenantId, order, refundAmount,
    );

    await this.ordersRepo.update({ id, tenantId } as any, {
      status: amount && amount < order.total ? 'partially_refunded' : 'refunded',
      refundedAt: new Date(),
      refundAmount,
    });

    return refund;
  }

  // ── Track Shipment ────────────────────────────────────────
  async updateTracking(tenantId: string, id: string, tracking: {
    trackingNumber: string;
    carrier: string;
    trackingUrl?: string;
    estimatedDelivery?: Date;
  }) {
    await this.ordersRepo.update({ id, tenantId } as any, {
      trackingNumber: tracking.trackingNumber,
      carrier: tracking.carrier,
      trackingUrl: tracking.trackingUrl,
      estimatedDelivery: tracking.estimatedDelivery,
    });

    // Notify customer
    await this.orderQueue.add('send_tracking_notification', { orderId: id, tenantId, tracking });
    return { success: true, tracking };
  }

  // ── Analytics ─────────────────────────────────────────────
  async getAnalytics(tenantId: string, dateFrom: Date, dateTo: Date) {
    const result = await this.dataSource.query(
      `
      SELECT
        DATE_TRUNC('day', o.created_at) as date,
        COUNT(*) as orders,
        SUM(o.total) as revenue,
        AVG(o.total) as avg_order_value,
        COUNT(DISTINCT o.customer_id) as unique_customers
      FROM orders o
      WHERE o.tenant_id = $1
        AND o.created_at BETWEEN $2 AND $3
        AND o.status NOT IN ('cancelled', 'refunded')
      GROUP BY DATE_TRUNC('day', o.created_at)
      ORDER BY date ASC
      `,
      [tenantId, dateFrom, dateTo],
    );
    return result;
  }

  // ── Helpers ───────────────────────────────────────────────
  private async validateAndReserveStock(qr: any, tenantId: string, items: any[]) {
    const result = [];

    for (const item of items) {
      const product = await qr.manager.findOne(Product, {
        where: { id: item.productId, tenantId },
      });

      if (!product) throw new NotFoundException(`Product ${item.productId} not found`);
      if (product.trackInventory && product.stockQuantity - product.stockReserved < item.quantity) {
        throw new BadRequestException(`Insufficient stock for ${product.name}`);
      }

      // Reserve stock
      await qr.manager.increment(Product, { id: item.productId }, 'stockReserved', item.quantity);

      result.push({
        ...item,
        product,
        unitPrice: item.unitPrice || product.salePrice || product.basePrice,
      });
    }

    return result;
  }

  private async releaseStockReservation(order: Order) {
    for (const item of order.items || []) {
      await this.productsRepo.decrement(
        { id: item.productId },
        'stockReserved',
        item.quantity,
      );
    }
  }

  private async resolveCustomer(qr: any, tenantId: string, email: string, name: string) {
    let customer = await qr.manager.findOne(Customer, { where: { email, tenantId } });
    if (!customer) {
      const [firstName, ...rest] = name?.split(' ') || ['Guest'];
      customer = await qr.manager.save(Customer, {
        tenantId,
        email,
        firstName,
        lastName: rest.join(' ') || '',
      });
    }
    return customer;
  }

  private async applyDiscount(tenantId: string, code?: string, subtotal?: number) {
    if (!code) return 0;
    // TODO: Implement coupon validation
    return 0;
  }

  private async calculateShipping(address: any, items: any[]) {
    // TODO: Integrate with Shippo/EasyPost
    return 9.99;
  }

  private calculateTax(amount: number, countryCode: string) {
    const rates: Record<string, number> = {
      US: 0.08, GB: 0.20, TZ: 0.18, KE: 0.16, DE: 0.19,
    };
    return amount * (rates[countryCode] || 0);
  }
}
