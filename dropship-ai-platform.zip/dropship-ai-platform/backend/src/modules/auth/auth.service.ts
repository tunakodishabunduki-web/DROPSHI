import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import * as argon2 from 'argon2';
import * as crypto from 'crypto';
import { User } from '../users/entities/user.entity';
import { RefreshToken } from './entities/refresh-token.entity';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private usersRepo: Repository<User>,
    @InjectRepository(RefreshToken) private refreshRepo: Repository<RefreshToken>,
    private jwtService: JwtService,
    private config: ConfigService,
  ) {}

  // ── Register ─────────────────────────────────────────────
  async register(dto: RegisterDto, tenantId: string) {
    const existing = await this.usersRepo.findOne({
      where: { email: dto.email, tenantId },
    });
    if (existing) throw new ConflictException('Email already registered');

    const passwordHash = await argon2.hash(dto.password, {
      type: argon2.argon2id,
      memoryCost: 65536,
      timeCost: 3,
      parallelism: 4,
    });

    const user = this.usersRepo.create({
      ...dto,
      tenantId,
      passwordHash,
      role: 'customer',
      status: 'pending_verification',
    });

    await this.usersRepo.save(user);
    const tokens = await this.generateTokenPair(user);

    return {
      user: this.sanitizeUser(user),
      ...tokens,
    };
  }

  // ── Login ────────────────────────────────────────────────
  async login(dto: LoginDto, tenantId: string, ip?: string, userAgent?: string) {
    const user = await this.usersRepo.findOne({
      where: { email: dto.email, tenantId },
    });

    if (!user) throw new UnauthorizedException('Invalid credentials');
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      throw new ForbiddenException('Account temporarily locked');
    }

    const valid = await argon2.verify(user.passwordHash, dto.password);
    if (!valid) {
      await this.handleFailedLogin(user);
      throw new UnauthorizedException('Invalid credentials');
    }

    // Reset failed attempts on success
    if (user.failedLoginAttempts > 0) {
      await this.usersRepo.update(user.id, {
        failedLoginAttempts: 0,
        lockedUntil: null,
        lastLoginAt: new Date(),
        lastLoginIp: ip,
      });
    }

    const tokens = await this.generateTokenPair(user, ip, userAgent);
    return { user: this.sanitizeUser(user), ...tokens };
  }

  // ── Refresh Token ────────────────────────────────────────
  async refresh(refreshToken: string) {
    let payload: any;
    try {
      payload = this.jwtService.verify(refreshToken, {
        secret: this.config.get('JWT_REFRESH_SECRET'),
      });
    } catch {
      throw new UnauthorizedException('Invalid refresh token');
    }

    const tokenHash = this.hashToken(refreshToken);
    const stored = await this.refreshRepo.findOne({
      where: { tokenHash },
      relations: ['user'],
    });

    if (!stored || stored.revoked || stored.expiresAt < new Date()) {
      // Token reuse detected — revoke entire family
      if (stored) {
        await this.refreshRepo.update({ family: stored.family }, { revoked: true });
      }
      throw new UnauthorizedException('Refresh token compromised');
    }

    // Rotate: revoke old, issue new
    await this.refreshRepo.update(stored.id, { revoked: true });
    const tokens = await this.generateTokenPair(stored.user);

    return { user: this.sanitizeUser(stored.user), ...tokens };
  }

  // ── Logout ───────────────────────────────────────────────
  async logout(refreshToken: string) {
    const tokenHash = this.hashToken(refreshToken);
    await this.refreshRepo.update({ tokenHash }, { revoked: true });
  }

  // ── OAuth ────────────────────────────────────────────────
  async oauthLogin(profile: any, tenantId: string) {
    let user = await this.usersRepo.findOne({
      where: {
        oauthProvider: profile.provider,
        oauthProviderId: profile.id,
        tenantId,
      },
    });

    if (!user) {
      user = await this.usersRepo.findOne({
        where: { email: profile.email, tenantId },
      });

      if (user) {
        await this.usersRepo.update(user.id, {
          oauthProvider: profile.provider,
          oauthProviderId: profile.id,
        });
      } else {
        user = await this.usersRepo.save(
          this.usersRepo.create({
            tenantId,
            email: profile.email,
            firstName: profile.firstName,
            lastName: profile.lastName,
            avatarUrl: profile.picture,
            oauthProvider: profile.provider,
            oauthProviderId: profile.id,
            emailVerified: true,
            status: 'active',
            role: 'customer',
          }),
        );
      }
    }

    return this.generateTokenPair(user);
  }

  // ── Validate User (for LocalStrategy) ────────────────────
  async validateUser(email: string, password: string, tenantId: string) {
    const user = await this.usersRepo.findOne({ where: { email, tenantId } });
    if (!user || !user.passwordHash) return null;

    const valid = await argon2.verify(user.passwordHash, password);
    return valid ? user : null;
  }

  // ── Helpers ───────────────────────────────────────────────
  private async generateTokenPair(user: User, ip?: string, userAgent?: string) {
    const payload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      tenantId: user.tenantId,
    };

    const accessToken = this.jwtService.sign(payload);

    const refreshTokenRaw = crypto.randomBytes(64).toString('hex');
    const tokenHash = this.hashToken(refreshTokenRaw);
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await this.refreshRepo.save(
      this.refreshRepo.create({
        userId: user.id,
        tokenHash,
        expiresAt,
        ipAddress: ip,
        userAgent,
      }),
    );

    return { accessToken, refreshToken: refreshTokenRaw };
  }

  private hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  private async handleFailedLogin(user: User) {
    const attempts = user.failedLoginAttempts + 1;
    const update: Partial<User> = { failedLoginAttempts: attempts };

    if (attempts >= 5) {
      const lockUntil = new Date();
      lockUntil.setMinutes(lockUntil.getMinutes() + 15 * Math.pow(2, attempts - 5));
      update.lockedUntil = lockUntil;
    }

    await this.usersRepo.update(user.id, update);
  }

  private sanitizeUser(user: User) {
    const { passwordHash, twoFactorSecret, ...safe } = user as any;
    return safe;
  }
}
