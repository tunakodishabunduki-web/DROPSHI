// ─── register.dto.ts ──────────────────────────────────────────────────────────
import { IsEmail, IsString, MinLength, MaxLength, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({ example: 'john@example.com' })
  @IsEmail()
  email: string;

  @ApiProperty({ minLength: 8 })
  @IsString()
  @MinLength(8)
  @MaxLength(128)
  password: string;

  @ApiProperty({ example: 'John' })
  @IsString()
  @MaxLength(100)
  firstName: string;

  @ApiProperty({ example: 'Doe' })
  @IsString()
  @MaxLength(100)
  lastName: string;

  @IsOptional()
  @IsString()
  phone?: string;
}

// ─── login.dto.ts ─────────────────────────────────────────────────────────────
import { IsEmail, IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class LoginDto {
  @ApiProperty({ example: 'john@example.com' })
  @IsEmail()
  email: string;

  @ApiProperty()
  @IsString()
  @MinLength(1)
  password: string;
}

// ─── create-product.dto.ts ────────────────────────────────────────────────────
import {
  IsString, IsNumber, IsOptional, IsArray,
  IsBoolean, IsUUID, MaxLength, Min, IsEnum,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateProductDto {
  @ApiProperty() @IsString() @MaxLength(500) name: string;
  @ApiProperty() @IsString() @MaxLength(100) sku: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() description?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() shortDescription?: string;
  @ApiProperty() @IsNumber() @Min(0) @Type(() => Number) basePrice: number;
  @ApiProperty({ required: false }) @IsOptional() @IsNumber() @Min(0) @Type(() => Number) costPrice?: number;
  @ApiProperty({ required: false }) @IsOptional() @IsNumber() @Min(0) @Type(() => Number) salePrice?: number;
  @ApiProperty({ required: false }) @IsOptional() @IsNumber() @Min(0) @Type(() => Number) stockQuantity?: number;
  @ApiProperty({ required: false }) @IsOptional() @IsUUID() supplierId?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsUUID() categoryId?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsArray() images?: string[];
  @ApiProperty({ required: false }) @IsOptional() @IsArray() tags?: string[];
  @ApiProperty({ required: false }) @IsOptional() @IsBoolean() variantsEnabled?: boolean;
  @ApiProperty({ required: false }) @IsOptional() @IsString() supplierSku?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() supplierUrl?: string;
  @ApiProperty({ required: false }) @IsOptional() priceChangeReason?: string;
}

// ─── update-product.dto.ts ────────────────────────────────────────────────────
import { PartialType } from '@nestjs/mapped-types';
export class UpdateProductDto extends PartialType(CreateProductDto) {}

// ─── product-query.dto.ts ─────────────────────────────────────────────────────
import { IsOptional, IsString, IsNumber, IsArray, Min, Max } from 'class-validator';
import { Type } from 'class-transformer';

export class ProductQueryDto {
  @IsOptional() @IsNumber() @Min(1) @Type(() => Number) page?: number = 1;
  @IsOptional() @IsNumber() @Min(1) @Max(100) @Type(() => Number) limit?: number = 20;
  @IsOptional() @IsString() search?: string;
  @IsOptional() @IsString() status?: string;
  @IsOptional() @IsString() categoryId?: string;
  @IsOptional() @IsString() supplierId?: string;
  @IsOptional() @IsNumber() @Type(() => Number) minPrice?: number;
  @IsOptional() @IsNumber() @Type(() => Number) maxPrice?: number;
  @IsOptional() sortBy?: string;
  @IsOptional() sortOrder?: 'ASC' | 'DESC';
  @IsOptional() @IsArray() tags?: string[];
}

// ─── bulk-update-price.dto.ts ─────────────────────────────────────────────────
import { IsArray, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class PriceUpdateItem {
  @IsString() productId: string;
  @IsNumber() @Min(0) @Type(() => Number) price: number;
}

export class BulkUpdatePriceDto {
  @IsArray() @ValidateNested({ each: true }) @Type(() => PriceUpdateItem) updates: PriceUpdateItem[];
  @IsString() strategy: string;
  @IsOptional() @IsString() reason?: string;
}

// ─── order-query.dto.ts ───────────────────────────────────────────────────────
export class OrderQueryDto {
  @IsOptional() @IsNumber() @Min(1) @Type(() => Number) page?: number = 1;
  @IsOptional() @IsNumber() @Min(1) @Max(100) @Type(() => Number) limit?: number = 20;
  @IsOptional() @IsString() status?: string;
  @IsOptional() @IsString() paymentStatus?: string;
  @IsOptional() @IsString() customerId?: string;
  @IsOptional() dateFrom?: Date;
  @IsOptional() dateTo?: Date;
  @IsOptional() sortBy?: string;
  @IsOptional() sortOrder?: 'ASC' | 'DESC';
}

// ─── create-order.dto.ts ──────────────────────────────────────────────────────
export class CreateOrderDto {
  @IsArray() items: any[];
  @IsOptional() @IsString() customerEmail?: string;
  @IsOptional() @IsString() customerName?: string;
  shippingAddress: any;
  @IsOptional() billingAddress?: any;
  @IsOptional() @IsString() couponCode?: string;
  @IsOptional() @IsString() currency?: string;
  @IsOptional() @IsString() paymentMethod?: string;
  @IsOptional() @IsString() customerNote?: string;
  @IsOptional() metadata?: object;
}
