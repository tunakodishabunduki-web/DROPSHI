// ─── auth.service.spec.ts ─────────────────────────────────────────────────────
import { Test, TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { getRepositoryToken } from '@nestjs/typeorm';
import { ConfigService } from '@nestjs/config';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { AuthService } from '../../src/modules/auth/auth.service';
import { User } from '../../src/modules/users/entities/user.entity';
import { RefreshToken } from '../../src/modules/auth/entities/refresh-token.entity';

jest.mock('argon2');

const mockUserRepo = () => ({
  findOne: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  update: jest.fn(),
});

const mockRefreshRepo = () => ({
  findOne: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  update: jest.fn(),
});

describe('AuthService', () => {
  let service: AuthService;
  let usersRepo: ReturnType<typeof mockUserRepo>;
  let refreshRepo: ReturnType<typeof mockRefreshRepo>;
  let jwtService: JwtService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: getRepositoryToken(User), useFactory: mockUserRepo },
        { provide: getRepositoryToken(RefreshToken), useFactory: mockRefreshRepo },
        {
          provide: JwtService,
          useValue: { sign: jest.fn().mockReturnValue('mock.access.token'), verify: jest.fn() },
        },
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn((key: string) => {
              const map: Record<string, string> = {
                JWT_SECRET: 'test_secret',
                JWT_REFRESH_SECRET: 'test_refresh_secret',
                JWT_EXPIRES_IN: '15m',
              };
              return map[key];
            }),
          },
        },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    usersRepo = module.get(getRepositoryToken(User));
    refreshRepo = module.get(getRepositoryToken(RefreshToken));
    jwtService = module.get<JwtService>(JwtService);
  });

  describe('register', () => {
    it('should throw ConflictException if email already exists', async () => {
      usersRepo.findOne.mockResolvedValue({ id: '1', email: 'test@test.com' });
      await expect(service.register({ email: 'test@test.com', password: 'pass', firstName: 'Test', lastName: 'User' } as any, 'tenant-1'))
        .rejects.toThrow(ConflictException);
    });

    it('should create user and return tokens', async () => {
      usersRepo.findOne.mockResolvedValue(null);
      (argon2.hash as jest.Mock).mockResolvedValue('hashed_password');
      const newUser = { id: 'new-id', email: 'new@test.com', firstName: 'New', tenantId: 'tenant-1' };
      usersRepo.create.mockReturnValue(newUser);
      usersRepo.save.mockResolvedValue(newUser);
      refreshRepo.create.mockReturnValue({});
      refreshRepo.save.mockResolvedValue({});

      const result = await service.register({
        email: 'new@test.com', password: 'password123', firstName: 'New', lastName: 'User',
      } as any, 'tenant-1');

      expect(result).toHaveProperty('accessToken');
      expect(result).toHaveProperty('refreshToken');
      expect(result.user).toBeDefined();
    });
  });

  describe('login', () => {
    it('should throw UnauthorizedException for invalid user', async () => {
      usersRepo.findOne.mockResolvedValue(null);
      await expect(service.login({ email: 'x@x.com', password: 'wrong' } as any, 'tenant-1'))
        .rejects.toThrow(UnauthorizedException);
    });

    it('should throw UnauthorizedException for wrong password', async () => {
      usersRepo.findOne.mockResolvedValue({ id: '1', passwordHash: 'hash', failedLoginAttempts: 0 });
      (argon2.verify as jest.Mock).mockResolvedValue(false);
      usersRepo.update.mockResolvedValue(undefined);
      await expect(service.login({ email: 'x@x.com', password: 'wrong' } as any, 'tenant-1'))
        .rejects.toThrow(UnauthorizedException);
    });

    it('should return tokens on valid credentials', async () => {
      const user = { id: '1', email: 'u@u.com', role: 'customer', tenantId: 'tenant-1', passwordHash: 'hash', failedLoginAttempts: 0 };
      usersRepo.findOne.mockResolvedValue(user);
      (argon2.verify as jest.Mock).mockResolvedValue(true);
      usersRepo.update.mockResolvedValue(undefined);
      refreshRepo.create.mockReturnValue({});
      refreshRepo.save.mockResolvedValue({});

      const result = await service.login({ email: 'u@u.com', password: 'pass' } as any, 'tenant-1');
      expect(result.accessToken).toBe('mock.access.token');
    });
  });
});
