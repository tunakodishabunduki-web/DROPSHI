// ─── roles.decorator.ts ───────────────────────────────────────────────────────
import { SetMetadata } from '@nestjs/common';
export const ROLES_KEY = 'roles';
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);

// ─── public.decorator.ts ──────────────────────────────────────────────────────
import { SetMetadata } from '@nestjs/common';
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);

// ─── current-user.decorator.ts ────────────────────────────────────────────────
import { createParamDecorator, ExecutionContext } from '@nestjs/common';
export const CurrentUser = createParamDecorator(
  (data: string | undefined, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    const user = request.user;
    return data ? user?.[data] : user;
  },
);

// ─── current-tenant.decorator.ts ──────────────────────────────────────────────
import { createParamDecorator, ExecutionContext } from '@nestjs/common';
export const CurrentTenant = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): string => {
    const request = ctx.switchToHttp().getRequest();
    return request.tenantId || request.user?.tenantId;
  },
);

// ─── audit-log.decorator.ts ───────────────────────────────────────────────────
import { SetMetadata } from '@nestjs/common';
export const AUDIT_LOG_KEY = 'auditLog';
export const AuditLog = (action: string) => SetMetadata(AUDIT_LOG_KEY, action);
