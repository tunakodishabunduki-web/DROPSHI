// ─── roles.guard.ts ───────────────────────────────────────────────────────────
import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredRoles || requiredRoles.length === 0) return true;

    const { user } = context.switchToHttp().getRequest();
    if (!user) return false;

    // super_admin bypasses all role checks
    if (user.role === 'super_admin') return true;

    const hasRole = requiredRoles.some((role) => user.role === role);
    if (!hasRole) {
      throw new ForbiddenException(
        `Insufficient permissions. Required: ${requiredRoles.join(' or ')}`,
      );
    }

    return true;
  }
}

// ─── tenant.guard.ts ──────────────────────────────────────────────────────────
import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class TenantGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) return true; // Let JwtAuthGuard handle auth errors

    // Ensure tenant matches JWT
    const tenantId = request.headers['x-tenant-id'] || user.tenantId;
    if (!tenantId) throw new UnauthorizedException('Tenant context required');

    // Admins can access any tenant via header, others only their own
    if (user.role !== 'super_admin' && tenantId !== user.tenantId) {
      throw new ForbiddenException('Access denied to this tenant');
    }

    request.tenantId = user.tenantId;
    return true;
  }
}
