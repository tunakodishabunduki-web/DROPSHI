import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';

describe('Orders E2E', () => {
  let app: INestApplication;
  let accessToken: string;
  let tenantId: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.setGlobalPrefix('api');
    app.enableVersioning();
    await app.init();

    // Get auth token
    const loginRes = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .set('x-tenant-id', 'demo')
      .send({ email: 'admin@demo.com', password: 'Admin@1234' });

    accessToken = loginRes.body?.data?.accessToken;
    tenantId = loginRes.body?.data?.user?.tenantId;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('GET /api/v1/orders', () => {
    it('should require authentication', () => {
      return request(app.getHttpServer())
        .get('/api/v1/orders')
        .expect(401);
    });

    it('should return paginated orders', () => {
      return request(app.getHttpServer())
        .get('/api/v1/orders')
        .set('Authorization', `Bearer ${accessToken}`)
        .set('x-tenant-id', tenantId)
        .expect(200)
        .expect((res) => {
          expect(res.body.success).toBe(true);
          expect(res.body.data).toHaveProperty('data');
          expect(res.body.data).toHaveProperty('meta');
          expect(Array.isArray(res.body.data.data)).toBe(true);
        });
    });

    it('should filter by status', () => {
      return request(app.getHttpServer())
        .get('/api/v1/orders?status=pending')
        .set('Authorization', `Bearer ${accessToken}`)
        .set('x-tenant-id', tenantId)
        .expect(200)
        .expect((res) => {
          const orders = res.body.data.data;
          orders.forEach((o: any) => expect(o.status).toBe('pending'));
        });
    });
  });

  describe('POST /api/v1/orders', () => {
    it('should reject invalid order', () => {
      return request(app.getHttpServer())
        .post('/api/v1/orders')
        .set('Authorization', `Bearer ${accessToken}`)
        .set('x-tenant-id', tenantId)
        .send({ items: [] }) // Missing required fields
        .expect(400);
    });
  });

  describe('GET /api/v1/analytics/dashboard', () => {
    it('should return dashboard stats', () => {
      return request(app.getHttpServer())
        .get('/api/v1/analytics/dashboard')
        .set('Authorization', `Bearer ${accessToken}`)
        .set('x-tenant-id', tenantId)
        .expect(200)
        .expect((res) => {
          expect(res.body.success).toBe(true);
          expect(res.body.data).toHaveProperty('revenue');
          expect(res.body.data).toHaveProperty('orders');
        });
    });
  });

  describe('GET /api/v1/products', () => {
    it('should return products with pagination', () => {
      return request(app.getHttpServer())
        .get('/api/v1/products?page=1&limit=10')
        .set('Authorization', `Bearer ${accessToken}`)
        .set('x-tenant-id', tenantId)
        .expect(200)
        .expect((res) => {
          expect(res.body.data.meta.limit).toBe(10);
        });
    });
  });

  describe('GET /api/v1/health', () => {
    it('should return healthy status', () => {
      return request(app.getHttpServer())
        .get('/api/v1/health')
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('status');
        });
    });
  });
});
