'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Megaphone, Plus, Zap, BarChart2, TrendingUp,
  Play, Pause, RefreshCw, ExternalLink, Loader2,
} from 'lucide-react';
import { aiApi } from '@/lib/api';
import { formatCurrency, formatNumber } from '@/lib/utils';

const PLATFORMS = ['tiktok', 'instagram', 'facebook', 'google'];
const TONES = ['urgent', 'playful', 'professional', 'luxury', 'minimal'];
const PLATFORM_COLORS: Record<string, string> = {
  tiktok: 'bg-black text-white',
  instagram: 'bg-gradient-to-br from-purple-500 to-pink-500 text-white',
  facebook: 'bg-blue-600 text-white',
  google: 'bg-white text-gray-700 border border-gray-200',
};

export default function MarketingPage() {
  const qc = useQueryClient();
  const [genForm, setGenForm] = useState({
    productId: '',
    platforms: ['tiktok', 'instagram'] as string[],
    tone: 'playful',
    targetAudience: { ageRange: '18-35', interests: ['shopping', 'lifestyle'] },
    budget: 50,
  });
  const [generatedAds, setGeneratedAds] = useState<any[]>([]);

  const { data: analytics } = useQuery({
    queryKey: ['marketing-analytics'],
    queryFn: aiApi.getAdAnalytics,
  });

  const generateMutation = useMutation({
    mutationFn: (dto: any) => aiApi.generateAdCopy(dto),
    onSuccess: (res: any) => {
      setGeneratedAds(res?.data?.creatives || []);
      qc.invalidateQueries({ queryKey: ['marketing-analytics'] });
    },
  });

  const analyticsData: any[] = (analytics as any)?.data || MOCK_ANALYTICS;

  const togglePlatform = (p: string) => {
    setGenForm((f) => ({
      ...f,
      platforms: f.platforms.includes(p) ? f.platforms.filter((x) => x !== p) : [...f.platforms, p],
    }));
  };

  return (
    <div className="space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Marketing AI</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Generate ad creatives, schedule campaigns, and track performance
          </p>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {analyticsData.map((p: any) => (
          <div key={p.platform} className="stat-card">
            <div className="flex items-center gap-2 mb-3">
              <span className={`px-2 py-0.5 text-xs font-bold rounded-md capitalize ${PLATFORM_COLORS[p.platform] || 'bg-muted'}`}>
                {p.platform}
              </span>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Impressions</span>
                <span className="font-semibold">{formatNumber(p.impressions || p.total_impressions || 0)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Clicks</span>
                <span className="font-semibold">{formatNumber(p.clicks || p.total_clicks || 0)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">CTR</span>
                <span className="font-semibold text-brand-500">
                  {((p.ctr || (p.total_clicks / (p.total_impressions || 1))) * 100).toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">ROAS</span>
                <span className="font-semibold text-emerald-500">
                  {(p.roas || p.avg_roas || 0).toFixed(2)}x
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Ad Generator */}
        <div className="stat-card space-y-5">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-brand-500" />
            <h3 className="font-semibold">AI Ad Generator</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Product ID</label>
              <input
                value={genForm.productId}
                onChange={(e) => setGenForm((f) => ({ ...f, productId: e.target.value }))}
                placeholder="Paste product UUID..."
                className="w-full px-3 py-2 text-sm rounded-lg bg-muted border-0 outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Platforms</label>
              <div className="flex flex-wrap gap-2">
                {PLATFORMS.map((p) => (
                  <button key={p} onClick={() => togglePlatform(p)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors ${
                      genForm.platforms.includes(p) ? 'bg-brand-500 text-white' : 'bg-muted text-muted-foreground hover:text-foreground'
                    }`}>
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Tone</label>
              <div className="flex flex-wrap gap-2">
                {TONES.map((t) => (
                  <button key={t} onClick={() => setGenForm((f) => ({ ...f, tone: t }))}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors ${
                      genForm.tone === t ? 'bg-brand-500 text-white' : 'bg-muted text-muted-foreground hover:text-foreground'
                    }`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">
                Daily Budget: ${genForm.budget}
              </label>
              <input type="range" min="5" max="500" step="5" value={genForm.budget}
                onChange={(e) => setGenForm((f) => ({ ...f, budget: +e.target.value }))}
                className="w-full accent-brand-500" />
            </div>

            <button
              onClick={() => generateMutation.mutate(genForm)}
              disabled={generateMutation.isPending || !genForm.productId}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium transition-colors disabled:opacity-50">
              {generateMutation.isPending
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</>
                : <><Zap className="w-4 h-4" /> Generate Ad Creatives</>}
            </button>
          </div>
        </div>

        {/* Generated Ads */}
        <div className="stat-card">
          <h3 className="font-semibold mb-4">Generated Creatives</h3>
          {generatedAds.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-center">
              <Megaphone className="w-10 h-10 text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">
                Enter a product ID and click Generate to create AI ad copy
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[400px] overflow-y-auto scrollbar-thin pr-1">
              {generatedAds.map((ad: any, i: number) => (
                <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="p-3.5 rounded-lg border border-border bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-0.5 text-xs font-bold rounded capitalize ${PLATFORM_COLORS[ad.platform] || 'bg-muted'}`}>
                      {ad.platform}
                    </span>
                    <span className="text-xs text-emerald-500 font-semibold">Score: {ad.score}/100</span>
                  </div>
                  <p className="text-sm font-semibold mb-1">{ad.headline}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{ad.body}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs font-medium text-brand-500">{ad.cta}</span>
                    {ad.hashtags?.length > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {ad.hashtags.slice(0, 2).map((h: string) => `#${h}`).join(' ')}
                      </span>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const MOCK_ANALYTICS = [
  { platform: 'tiktok', total_impressions: 124500, total_clicks: 4820, ctr: 0.0387, avg_roas: 3.2 },
  { platform: 'instagram', total_impressions: 98200, total_clicks: 3640, ctr: 0.0371, avg_roas: 2.8 },
  { platform: 'facebook', total_impressions: 76000, total_clicks: 2190, ctr: 0.0288, avg_roas: 2.4 },
  { platform: 'google', total_impressions: 52000, total_clicks: 2860, ctr: 0.0550, avg_roas: 4.1 },
];
