'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Truck, Plus, RefreshCw, CheckCircle, AlertCircle,
  Clock, Zap, BarChart2, Edit, Trash2, Activity,
} from 'lucide-react';
import { suppliersApi, aiApi } from '@/lib/api';
import { formatRelativeTime } from '@/lib/utils';

const STATUS_COLORS: Record<string, string> = {
  active: 'badge-success',
  inactive: 'badge-neutral',
  suspended: 'badge-danger',
  pending_review: 'badge-warning',
};

export default function SuppliersPage() {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', apiType: 'aliexpress', website: '', contactEmail: '' });

  const { data, isLoading } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => suppliersApi.list(),
  });

  const { data: health } = useQuery({
    queryKey: ['supplier-health'],
    queryFn: aiApi.monitorHealth,
    refetchInterval: 60_000,
  });

  const syncMutation = useMutation({
    mutationFn: aiApi.syncAll,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['suppliers'] }),
  });

  const createMutation = useMutation({
    mutationFn: (dto: any) => suppliersApi.create(dto),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['suppliers'] });
      setShowForm(false);
      setForm({ name: '', apiType: 'aliexpress', website: '', contactEmail: '' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => suppliersApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['suppliers'] }),
  });

  const suppliers: any[] = (data as any)?.data || [];
  const healthData: any[] = (health as any)?.data || [];

  const getHealthStatus = (supplierId: string) =>
    healthData.find((h: any) => h.supplierId === supplierId);

  return (
    <div className="space-y-5 max-w-[1400px]">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Suppliers</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {suppliers.length} connected · Sync runs every 60 min
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => syncMutation.mutate()}
            disabled={syncMutation.isPending}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm hover:bg-muted transition-colors disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
            Sync All
          </button>
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Add Supplier
          </button>
        </div>
      </div>

      {/* Add supplier form */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="stat-card border-brand-500/30"
        >
          <h3 className="font-semibold text-sm mb-4">New Supplier</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { key: 'name', label: 'Supplier Name', type: 'text', placeholder: 'e.g. AliExpress Store' },
              { key: 'website', label: 'Website / Shop URL', type: 'url', placeholder: 'https://...' },
              { key: 'contactEmail', label: 'Contact Email', type: 'email', placeholder: 'supplier@example.com' },
            ].map((f) => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">{f.label}</label>
                <input
                  type={f.type} placeholder={f.placeholder}
                  value={(form as any)[f.key]}
                  onChange={(e) => setForm((p) => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30"
                />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">API Type</label>
              <select
                value={form.apiType}
                onChange={(e) => setForm((p) => ({ ...p, apiType: e.target.value }))}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                {['aliexpress', 'shopify', 'amazon', 'custom'].map((t) => (
                  <option key={t} value={t} className="capitalize">{t}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => createMutation.mutate(form)}
              disabled={createMutation.isPending || !form.name}
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-60"
            >
              {createMutation.isPending ? 'Adding...' : 'Add Supplier'}
            </button>
            <button
              onClick={() => setShowForm(false)}
              className="px-4 py-2 border border-border text-sm rounded-lg hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      )}

      {/* Supplier cards */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="stat-card space-y-3">
              <div className="skeleton h-5 w-32 rounded" />
              <div className="skeleton h-4 w-full rounded" />
              <div className="skeleton h-4 w-2/3 rounded" />
            </div>
          ))}
        </div>
      ) : suppliers.length === 0 ? (
        <div className="stat-card flex flex-col items-center justify-center py-16 text-center">
          <Truck className="w-12 h-12 text-muted-foreground/30 mb-4" />
          <p className="font-medium text-muted-foreground">No suppliers connected yet</p>
          <p className="text-sm text-muted-foreground mt-1">
            Add your first supplier to start importing products
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="mt-4 px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors"
          >
            Add Supplier
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {(suppliers.length ? suppliers : MOCK_SUPPLIERS).map((supplier: any, i: number) => {
            const h = getHealthStatus(supplier.id);
            const isHealthy = h?.status === 'healthy';

            return (
              <motion.div
                key={supplier.id || i}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.07 }}
                className="stat-card group"
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center flex-shrink-0">
                      <Truck className="w-5 h-5 text-brand-500" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{supplier.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{supplier.apiType}</p>
                    </div>
                  </div>
                  <span className={STATUS_COLORS[supplier.status] || 'badge-neutral'}>
                    {supplier.status?.replace('_', ' ')}
                  </span>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center">
                    <p className="text-lg font-bold">
                      {((supplier.reliabilityScore || 0) * 100).toFixed(0)}%
                    </p>
                    <p className="text-xs text-muted-foreground">Reliability</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold">{supplier.avgShipDays || '—'}</p>
                    <p className="text-xs text-muted-foreground">Ship Days</p>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <div className={`w-2 h-2 rounded-full ${isHealthy || !h ? 'bg-emerald-500' : 'bg-red-500'} animate-pulse`} />
                      <p className="text-xs font-medium">{h ? (isHealthy ? 'Up' : 'Down') : 'OK'}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">Health</p>
                  </div>
                </div>

                {/* Reliability bar */}
                <div className="mb-4">
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-brand-500 rounded-full transition-all"
                      style={{ width: `${(supplier.reliabilityScore || 0.8) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {supplier.lastSyncedAt
                      ? `Synced ${formatRelativeTime(supplier.lastSyncedAt)}`
                      : 'Not yet synced'}
                  </span>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {supplier.isPrimary && (
                      <span className="badge-info mr-1">Primary</span>
                    )}
                    <button
                      onClick={() => aiApi.syncSupplier(supplier.id)}
                      className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-brand-500 transition-colors"
                      title="Sync now"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                    <button
                      className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                      title="Edit"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('Remove this supplier?')) deleteMutation.mutate(supplier.id);
                      }}
                      className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Health monitor */}
      {healthData.length > 0 && (
        <div className="stat-card">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-brand-500" />
            <h3 className="font-semibold text-sm">Supplier Health Monitor</h3>
          </div>
          <div className="space-y-2">
            {healthData.map((h: any) => (
              <div key={h.supplierId} className="flex items-center justify-between text-sm py-2 border-b border-border last:border-0">
                <span>{h.name}</span>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">
                    Score: {((h.reliabilityScore || 0) * 100).toFixed(0)}%
                  </span>
                  <span className={h.status === 'healthy' ? 'badge-success' : 'badge-danger'}>
                    {h.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const MOCK_SUPPLIERS = [
  {
    id: '1', name: 'AliExpress Main', apiType: 'aliexpress', status: 'active',
    reliabilityScore: 0.92, avgShipDays: 14, isPrimary: true,
    lastSyncedAt: new Date(Date.now() - 240000),
  },
  {
    id: '2', name: 'Shopify Warehouse', apiType: 'shopify', status: 'active',
    reliabilityScore: 0.88, avgShipDays: 5, isPrimary: false,
    lastSyncedAt: new Date(Date.now() - 3600000),
  },
  {
    id: '3', name: 'Amazon FBA US', apiType: 'amazon', status: 'pending_review',
    reliabilityScore: 0.95, avgShipDays: 3, isPrimary: false,
    lastSyncedAt: null,
  },
];
