'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowLeft, Save, Loader2, Zap, Package } from 'lucide-react';
import { productsApi, suppliersApi } from '@/lib/api';

const schema = z.object({
  name: z.string().min(2, 'Name required'),
  sku: z.string().min(1, 'SKU required'),
  description: z.string().optional(),
  basePrice: z.number().min(0.01, 'Price must be > 0'),
  costPrice: z.number().min(0).optional(),
  salePrice: z.number().min(0).optional(),
  stockQuantity: z.number().min(0).default(0),
  supplierId: z.string().uuid().optional(),
  categoryId: z.string().uuid().optional(),
  tags: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export default function NewProductPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const [imageUrl, setImageUrl] = useState('');

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers-list'],
    queryFn: () => suppliersApi.list(),
  });

  const { register, handleSubmit, formState: { errors }, watch } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { stockQuantity: 0, basePrice: 0, costPrice: 0 },
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => productsApi.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['products'] });
      router.push('/dashboard/products');
    },
  });

  const basePrice = watch('basePrice') || 0;
  const costPrice = watch('costPrice') || 0;
  const margin = basePrice > 0 ? (((basePrice - costPrice) / basePrice) * 100).toFixed(1) : '—';

  const onSubmit = (data: FormValues) => {
    createMutation.mutate({
      ...data,
      images: imageUrl ? [imageUrl] : [],
      tags: data.tags ? data.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
    });
  };

  const supplierList: any[] = (suppliers as any)?.data || [];

  return (
    <div className="max-w-3xl space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => router.back()} className="p-2 rounded-lg hover:bg-muted transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">New Product</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Add a product to your catalog</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        {/* Basic info */}
        <div className="stat-card space-y-4">
          <h3 className="font-semibold text-sm">Basic Information</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Product Name *</label>
              <input {...register('name')} placeholder="e.g. Wireless Earbuds Pro"
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
              {errors.name && <p className="text-xs text-destructive mt-1">{errors.name.message}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">SKU *</label>
              <input {...register('sku')} placeholder="SKU-001"
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 font-mono" />
              {errors.sku && <p className="text-xs text-destructive mt-1">{errors.sku.message}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Tags (comma separated)</label>
              <input {...register('tags')} placeholder="trending, wireless, electronics"
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Description</label>
              <textarea {...register('description')} rows={3} placeholder="Describe your product..."
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 resize-none" />
            </div>
          </div>
        </div>

        {/* Pricing */}
        <div className="stat-card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm">Pricing</h3>
            <div className="text-xs text-muted-foreground">
              Margin:{' '}
              <span className={`font-semibold ${parseFloat(margin) >= 30 ? 'text-emerald-500' : parseFloat(margin) >= 15 ? 'text-amber-500' : 'text-destructive'}`}>
                {margin}%
              </span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {[
              { field: 'basePrice', label: 'Selling Price *', hint: 'What customers pay' },
              { field: 'costPrice', label: 'Cost Price', hint: 'What you pay supplier' },
              { field: 'salePrice', label: 'Sale Price', hint: 'Optional discount price' },
            ].map((f) => (
              <div key={f.field}>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">{f.label}</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                  <input
                    {...register(f.field as any, { valueAsNumber: true })}
                    type="number" step="0.01" min="0" placeholder="0.00"
                    className="w-full pl-7 pr-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{f.hint}</p>
                {(errors as any)[f.field] && <p className="text-xs text-destructive">{(errors as any)[f.field]?.message}</p>}
              </div>
            ))}
          </div>
        </div>

        {/* Inventory */}
        <div className="stat-card space-y-4">
          <h3 className="font-semibold text-sm">Inventory & Supplier</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Stock Quantity</label>
              <input {...register('stockQuantity', { valueAsNumber: true })} type="number" min="0" placeholder="0"
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Supplier</label>
              <select {...register('supplierId')}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30">
                <option value="">No supplier</option>
                {supplierList.map((s: any) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Product Image URL</label>
              <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)}
                type="url" placeholder="https://example.com/image.jpg"
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
          </div>
          {imageUrl && (
            <div className="mt-3 flex items-center gap-3">
              <img src={imageUrl} alt="Preview" className="w-16 h-16 rounded-lg object-cover border border-border" />
              <p className="text-xs text-muted-foreground">Image preview</p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <button type="submit" disabled={createMutation.isPending}
            className="flex items-center gap-2 px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-60">
            {createMutation.isPending
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</>
              : <><Save className="w-4 h-4" /> Save Product</>}
          </button>
          <button type="button" onClick={() => router.back()}
            className="px-4 py-2.5 border border-border text-sm rounded-lg hover:bg-muted transition-colors">
            Cancel
          </button>
          <div className="ml-auto flex items-center gap-1.5 text-xs text-muted-foreground">
            <Zap className="w-3.5 h-3.5 text-brand-500" />
            AI analysis will run automatically after save
          </div>
        </div>

        {createMutation.isError && (
          <p className="text-sm text-destructive">{(createMutation.error as Error).message}</p>
        )}
      </form>
    </div>
  );
}
