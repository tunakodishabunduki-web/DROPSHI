'use client';

import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Plus, Search, Filter, Download, RefreshCw,
  Zap, MoreHorizontal, Edit, Trash2, TrendingUp,
  Package, AlertTriangle, Upload,
} from 'lucide-react';
import { productsApi, aiApi } from '@/lib/api';
import { formatCurrency, getAiScoreColor, debounce } from '@/lib/utils';

const STATUS_OPTS = ['all', 'active', 'inactive', 'draft', 'out_of_stock'];
const STATUS_COLORS: Record<string, string> = {
  active: 'badge-success', inactive: 'badge-neutral',
  draft: 'badge-warning', out_of_stock: 'badge-danger',
};

export default function ProductsPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<string[]>([]);

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['products', { search, status, page }],
    queryFn: () => productsApi.list({ search: search || undefined, status: status === 'all' ? undefined : status, page, limit: 20 }),
  });

  const analyzeMutation = useMutation({
    mutationFn: (id: string) => aiApi.analyzeProduct(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['products'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => productsApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['products'] }),
  });

  const debouncedSearch = useCallback(debounce((v: string) => { setSearch(v); setPage(1); }, 400), []);

  const products: any[] = (data as any)?.data?.data || [];
  const meta: any = (data as any)?.data?.meta || {};

  const toggleSelect = (id: string) =>
    setSelected((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
  const toggleAll = () =>
    setSelected(selected.length === products.length ? [] : products.map((p) => p.id));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Products</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {meta.total || 0} products · {products.filter((p) => p.status === 'active').length} active
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm hover:bg-muted transition-colors">
            <Upload className="w-3.5 h-3.5" /> Import
          </button>
          <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm hover:bg-muted transition-colors">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <a href="/dashboard/products/new"
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium transition-colors">
            <Plus className="w-3.5 h-3.5" /> Add Product
          </a>
        </div>
      </div>

      {/* Filters */}
      <div className="stat-card !p-3 flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input type="text" placeholder="Search products, SKU..."
            onChange={(e) => debouncedSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-2 text-sm rounded-lg bg-muted border-0 outline-none focus:ring-2 focus:ring-brand-500/30 placeholder:text-muted-foreground" />
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {STATUS_OPTS.map((s) => (
            <button key={s} onClick={() => { setStatus(s); setPage(1); }}
              className={`px-3 py-1.5 text-xs rounded-lg capitalize font-medium transition-colors ${status === s ? 'bg-brand-500 text-white' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {s}
            </button>
          ))}
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-muted-foreground hover:text-foreground border border-border rounded-lg transition-colors">
          <Filter className="w-3.5 h-3.5" /> More filters
        </button>
        {isFetching && <RefreshCw className="w-3.5 h-3.5 animate-spin text-muted-foreground ml-auto" />}
      </div>

      {/* Bulk actions */}
      {selected.length > 0 && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 px-4 py-2.5 rounded-lg bg-brand-500/10 border border-brand-500/20 text-sm">
          <span className="font-medium text-brand-600 dark:text-brand-400">{selected.length} selected</span>
          <button onClick={() => analyzeMutation.mutate(selected[0])}
            className="flex items-center gap-1 text-brand-600 dark:text-brand-400 hover:underline">
            <Zap className="w-3.5 h-3.5" /> AI Analyze
          </button>
          <button className="flex items-center gap-1 text-muted-foreground hover:text-foreground">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button className="flex items-center gap-1 text-destructive hover:text-destructive/80">
            <Trash2 className="w-3.5 h-3.5" /> Delete
          </button>
          <button onClick={() => setSelected([])} className="ml-auto text-muted-foreground hover:text-foreground text-xs">
            Clear
          </button>
        </motion.div>
      )}

      {/* Table */}
      <div className="stat-card !p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="w-10 px-4 py-3 text-left">
                  <input type="checkbox" checked={selected.length === products.length && products.length > 0}
                    onChange={toggleAll} className="rounded border-border" />
                </th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Product</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">SKU</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Price</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Stock</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">AI Score</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Status</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading
                ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 8 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 w-full rounded" />
                      </td>
                    ))}
                  </tr>
                ))
                : products.map((product) => (
                  <tr key={product.id} className="hover:bg-muted/30 transition-colors group">
                    <td className="px-4 py-3">
                      <input type="checkbox" checked={selected.includes(product.id)}
                        onChange={() => toggleSelect(product.id)} className="rounded border-border" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                          {product.images?.[0] ? (
                            <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Package className="w-4 h-4 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium truncate max-w-[200px]">{product.name}</p>
                          <p className="text-xs text-muted-foreground">{product.category?.name || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{product.sku}</td>
                    <td className="px-4 py-3">
                      <div>
                        <span className="font-medium">{formatCurrency(product.salePrice || product.basePrice)}</span>
                        {product.salePrice && (
                          <span className="text-xs text-muted-foreground line-through ml-1">
                            {formatCurrency(product.basePrice)}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        {product.stockQuantity <= product.lowStockThreshold && product.status === 'active' && (
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                        )}
                        <span className={product.stockQuantity === 0 ? 'text-destructive font-medium' : ''}>
                          {product.stockQuantity}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {product.aiScore !== null ? (
                        <div className="flex items-center gap-1.5">
                          <TrendingUp className={`w-3.5 h-3.5 ${getAiScoreColor(product.aiScore)}`} />
                          <span className={`font-semibold text-xs ${getAiScoreColor(product.aiScore)}`}>
                            {product.aiScore.toFixed(0)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={STATUS_COLORS[product.status] || 'badge-neutral'}>
                        {product.status?.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => analyzeMutation.mutate(product.id)}
                          className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-brand-500 transition-colors"
                          title="AI Analyze">
                          <Zap className="w-3.5 h-3.5" />
                        </button>
                        <a href={`/dashboard/products/${product.id}/edit`}
                          className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                          <Edit className="w-3.5 h-3.5" />
                        </a>
                        <button onClick={() => { if (confirm('Delete this product?')) deleteMutation.mutate(product.id); }}
                          className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-destructive transition-colors">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {meta.totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border text-sm">
            <span className="text-muted-foreground">
              Showing {((page - 1) * 20) + 1}–{Math.min(page * 20, meta.total)} of {meta.total}
            </span>
            <div className="flex items-center gap-1">
              <button disabled={page === 1} onClick={() => setPage(p => p - 1)}
                className="px-3 py-1.5 rounded border border-border disabled:opacity-40 hover:bg-muted transition-colors">
                Previous
              </button>
              {Array.from({ length: Math.min(meta.totalPages, 5) }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setPage(p)}
                  className={`w-8 h-8 rounded text-xs font-medium transition-colors ${page === p ? 'bg-brand-500 text-white' : 'hover:bg-muted text-muted-foreground'}`}>
                  {p}
                </button>
              ))}
              <button disabled={page === meta.totalPages} onClick={() => setPage(p => p + 1)}
                className="px-3 py-1.5 rounded border border-border disabled:opacity-40 hover:bg-muted transition-colors">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
