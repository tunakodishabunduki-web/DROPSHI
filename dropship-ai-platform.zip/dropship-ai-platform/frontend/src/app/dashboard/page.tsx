'use client';

import { useQuery } from '@tanstack/react-query';
import {
  TrendingUp, TrendingDown, ShoppingCart, DollarSign,
  Package, Users, Zap, ArrowUpRight, RefreshCw,
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell,
} from 'recharts';
import { motion } from 'framer-motion';
import { analyticsApi } from '@/lib/api/analytics.api';
import { cn, formatCurrency, formatNumber } from '@/lib/utils';

const FADE_UP = {
  hidden: { opacity: 0, y: 16 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.07, duration: 0.35 } }),
};

const PIE_COLORS = ['#4f63ff', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function DashboardPage() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: analyticsApi.getDashboardStats,
    refetchInterval: 60_000,
  });

  const { data: timeSeries } = useQuery({
    queryKey: ['sales-timeseries', '30d'],
    queryFn: () => analyticsApi.getSalesTimeSeries('30d'),
  });

  const { data: topProducts } = useQuery({
    queryKey: ['top-products'],
    queryFn: analyticsApi.getTopProducts,
  });

  const kpis = [
    {
      label: 'Total Revenue',
      value: formatCurrency(stats?.revenue?.current || 0),
      change: stats?.revenue?.growth || 0,
      icon: DollarSign,
      color: 'text-brand-500',
      bg: 'bg-brand-500/10',
    },
    {
      label: 'Orders',
      value: formatNumber(stats?.orders?.total || 0),
      change: 8.2,
      icon: ShoppingCart,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
    },
    {
      label: 'Products',
      value: formatNumber(stats?.products?.active || 0),
      change: 3.1,
      icon: Package,
      color: 'text-amber-500',
      bg: 'bg-amber-500/10',
    },
    {
      label: 'Customers',
      value: formatNumber(stats?.customers?.total || 0),
      change: stats?.customers?.growth || 12,
      icon: Users,
      color: 'text-purple-500',
      bg: 'bg-purple-500/10',
    },
  ];

  return (
    <div className="space-y-6 max-w-[1400px]">
      {/* ── Header ───────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Overview</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Welcome back. Here's what's happening with your store.
          </p>
        </div>
        <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh
        </button>
      </div>

      {/* ── KPI Cards ────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((kpi, i) => {
          const Icon = kpi.icon;
          const positive = kpi.change >= 0;
          return (
            <motion.div
              key={kpi.label}
              custom={i}
              variants={FADE_UP}
              initial="hidden"
              animate="show"
              className="stat-card"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium text-muted-foreground">{kpi.label}</p>
                  <p className="text-2xl font-bold mt-1 tracking-tight">
                    {isLoading ? <span className="skeleton w-20 h-7 block" /> : kpi.value}
                  </p>
                </div>
                <div className={cn('p-2 rounded-lg', kpi.bg)}>
                  <Icon className={cn('w-4 h-4', kpi.color)} />
                </div>
              </div>
              <div className={cn(
                'flex items-center gap-1 mt-3 text-xs font-medium',
                positive ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500',
              )}>
                {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {Math.abs(kpi.change).toFixed(1)}% vs last month
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* ── Charts Row ───────────────────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Revenue chart */}
        <motion.div
          variants={FADE_UP} custom={4} initial="hidden" animate="show"
          className="stat-card xl:col-span-2"
        >
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-sm">Revenue Over Time</h3>
            <div className="flex gap-2">
              {['7d', '30d', '90d'].map((p) => (
                <button key={p} className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground hover:text-foreground transition-colors">
                  {p}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={timeSeries || mockTimeData}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f63ff" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#4f63ff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="period" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }}
                formatter={(v: any) => [`$${Number(v).toLocaleString()}`, 'Revenue']}
              />
              <Area type="monotone" dataKey="revenue" stroke="#4f63ff" strokeWidth={2} fill="url(#revenueGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Order status pie */}
        <motion.div
          variants={FADE_UP} custom={5} initial="hidden" animate="show"
          className="stat-card"
        >
          <h3 className="font-semibold text-sm mb-5">Order Status</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie
                data={stats?.orders || mockOrderStatus}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={3}
                dataKey="count"
                nameKey="status"
              >
                {(stats?.orders || mockOrderStatus).map((_: any, idx: number) => (
                  <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(v: any) => [v, 'Orders']} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-1 mt-2">
            {(stats?.orders || mockOrderStatus).map((s: any, idx: number) => (
              <div key={s.status} className="flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: PIE_COLORS[idx % PIE_COLORS.length] }} />
                <span className="text-muted-foreground capitalize">{s.status}</span>
                <span className="font-medium ml-auto">{s.count}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* ── Bottom Row ───────────────────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Top Products */}
        <motion.div
          variants={FADE_UP} custom={6} initial="hidden" animate="show"
          className="stat-card"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">Top Products</h3>
            <a href="/dashboard/products" className="text-xs text-brand-500 hover:underline flex items-center gap-0.5">
              View all <ArrowUpRight className="w-3 h-3" />
            </a>
          </div>
          <div className="space-y-3">
            {(topProducts || mockTopProducts).slice(0, 5).map((p: any, i: number) => (
              <div key={p.id || i} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted flex-shrink-0 overflow-hidden">
                  {p.image ? (
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">
                      {i + 1}
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.units_sold} sold</p>
                </div>
                <span className="text-xs font-semibold">{formatCurrency(p.total_revenue)}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* AI Module Status */}
        <motion.div
          variants={FADE_UP} custom={7} initial="hidden" animate="show"
          className="stat-card"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">AI Modules</h3>
            <span className="badge-success">All Active</span>
          </div>
          <div className="space-y-2">
            {AI_MODULES.map((m) => (
              <div key={m.name} className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
                <Zap className="w-4 h-4 text-brand-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium">{m.name}</p>
                  <p className="text-xs text-muted-foreground">{m.status}</p>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs text-emerald-600 dark:text-emerald-400">Live</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

// ── Mock Data ─────────────────────────────────────────────────────────────────
const mockTimeData = Array.from({ length: 30 }, (_, i) => ({
  period: `${i + 1}`,
  revenue: Math.floor(Math.random() * 8000 + 2000),
  orders: Math.floor(Math.random() * 50 + 10),
}));

const mockOrderStatus = [
  { status: 'delivered', count: 128 },
  { status: 'processing', count: 43 },
  { status: 'pending', count: 21 },
  { status: 'shipped', count: 67 },
  { status: 'cancelled', count: 8 },
];

const mockTopProducts = [
  { name: 'Wireless Earbuds Pro', units_sold: 284, total_revenue: 14200 },
  { name: 'LED Strip Lights 5m', units_sold: 196, total_revenue: 5880 },
  { name: 'Phone Stand Adjustable', units_sold: 167, total_revenue: 3340 },
  { name: 'Yoga Mat Non-Slip', units_sold: 143, total_revenue: 5148 },
  { name: 'Portable Blender USB', units_sold: 121, total_revenue: 6050 },
];

const AI_MODULES = [
  { name: 'Product Research AI', status: 'Scanning 12 markets' },
  { name: 'Dynamic Pricing AI', status: 'Monitoring 847 products' },
  { name: 'Marketing AI', status: '3 campaigns running' },
  { name: 'Customer Support AI', status: '5 tickets in queue' },
  { name: 'Supplier Sync AI', status: 'Last sync 4 min ago' },
];
