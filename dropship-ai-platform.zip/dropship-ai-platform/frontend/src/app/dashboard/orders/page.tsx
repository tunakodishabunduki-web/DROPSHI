'use client';

import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Search, Filter, Download, Package, Clock, Truck, CheckCircle, XCircle, RefreshCw, Eye } from 'lucide-react';
import { ordersApi } from '@/lib/api';
import { formatCurrency, formatRelativeTime, getOrderStatusColor, debounce } from '@/lib/utils';

const STATUS_FILTERS = ['all', 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];

const STATUS_ICONS: Record<string, any> = {
  pending: Clock,
  confirmed: CheckCircle,
  processing: RefreshCw,
  shipped: Truck,
  delivered: CheckCircle,
  cancelled: XCircle,
  refunded: XCircle,
};

export default function OrdersPage() {
  const qc = useQueryClient();
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['orders', { status, search, page }],
    queryFn: () => ordersApi.list({ status: status === 'all' ? undefined : status, search: search || undefined, page, limit: 20 }),
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, newStatus }: { id: string; newStatus: string }) => ordersApi.updateStatus(id, newStatus),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['orders'] }),
  });

  const debouncedSearch = useCallback(debounce((v: string) => { setSearch(v); setPage(1); }, 400), []);

  const orders: any[] = (data as any)?.data?.data || [];
  const meta: any = (data as any)?.data?.meta || {};

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Orders</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{meta.total || 0} total orders</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm hover:bg-muted transition-colors">
          <Download className="w-3.5 h-3.5" /> Export CSV
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Pending', value: orders.filter(o => o.status === 'pending').length, icon: Clock, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-900/20' },
          { label: 'Processing', value: orders.filter(o => o.status === 'processing').length, icon: RefreshCw, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-900/20' },
          { label: 'Shipped', value: orders.filter(o => o.status === 'shipped').length, icon: Truck, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-900/20' },
          { label: 'Delivered', value: orders.filter(o => o.status === 'delivered').length, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="stat-card flex items-center gap-3">
              <div className={`p-2 rounded-lg ${s.bg}`}><Icon className={`w-4 h-4 ${s.color}`} /></div>
              <div>
                <p className="text-xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="stat-card !p-3 flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input onChange={(e) => debouncedSearch(e.target.value)} type="text" placeholder="Search order #, customer..."
            className="w-full pl-8 pr-3 py-2 text-sm rounded-lg bg-muted border-0 outline-none focus:ring-2 focus:ring-brand-500/30" />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {STATUS_FILTERS.map((s) => (
            <button key={s} onClick={() => { setStatus(s); setPage(1); }}
              className={`px-2.5 py-1 text-xs rounded-lg capitalize font-medium transition-colors ${status === s ? 'bg-brand-500 text-white' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {s}
            </button>
          ))}
        </div>
        {isFetching && <RefreshCw className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
      </div>

      {/* Orders table */}
      <div className="stat-card !p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Order</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Customer</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Items</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Total</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Payment</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Status</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Date</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading
                ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>{Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="px-4 py-3"><div className="skeleton h-4 rounded w-full" /></td>
                  ))}</tr>
                ))
                : orders.map((order) => {
                  const StatusIcon = STATUS_ICONS[order.status] || Package;
                  return (
                    <tr key={order.id} className="hover:bg-muted/30 transition-colors group">
                      <td className="px-4 py-3">
                        <span className="font-mono font-medium text-xs">{order.orderNumber}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-xs">{order.customer?.firstName} {order.customer?.lastName}</p>
                          <p className="text-xs text-muted-foreground">{order.customer?.email}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{order.items?.length || 0} items</td>
                      <td className="px-4 py-3 font-semibold">{formatCurrency(order.total, order.currency)}</td>
                      <td className="px-4 py-3">
                        <span className={order.paymentStatus === 'completed' ? 'badge-success' : order.paymentStatus === 'failed' ? 'badge-danger' : 'badge-warning'}>
                          {order.paymentStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <StatusIcon className="w-3.5 h-3.5 text-muted-foreground" />
                          <span className={getOrderStatusColor(order.status)}>{order.status}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatRelativeTime(order.createdAt)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <a href={`/dashboard/orders/${order.id}`}
                            className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                            <Eye className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>

        {meta.totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border text-sm">
            <span className="text-muted-foreground">
              {((page-1)*20)+1}–{Math.min(page*20, meta.total)} of {meta.total}
            </span>
            <div className="flex gap-1">
              <button disabled={page===1} onClick={() => setPage(p=>p-1)}
                className="px-3 py-1.5 rounded border border-border disabled:opacity-40 hover:bg-muted transition-colors text-xs">
                Previous
              </button>
              <button disabled={page===meta.totalPages} onClick={() => setPage(p=>p+1)}
                className="px-3 py-1.5 rounded border border-border disabled:opacity-40 hover:bg-muted transition-colors text-xs">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
