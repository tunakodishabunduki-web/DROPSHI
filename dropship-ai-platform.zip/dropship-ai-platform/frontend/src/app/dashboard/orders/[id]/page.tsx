'use client';

import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Package, Truck, CheckCircle, XCircle, RefreshCw, MapPin, CreditCard } from 'lucide-react';
import { ordersApi } from '@/lib/api';
import { formatCurrency, formatDate, getOrderStatusColor } from '@/lib/utils';

const STATUS_FLOW = ['pending', 'confirmed', 'processing', 'shipped', 'delivered'];

export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['order', id],
    queryFn: () => ordersApi.get(id),
  });

  const statusMutation = useMutation({
    mutationFn: (newStatus: string) => ordersApi.updateStatus(id, newStatus),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['order', id] }),
  });

  const cancelMutation = useMutation({
    mutationFn: (reason: string) => ordersApi.cancel(id, reason),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['order', id] }),
  });

  const order: any = (data as any)?.data;

  if (isLoading) {
    return (
      <div className="max-w-4xl space-y-4">
        <div className="skeleton h-8 w-48 rounded" />
        <div className="stat-card space-y-3">
          {[1,2,3,4].map(i => <div key={i} className="skeleton h-5 rounded" />)}
        </div>
      </div>
    );
  }

  if (!order) return <div className="text-muted-foreground">Order not found</div>;

  const currentStep = STATUS_FLOW.indexOf(order.status);

  return (
    <div className="max-w-4xl space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => router.back()} className="p-2 rounded-lg hover:bg-muted transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold tracking-tight font-mono">{order.orderNumber}</h1>
            <span className={getOrderStatusColor(order.status)}>{order.status}</span>
            <span className={order.paymentStatus === 'completed' ? 'badge-success' : 'badge-warning'}>
              {order.paymentStatus}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">{formatDate(order.createdAt, 'long')}</p>
        </div>
        <div className="flex items-center gap-2">
          {order.status !== 'cancelled' && order.status !== 'delivered' && (
            <button
              onClick={() => cancelMutation.mutate('Customer request')}
              className="px-3 py-2 text-sm border border-destructive/30 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
            >
              Cancel Order
            </button>
          )}
          {currentStep < STATUS_FLOW.length - 1 && !['cancelled', 'refunded'].includes(order.status) && (
            <button
              onClick={() => statusMutation.mutate(STATUS_FLOW[currentStep + 1])}
              disabled={statusMutation.isPending}
              className="px-3 py-2 text-sm bg-brand-500 hover:bg-brand-600 text-white rounded-lg transition-colors disabled:opacity-60"
            >
              {statusMutation.isPending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : `Mark as ${STATUS_FLOW[currentStep + 1]}`}
            </button>
          )}
        </div>
      </div>

      {/* Progress tracker */}
      {!['cancelled', 'refunded'].includes(order.status) && (
        <div className="stat-card">
          <div className="flex items-center justify-between relative">
            <div className="absolute top-4 left-0 right-0 h-0.5 bg-border z-0">
              <div
                className="h-full bg-brand-500 transition-all"
                style={{ width: `${(currentStep / (STATUS_FLOW.length - 1)) * 100}%` }}
              />
            </div>
            {STATUS_FLOW.map((s, i) => (
              <div key={s} className="flex flex-col items-center z-10">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-colors ${
                  i <= currentStep
                    ? 'bg-brand-500 border-brand-500 text-white'
                    : 'bg-card border-border text-muted-foreground'
                }`}>
                  {i < currentStep ? <CheckCircle className="w-4 h-4" /> : <span className="text-xs font-bold">{i + 1}</span>}
                </div>
                <span className="text-xs mt-2 capitalize text-muted-foreground">{s}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Order items */}
        <div className="xl:col-span-2 stat-card space-y-1">
          <h3 className="font-semibold text-sm mb-4">Order Items</h3>
          {(order.items || []).map((item: any) => (
            <div key={item.id} className="flex items-center gap-3 py-3 border-b border-border last:border-0">
              <div className="w-12 h-12 rounded-lg bg-muted flex-shrink-0 overflow-hidden">
                {item.productImage
                  ? <img src={item.productImage} alt={item.productName} className="w-full h-full object-cover" />
                  : <Package className="w-6 h-6 text-muted-foreground m-3" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{item.productName}</p>
                <p className="text-xs text-muted-foreground font-mono">{item.sku}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">{formatCurrency(item.unitPrice)} × {item.quantity}</p>
                <p className="text-xs font-semibold">{formatCurrency(item.total)}</p>
              </div>
            </div>
          ))}
          <div className="pt-3 space-y-1.5">
            {[
              ['Subtotal', formatCurrency(order.subtotal)],
              ['Shipping', formatCurrency(order.shippingTotal)],
              ['Tax', formatCurrency(order.taxTotal)],
              order.discountTotal > 0 ? ['Discount', `-${formatCurrency(order.discountTotal)}`] : null,
            ].filter(Boolean).map(([label, val]: any) => (
              <div key={label} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{label}</span>
                <span>{val}</span>
              </div>
            ))}
            <div className="flex justify-between text-sm font-bold pt-2 border-t border-border">
              <span>Total</span>
              <span className="text-brand-500">{formatCurrency(order.total, order.currency)}</span>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Customer */}
          <div className="stat-card">
            <h3 className="font-semibold text-sm mb-3">Customer</h3>
            {order.customer ? (
              <div className="space-y-1 text-sm">
                <p className="font-medium">{order.customer.firstName} {order.customer.lastName}</p>
                <p className="text-muted-foreground text-xs">{order.customer.email}</p>
                {order.customer.phone && <p className="text-muted-foreground text-xs">{order.customer.phone}</p>}
              </div>
            ) : <p className="text-sm text-muted-foreground">Guest order</p>}
          </div>

          {/* Shipping address */}
          <div className="stat-card">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <h3 className="font-semibold text-sm">Shipping Address</h3>
            </div>
            {order.shippingAddress && (
              <div className="text-sm text-muted-foreground space-y-0.5">
                <p className="font-medium text-foreground">{order.shippingAddress.firstName} {order.shippingAddress.lastName}</p>
                <p>{order.shippingAddress.address1}</p>
                {order.shippingAddress.address2 && <p>{order.shippingAddress.address2}</p>}
                <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.postalCode}</p>
                <p>{order.shippingAddress.country}</p>
              </div>
            )}
          </div>

          {/* Tracking */}
          {order.trackingNumber && (
            <div className="stat-card">
              <div className="flex items-center gap-2 mb-3">
                <Truck className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-semibold text-sm">Tracking</h3>
              </div>
              <div className="text-sm space-y-1">
                <p className="font-mono text-xs">{order.trackingNumber}</p>
                <p className="text-muted-foreground text-xs">{order.carrier}</p>
                {order.trackingUrl && (
                  <a href={order.trackingUrl} target="_blank" rel="noopener noreferrer"
                    className="text-brand-500 text-xs hover:underline">
                    Track shipment →
                  </a>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
