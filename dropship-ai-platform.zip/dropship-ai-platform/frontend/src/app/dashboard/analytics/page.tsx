'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, LineChart, Line, Legend,
} from 'recharts';
import { Download, Calendar, TrendingUp, DollarSign, ShoppingCart, Users } from 'lucide-react';
import { analyticsApi } from '@/lib/api';
import { formatCurrency, formatNumber } from '@/lib/utils';

const PERIODS = ['7d', '30d', '90d', '1y'] as const;

export default function AnalyticsPage() {
  const [period, setPeriod] = useState<typeof PERIODS[number]>('30d');

  const { data: timeSeries } = useQuery({
    queryKey: ['sales-timeseries', period],
    queryFn: () => analyticsApi.getSalesTimeSeries(period),
  });

  const { data: topProducts } = useQuery({
    queryKey: ['top-products', 10],
    queryFn: () => analyticsApi.getTopProducts(10),
  });

  const { data: adPerf } = useQuery({
    queryKey: ['ad-performance'],
    queryFn: () => analyticsApi.getAdPerformance(),
  });

  const { data: supplierPerf } = useQuery({
    queryKey: ['supplier-performance'],
    queryFn: analyticsApi.getSupplierPerformance,
  });

  const series: any[] = (timeSeries as any)?.data || MOCK_SERIES;
  const products: any[] = (topProducts as any)?.data || MOCK_TOP_PRODUCTS;
  const ads: any[] = (adPerf as any)?.data || MOCK_ADS;

  const totalRevenue = series.reduce((s, d) => s + parseFloat(d.revenue || 0), 0);
  const totalOrders = series.reduce((s, d) => s + parseInt(d.orders || 0), 0);

  const handleExport = async () => {
    const now = new Date();
    const from = new Date(now.getTime() - (period === '7d' ? 7 : period === '30d' ? 30 : period === '90d' ? 90 : 365) * 86400000);
    const blob = await analyticsApi.exportOrders(from.toISOString(), now.toISOString()) as any;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'orders-export.csv'; a.click();
  };

  return (
    <div className="space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Performance overview for your store</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-muted rounded-lg p-1 gap-0.5">
            {PERIODS.map((p) => (
              <button key={p} onClick={() => setPeriod(p)}
                className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${period === p ? 'bg-card shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                {p}
              </button>
            ))}
          </div>
          <button onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm hover:bg-muted transition-colors">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: 'Revenue', value: formatCurrency(totalRevenue), icon: DollarSign, color: 'text-brand-500', bg: 'bg-brand-500/10' },
          { label: 'Orders', value: formatNumber(totalOrders), icon: ShoppingCart, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
          { label: 'Avg Order Value', value: totalOrders > 0 ? formatCurrency(totalRevenue / totalOrders) : '—', icon: TrendingUp, color: 'text-amber-500', bg: 'bg-amber-500/10' },
          { label: 'New Customers', value: formatNumber(Math.floor(totalOrders * 0.6)), icon: Users, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="stat-card flex items-center gap-4">
              <div className={`p-2.5 rounded-xl ${s.bg}`}><Icon className={`w-5 h-5 ${s.color}`} /></div>
              <div>
                <p className="text-2xl font-bold tracking-tight">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Revenue chart */}
      <div className="stat-card">
        <h3 className="font-semibold text-sm mb-5">Revenue & Orders Over Time</h3>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={series} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="grad1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#4f63ff" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#4f63ff" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="grad2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.12} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="period" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="left" tick={{ fontSize: 11 }} axisLine={false} tickLine={false}
              tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
            <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }}
              formatter={(v: any, name: string) => [name === 'Revenue' ? formatCurrency(v) : v, name]} />
            <Legend wrapperStyle={{ fontSize: 12, paddingTop: 12 }} />
            <Area yAxisId="left" type="monotone" dataKey="revenue" name="Revenue" stroke="#4f63ff" strokeWidth={2} fill="url(#grad1)" dot={false} />
            <Area yAxisId="right" type="monotone" dataKey="orders" name="Orders" stroke="#10b981" strokeWidth={2} fill="url(#grad2)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Top products bar chart */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-5">Top Products by Revenue</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={products.slice(0, 6)} layout="vertical" margin={{ left: 0, right: 16 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} axisLine={false} tickLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} width={120}
                tickFormatter={(v) => v.length > 16 ? v.slice(0, 16) + '…' : v} />
              <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }}
                formatter={(v: any) => [formatCurrency(v), 'Revenue']} />
              <Bar dataKey="total_revenue" fill="#4f63ff" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Ad performance */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-5">Ad Performance by Platform</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={ads} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="platform" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="total_clicks" name="Clicks" fill="#4f63ff" radius={[4, 4, 0, 0]} />
              <Bar dataKey="total_conversions" name="Conversions" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

const MOCK_SERIES = Array.from({ length: 30 }, (_, i) => ({
  period: `${i + 1}`,
  revenue: Math.floor(Math.random() * 9000 + 2000),
  orders: Math.floor(Math.random() * 60 + 10),
}));

const MOCK_TOP_PRODUCTS = [
  { name: 'Wireless Earbuds Pro', total_revenue: 14200, units_sold: 284 },
  { name: 'LED Strip Lights 5m', total_revenue: 8880, units_sold: 296 },
  { name: 'Portable Blender USB', total_revenue: 6050, units_sold: 121 },
  { name: 'Yoga Mat Non-Slip', total_revenue: 5148, units_sold: 143 },
  { name: 'Phone Stand Adj.', total_revenue: 3340, units_sold: 167 },
  { name: 'Smart Watch Strap', total_revenue: 2880, units_sold: 192 },
];

const MOCK_ADS = [
  { platform: 'TikTok', total_clicks: 12400, total_conversions: 342 },
  { platform: 'Instagram', total_clicks: 9800, total_conversions: 218 },
  { platform: 'Facebook', total_clicks: 7600, total_conversions: 189 },
  { platform: 'Google', total_clicks: 5200, total_conversions: 143 },
];
