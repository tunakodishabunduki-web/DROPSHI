'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Zap, TrendingUp, DollarSign, Megaphone,
  HeadphonesIcon, Truck, Play, RefreshCw,
  CheckCircle, AlertCircle, Clock, BarChart2,
} from 'lucide-react';
import { aiApi } from '@/lib/api';
import { formatRelativeTime } from '@/lib/utils';

const MODULES = [
  {
    id: 'research',
    name: 'Product Research AI',
    description: 'Scans marketplaces & social media to surface trending products',
    icon: TrendingUp,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
  },
  {
    id: 'pricing',
    name: 'Dynamic Pricing AI',
    description: 'Adjusts prices in real-time based on competitor data and demand',
    icon: DollarSign,
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10',
  },
  {
    id: 'marketing',
    name: 'Marketing AI',
    description: 'Generates ad creatives for TikTok, Instagram and Meta',
    icon: Megaphone,
    color: 'text-purple-500',
    bg: 'bg-purple-500/10',
  },
  {
    id: 'support',
    name: 'Customer Support AI',
    description: 'Auto-responds to tickets and escalates when needed',
    icon: HeadphonesIcon,
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
  },
  {
    id: 'supplier',
    name: 'Supplier Sync AI',
    description: 'Monitors stock and switches suppliers automatically on failures',
    icon: Truck,
    color: 'text-rose-500',
    bg: 'bg-rose-500/10',
  },
];

export default function AiInsightsPage() {
  const qc = useQueryClient();
  const [activeModule, setActiveModule] = useState('research');

  const { data: logs, isLoading: logsLoading } = useQuery({
    queryKey: ['ai-logs'],
    queryFn: () => aiApi.getLogs({ limit: 50 }),
    refetchInterval: 15_000,
  });

  const { data: trends } = useQuery({
    queryKey: ['ai-trends'],
    queryFn: () => aiApi.discoverTrending({ limit: 10 }),
  });

  const { data: supportStats } = useQuery({
    queryKey: ['support-analytics'],
    queryFn: aiApi.getSupportAnalytics,
  });

  const syncMutation = useMutation({
    mutationFn: aiApi.syncAll,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['ai-logs'] }),
  });

  const bulkTriageMutation = useMutation({
    mutationFn: aiApi.bulkTriage,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['support-analytics'] }),
  });

  const batchPricingMutation = useMutation({
    mutationFn: () => aiApi.runBatchPricing('ai_optimal'),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['products'] }),
  });

  const aiLogs: any[] = (logs as any)?.data?.data || [];

  return (
    <div className="space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">AI Insights</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Monitor and control your AI automation modules</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-medium border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            All systems active
          </div>
        </div>
      </div>

      {/* Module cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
        {MODULES.map((m, i) => {
          const Icon = m.icon;
          const active = activeModule === m.id;
          return (
            <motion.button key={m.id} onClick={() => setActiveModule(m.id)}
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`stat-card text-left transition-all ${active ? 'ring-2 ring-brand-500 shadow-card-hover' : ''}`}>
              <div className={`w-9 h-9 rounded-xl ${m.bg} flex items-center justify-center mb-3`}>
                <Icon className={`w-4 h-4 ${m.color}`} />
              </div>
              <p className="text-xs font-semibold leading-snug">{m.name}</p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed line-clamp-2">{m.description}</p>
              <div className="flex items-center gap-1 mt-3">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs text-emerald-600 dark:text-emerald-400">Active</span>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Module detail + controls */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Controls */}
        <div className="stat-card space-y-3">
          <h3 className="font-semibold text-sm">Quick Actions</h3>
          <div className="space-y-2">
            <button onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending}
              className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted transition-colors text-sm disabled:opacity-60">
              {syncMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin text-brand-500" /> : <Truck className="w-4 h-4 text-rose-500" />}
              <div className="text-left">
                <p className="font-medium text-xs">Sync All Suppliers</p>
                <p className="text-xs text-muted-foreground">Update inventory & prices</p>
              </div>
            </button>
            <button onClick={() => batchPricingMutation.mutate()} disabled={batchPricingMutation.isPending}
              className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted transition-colors text-sm disabled:opacity-60">
              {batchPricingMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin text-brand-500" /> : <DollarSign className="w-4 h-4 text-emerald-500" />}
              <div className="text-left">
                <p className="font-medium text-xs">Run Batch Pricing</p>
                <p className="text-xs text-muted-foreground">Optimize all active products</p>
              </div>
            </button>
            <button onClick={() => bulkTriageMutation.mutate()} disabled={bulkTriageMutation.isPending}
              className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted transition-colors text-sm disabled:opacity-60">
              {bulkTriageMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin text-brand-500" /> : <HeadphonesIcon className="w-4 h-4 text-amber-500" />}
              <div className="text-left">
                <p className="font-medium text-xs">Bulk Triage Tickets</p>
                <p className="text-xs text-muted-foreground">AI-respond to open tickets</p>
              </div>
            </button>
          </div>

          {/* Support stats */}
          {supportStats && (
            <div className="mt-4 pt-4 border-t border-border space-y-2">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Support Stats</p>
              {[
                ['Open Tickets', (supportStats as any)?.data?.open_count],
                ['Resolved Today', (supportStats as any)?.data?.resolved_count],
                ['Avg Resolution', `${parseFloat((supportStats as any)?.data?.avg_resolution_hours || 0).toFixed(1)}h`],
                ['AI Confidence', `${(parseFloat((supportStats as any)?.data?.avg_ai_confidence || 0) * 100).toFixed(0)}%`],
              ].map(([label, val]) => (
                <div key={label as string} className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-semibold">{val || '—'}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Trending products from research AI */}
        <div className="stat-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">Trending Products</h3>
            <span className="text-xs text-muted-foreground">via Research AI</span>
          </div>
          <div className="space-y-2">
            {((trends as any)?.data?.trends || MOCK_TRENDS).slice(0, 8).map((t: any, i: number) => (
              <div key={t.id || i} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-500/10 flex items-center justify-center flex-shrink-0 text-xs font-bold text-brand-500">
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{t.keyword}</p>
                  <p className="text-xs text-muted-foreground">{t.platform}</p>
                </div>
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-emerald-500" />
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">{t.score?.toFixed(0)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Task Logs */}
        <div className="stat-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">Task Log</h3>
            {logsLoading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
          </div>
          <div className="space-y-2 max-h-[340px] overflow-y-auto scrollbar-thin pr-1">
            {(aiLogs.length ? aiLogs : MOCK_LOGS).map((log: any, i: number) => (
              <div key={log.id || i} className="flex items-start gap-2.5 text-xs">
                <div className="mt-0.5 flex-shrink-0">
                  {log.status === 'completed' ? (
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                  ) : log.status === 'failed' ? (
                    <AlertCircle className="w-3.5 h-3.5 text-destructive" />
                  ) : (
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{log.taskType?.replace(/_/g, ' ') || log.task}</p>
                  <p className="text-muted-foreground">{log.module} · {formatRelativeTime(log.createdAt || log.time)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const MOCK_TRENDS = [
  { keyword: 'LED Desk Lamp', platform: 'TikTok', score: 94 },
  { keyword: 'Portable Blender', platform: 'Instagram', score: 88 },
  { keyword: 'Wireless Charger Stand', platform: 'Amazon', score: 85 },
  { keyword: 'Posture Corrector', platform: 'TikTok', score: 81 },
  { keyword: 'Smart Plant Sensor', platform: 'Instagram', score: 77 },
  { keyword: 'Car Phone Mount', platform: 'Amazon', score: 73 },
  { keyword: 'Resistance Bands Set', platform: 'TikTok', score: 70 },
  { keyword: 'Collapsible Water Bottle', platform: 'Instagram', score: 66 },
];

const MOCK_LOGS = [
  { task: 'analyze_product', module: 'product_research', status: 'completed', time: new Date(Date.now() - 120000) },
  { task: 'sync_inventory', module: 'supplier_sync', status: 'completed', time: new Date(Date.now() - 240000) },
  { task: 'generate_ad', module: 'marketing', status: 'completed', time: new Date(Date.now() - 600000) },
  { task: 'triage_ticket', module: 'customer_support', status: 'completed', time: new Date(Date.now() - 900000) },
  { task: 'batch_pricing', module: 'dynamic_pricing', status: 'processing', time: new Date(Date.now() - 60000) },
];
