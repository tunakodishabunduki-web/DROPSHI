'use client';

import { useState } from 'react';
import { useAuthStore } from '@/lib/stores/auth.store';
import { Bell, Shield, CreditCard, Globe, Zap, Save, Key, Webhook } from 'lucide-react';

const TABS = [
  { id: 'general', label: 'General', icon: Globe },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'billing', label: 'Billing', icon: CreditCard },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'ai', label: 'AI Settings', icon: Zap },
  { id: 'api', label: 'API & Webhooks', icon: Webhook },
];

export default function SettingsPage() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState('general');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-5 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Manage your store configuration and preferences</p>
      </div>

      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-48 flex-shrink-0">
          <nav className="space-y-1">
            {TABS.map((t) => {
              const Icon = t.icon;
              return (
                <button key={t.id} onClick={() => setTab(t.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                    tab === t.id
                      ? 'bg-brand-500/10 text-brand-600 dark:text-brand-400 font-medium'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}>
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  {t.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 stat-card space-y-6">
          {tab === 'general' && (
            <>
              <h3 className="font-semibold">General Settings</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Store Name', value: 'Demo Store', type: 'text' },
                  { label: 'Store URL', value: 'demo.dropshipai.com', type: 'text' },
                  { label: 'Default Currency', value: 'USD', type: 'select' },
                  { label: 'Timezone', value: 'UTC', type: 'select' },
                  { label: 'Language', value: 'English', type: 'select' },
                  { label: 'Support Email', value: 'support@demo.com', type: 'email' },
                ].map((f) => (
                  <div key={f.label}>
                    <label className="block text-xs font-medium text-muted-foreground mb-1.5">{f.label}</label>
                    <input defaultValue={f.value} type={f.type === 'select' ? 'text' : f.type}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
                  </div>
                ))}
              </div>
            </>
          )}

          {tab === 'security' && (
            <>
              <h3 className="font-semibold">Security Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">Current Password</label>
                  <input type="password" className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">New Password</label>
                  <input type="password" className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
                </div>
                <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                  <p className="text-sm font-medium">Two-Factor Authentication</p>
                  <p className="text-xs text-muted-foreground">Add an extra layer of security with 2FA</p>
                  <button className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-xs font-medium rounded-lg transition-colors">
                    Enable 2FA
                  </button>
                </div>
              </div>
            </>
          )}

          {tab === 'ai' && (
            <>
              <h3 className="font-semibold">AI Module Settings</h3>
              <div className="space-y-4">
                {[
                  { label: 'Product Research AI', description: 'Auto-discover trending products daily', enabled: true },
                  { label: 'Dynamic Pricing AI', description: 'Auto-adjust prices based on demand', enabled: true },
                  { label: 'Marketing AI', description: 'Auto-generate ad campaigns', enabled: false },
                  { label: 'Customer Support AI', description: 'Auto-respond to support tickets', enabled: true },
                  { label: 'Supplier Sync AI', description: 'Auto-sync inventory every 60 minutes', enabled: true },
                ].map((m) => (
                  <div key={m.label} className="flex items-center justify-between p-3.5 rounded-lg border border-border">
                    <div>
                      <p className="text-sm font-medium">{m.label}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{m.description}</p>
                    </div>
                    <div className={`w-10 h-5 rounded-full transition-colors cursor-pointer ${m.enabled ? 'bg-brand-500' : 'bg-muted'}`}>
                      <div className={`w-4 h-4 rounded-full bg-white shadow-sm mt-0.5 transition-transform ${m.enabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                    </div>
                  </div>
                ))}
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">OpenAI API Key</label>
                  <input type="password" defaultValue="sk-••••••••••••••••••••••••••••••••••••••••"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 font-mono" />
                </div>
              </div>
            </>
          )}

          {tab === 'billing' && (
            <div className="space-y-4">
              <h3 className="font-semibold">Billing & Subscription</h3>
              <div className="p-4 rounded-xl bg-brand-500/10 border border-brand-500/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-brand-600 dark:text-brand-400">Pro Plan</p>
                    <p className="text-sm text-muted-foreground mt-0.5">$99/month · Renews Jan 1, 2027</p>
                  </div>
                  <span className="badge-success">Active</span>
                </div>
              </div>
              <div className="space-y-2">
                {[
                  ['Products', 'Unlimited'],
                  ['AI Modules', 'All 5 modules'],
                  ['Orders/month', 'Unlimited'],
                  ['Team members', 'Up to 10'],
                  ['Support', 'Priority'],
                ].map(([feat, val]) => (
                  <div key={feat} className="flex justify-between text-sm py-2 border-b border-border last:border-0">
                    <span className="text-muted-foreground">{feat}</span>
                    <span className="font-medium">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-border">
            <button onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors">
              <Save className="w-3.5 h-3.5" />
              {saved ? 'Saved!' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
