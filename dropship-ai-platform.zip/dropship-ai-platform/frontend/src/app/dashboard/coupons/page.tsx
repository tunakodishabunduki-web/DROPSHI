'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Tag, Copy, Trash2, CheckCircle } from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatDate, formatCurrency } from '@/lib/utils';

export default function CouponsPage() {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [copied, setCopied] = useState('');
  const [form, setForm] = useState({
    code: '', discountType: 'percentage', discountValue: 10,
    minOrderAmount: '', usageLimit: '', expiresAt: '',
  });

  const { data, isLoading } = useQuery({
    queryKey: ['coupons'],
    queryFn: () => api.get('/coupons'),
  });

  const createMutation = useMutation({
    mutationFn: (dto: any) => api.post('/coupons', dto),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['coupons'] }); setShowForm(false); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/coupons/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['coupons'] }),
  });

  const coupons: any[] = (data as any)?.data?.data || MOCK_COUPONS;

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    setTimeout(() => setCopied(''), 2000);
  };

  const generateCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const code = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    setForm((f) => ({ ...f, code }));
  };

  return (
    <div className="space-y-5 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Coupons</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{coupons.length} active discount codes</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium transition-colors">
          <Plus className="w-3.5 h-3.5" /> Create Coupon
        </button>
      </div>

      {showForm && (
        <div className="stat-card space-y-4">
          <h3 className="font-semibold text-sm">New Coupon</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Code</label>
              <div className="flex gap-2">
                <input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))}
                  placeholder="SAVE20" className="flex-1 px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 font-mono uppercase" />
                <button onClick={generateCode} className="px-3 py-2 text-xs bg-muted hover:bg-muted/80 rounded-lg transition-colors border border-border">
                  Generate
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Discount Type</label>
              <select value={form.discountType} onChange={(e) => setForm((f) => ({ ...f, discountType: e.target.value }))}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30">
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed Amount ($)</option>
                <option value="free_shipping">Free Shipping</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">
                Value {form.discountType === 'percentage' ? '(%)' : '($)'}
              </label>
              <input type="number" value={form.discountValue} min="1"
                onChange={(e) => setForm((f) => ({ ...f, discountValue: +e.target.value }))}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Min Order Amount</label>
              <input type="number" value={form.minOrderAmount} placeholder="0 = no minimum"
                onChange={(e) => setForm((f) => ({ ...f, minOrderAmount: e.target.value }))}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Usage Limit</label>
              <input type="number" value={form.usageLimit} placeholder="Unlimited"
                onChange={(e) => setForm((f) => ({ ...f, usageLimit: e.target.value }))}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Expires At</label>
              <input type="datetime-local" value={form.expiresAt}
                onChange={(e) => setForm((f) => ({ ...f, expiresAt: e.target.value }))}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending || !form.code}
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-60">
              Create Coupon
            </button>
            <button onClick={() => setShowForm(false)} className="px-4 py-2 border border-border text-sm rounded-lg hover:bg-muted transition-colors">
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="stat-card !p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40">
              {['Code', 'Discount', 'Min Order', 'Usage', 'Expires', 'Status', ''].map((h) => (
                <th key={h} className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {coupons.map((c: any) => (
              <tr key={c.id} className="hover:bg-muted/30 transition-colors group">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-brand-500">{c.code}</span>
                    <button onClick={() => copyCode(c.code)} className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-foreground">
                      {copied === c.code ? <CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </td>
                <td className="px-4 py-3 font-semibold">
                  {c.discountType === 'percentage' ? `${c.discountValue}%` :
                   c.discountType === 'free_shipping' ? 'Free Shipping' :
                   formatCurrency(c.discountValue)}
                </td>
                <td className="px-4 py-3 text-muted-foreground">
                  {c.minOrderAmount ? formatCurrency(c.minOrderAmount) : '—'}
                </td>
                <td className="px-4 py-3">
                  <span className="text-muted-foreground">{c.usedCount || 0}</span>
                  {c.usageLimit && <span className="text-muted-foreground"> / {c.usageLimit}</span>}
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">
                  {c.expiresAt ? formatDate(c.expiresAt) : 'Never'}
                </td>
                <td className="px-4 py-3">
                  <span className={c.isActive ? 'badge-success' : 'badge-neutral'}>
                    {c.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => { if (confirm('Delete coupon?')) deleteMutation.mutate(c.id); }}
                    className="opacity-0 group-hover:opacity-100 p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-destructive transition-all">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const MOCK_COUPONS = [
  { id: '1', code: 'SAVE20', discountType: 'percentage', discountValue: 20, minOrderAmount: 50, usedCount: 34, usageLimit: 100, isActive: true, expiresAt: new Date(Date.now() + 86400000 * 30) },
  { id: '2', code: 'FREESHIP', discountType: 'free_shipping', discountValue: 0, minOrderAmount: 25, usedCount: 12, usageLimit: null, isActive: true, expiresAt: null },
  { id: '3', code: 'WELCOME10', discountType: 'percentage', discountValue: 10, minOrderAmount: 0, usedCount: 89, usageLimit: 500, isActive: true, expiresAt: null },
  { id: '4', code: 'FLASH15', discountType: 'fixed', discountValue: 15, minOrderAmount: 100, usedCount: 7, usageLimit: 50, isActive: false, expiresAt: new Date(Date.now() - 86400000) },
];
