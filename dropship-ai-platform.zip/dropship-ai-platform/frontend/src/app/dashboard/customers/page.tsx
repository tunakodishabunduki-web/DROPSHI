'use client';

import { useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Users, TrendingUp, ShoppingCart, DollarSign, Mail, Phone } from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatCurrency, formatRelativeTime, debounce } from '@/lib/utils';

export default function CustomersPage() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['customers', { search, page }],
    queryFn: () => api.get('/customers', { params: { search: search || undefined, page, limit: 20 } }),
  });

  const debouncedSearch = useCallback(debounce((v: string) => { setSearch(v); setPage(1); }, 400), []);

  const customers: any[] = (data as any)?.data?.data || MOCK_CUSTOMERS;
  const meta: any = (data as any)?.data?.meta || { total: MOCK_CUSTOMERS.length };

  const topSpenders = [...customers].sort((a, b) => (b.totalSpent || 0) - (a.totalSpent || 0)).slice(0, 3);

  return (
    <div className="space-y-5 max-w-[1400px]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Customers</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{meta.total} total customers</p>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: 'Total Customers', value: meta.total, icon: Users, color: 'text-brand-500', bg: 'bg-brand-500/10' },
          { label: 'Avg Order Value', value: formatCurrency(customers.reduce((s, c) => s + (c.avgOrderValue || 0), 0) / (customers.length || 1)), icon: DollarSign, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
          { label: 'Total Orders', value: customers.reduce((s, c) => s + (c.orderCount || 0), 0), icon: ShoppingCart, color: 'text-amber-500', bg: 'bg-amber-500/10' },
          { label: 'Total Revenue', value: formatCurrency(customers.reduce((s, c) => s + (c.totalSpent || 0), 0)), icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="stat-card flex items-center gap-4">
              <div className={`p-2.5 rounded-xl ${s.bg}`}><Icon className={`w-5 h-5 ${s.color}`} /></div>
              <div>
                <p className="text-2xl font-bold tracking-tight">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Search */}
      <div className="stat-card !p-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search customers by name or email..."
            onChange={(e) => debouncedSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-2 text-sm rounded-lg bg-muted border-0 outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
      </div>

      {/* Table */}
      <div className="stat-card !p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                {['Customer', 'Email', 'Orders', 'Total Spent', 'Avg Order', 'Last Order', 'Tags'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left font-medium text-muted-foreground text-xs uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading
                ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>{Array.from({ length: 7 }).map((_, j) => (
                    <td key={j} className="px-4 py-3"><div className="skeleton h-4 rounded" /></td>
                  ))}</tr>
                ))
                : customers.map((c: any, i: number) => (
                  <tr key={c.id || i} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-brand-500/20 flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-bold text-brand-600">
                            {(c.firstName?.[0] || c.email?.[0] || '?').toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-xs">
                            {c.firstName} {c.lastName}
                          </p>
                          {c.phone && <p className="text-xs text-muted-foreground">{c.phone}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{c.email}</td>
                    <td className="px-4 py-3 font-semibold text-xs">{c.orderCount || 0}</td>
                    <td className="px-4 py-3 font-semibold text-xs">{formatCurrency(c.totalSpent || 0)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{formatCurrency(c.avgOrderValue || 0)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {c.lastOrderedAt ? formatRelativeTime(c.lastOrderedAt) : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {(c.tags || []).slice(0, 2).map((t: string) => (
                          <span key={t} className="badge-info text-xs">{t}</span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

const MOCK_CUSTOMERS = [
  { id: '1', firstName: 'Sarah', lastName: 'Johnson', email: 'sarah@example.com', phone: '+1 555 0101', orderCount: 12, totalSpent: 1840, avgOrderValue: 153, lastOrderedAt: new Date(Date.now() - 86400000 * 2), tags: ['vip', 'repeat'] },
  { id: '2', firstName: 'Marcus', lastName: 'Williams', email: 'marcus@example.com', orderCount: 7, totalSpent: 920, avgOrderValue: 131, lastOrderedAt: new Date(Date.now() - 86400000 * 5), tags: ['repeat'] },
  { id: '3', firstName: 'Amina', lastName: 'Hassan', email: 'amina@example.com', phone: '+255 712 345678', orderCount: 3, totalSpent: 420, avgOrderValue: 140, lastOrderedAt: new Date(Date.now() - 86400000 * 10), tags: ['new'] },
  { id: '4', firstName: 'James', lastName: 'Lee', email: 'james@example.com', orderCount: 24, totalSpent: 3600, avgOrderValue: 150, lastOrderedAt: new Date(Date.now() - 3600000), tags: ['vip', 'loyal'] },
  { id: '5', firstName: 'Fatima', lastName: 'Al-Rashid', email: 'fatima@example.com', orderCount: 5, totalSpent: 680, avgOrderValue: 136, lastOrderedAt: new Date(Date.now() - 86400000 * 3), tags: ['repeat'] },
  { id: '6', firstName: 'David', lastName: 'Kimani', email: 'david@example.com', orderCount: 1, totalSpent: 89, avgOrderValue: 89, lastOrderedAt: new Date(Date.now() - 86400000 * 20), tags: ['new'] },
  { id: '7', firstName: 'Lisa', lastName: 'Chen', email: 'lisa@example.com', orderCount: 18, totalSpent: 2750, avgOrderValue: 153, lastOrderedAt: new Date(Date.now() - 86400000), tags: ['vip'] },
  { id: '8', firstName: 'Omar', lastName: 'Diallo', email: 'omar@example.com', orderCount: 8, totalSpent: 1120, avgOrderValue: 140, lastOrderedAt: new Date(Date.now() - 86400000 * 7), tags: ['repeat'] },
];
