import type { Metadata, Viewport } from 'next';
import { GeistSans } from 'geist/font/sans';
import { GeistMono } from 'geist/font/mono';
import './globals.css';
import { Providers } from '@/components/layout/providers';
import { Toaster } from '@/components/ui/toaster';

export const metadata: Metadata = {
  title: {
    default: 'DropShip AI — Intelligent Commerce Platform',
    template: '%s | DropShip AI',
  },
  description: 'AI-powered drop shipping platform with automated pricing, marketing, and supplier management.',
  keywords: ['dropshipping', 'ecommerce', 'AI', 'automation', 'SaaS'],
  authors: [{ name: 'DropShip AI' }],
  manifest: '/manifest.json',
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    title: 'DropShip AI',
    description: 'AI-powered drop shipping platform',
    siteName: 'DropShip AI',
  },
};

export const viewport: Viewport = {
  themeColor: '#4f63ff',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
      </head>
      <body className="min-h-screen bg-background font-sans antialiased">
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
