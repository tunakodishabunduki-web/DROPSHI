import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { authApi } from '@/lib/api';

// ── Types ──────────────────────────────────────────────────────────────────────
interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  tenantId: string;
  avatarUrl?: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  setUser: (user: User) => void;
  refreshUser: () => Promise<void>;
}

// ── Auth Store ─────────────────────────────────────────────────────────────────
export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const response = await authApi.login(email, password) as any;
          const { user, accessToken, refreshToken } = response.data;
          localStorage.setItem('access_token', accessToken);
          localStorage.setItem('refresh_token', refreshToken);
          localStorage.setItem('tenant_id', user.tenantId);
          set({ user, isAuthenticated: true });
        } finally {
          set({ isLoading: false });
        }
      },

      logout: async () => {
        const refreshToken = localStorage.getItem('refresh_token');
        if (refreshToken) {
          try { await authApi.logout(refreshToken); } catch {}
        }
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        localStorage.removeItem('tenant_id');
        set({ user: null, isAuthenticated: false });
        window.location.href = '/auth/login';
      },

      setUser: (user) => set({ user, isAuthenticated: true }),

      refreshUser: async () => {
        try {
          const response = await authApi.me() as any;
          set({ user: response.data, isAuthenticated: true });
        } catch {
          get().logout();
        }
      },
    }),
    {
      name: 'auth-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ user: s.user, isAuthenticated: s.isAuthenticated }),
    },
  ),
);

// ── UI Store ───────────────────────────────────────────────────────────────────
interface UiState {
  sidebarOpen: boolean;
  darkMode: boolean;
  notifications: Notification[];
  setSidebarOpen: (v: boolean) => void;
  toggleDarkMode: () => void;
  addNotification: (n: Notification) => void;
  removeNotification: (id: string) => void;
}

interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
}

export const useUiStore = create<UiState>((set) => ({
  sidebarOpen: true,
  darkMode: false,
  notifications: [],
  setSidebarOpen: (v) => set({ sidebarOpen: v }),
  toggleDarkMode: () => set((s) => {
    document.documentElement.classList.toggle('dark', !s.darkMode);
    return { darkMode: !s.darkMode };
  }),
  addNotification: (n) => set((s) => ({ notifications: [n, ...s.notifications].slice(0, 5) })),
  removeNotification: (id) => set((s) => ({ notifications: s.notifications.filter((n) => n.id !== id) })),
}));

// ── Cart Store ─────────────────────────────────────────────────────────────────
interface CartItem {
  productId: string;
  variantId?: string;
  name: string;
  image?: string;
  price: number;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (productId: string, variantId?: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  total: () => number;
  itemCount: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],

      addItem: (item) => set((s) => {
        const existing = s.items.find(
          (i) => i.productId === item.productId && i.variantId === item.variantId,
        );
        if (existing) {
          return {
            items: s.items.map((i) =>
              i.productId === item.productId && i.variantId === item.variantId
                ? { ...i, quantity: i.quantity + item.quantity }
                : i,
            ),
          };
        }
        return { items: [...s.items, item] };
      }),

      removeItem: (productId, variantId) => set((s) => ({
        items: s.items.filter(
          (i) => !(i.productId === productId && i.variantId === variantId),
        ),
      })),

      updateQuantity: (productId, quantity) => set((s) => ({
        items: quantity <= 0
          ? s.items.filter((i) => i.productId !== productId)
          : s.items.map((i) => (i.productId === productId ? { ...i, quantity } : i)),
      })),

      clearCart: () => set({ items: [] }),

      total: () => get().items.reduce((sum, i) => sum + i.price * i.quantity, 0),
      itemCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    { name: 'cart-store', storage: createJSONStorage(() => localStorage) },
  ),
);
