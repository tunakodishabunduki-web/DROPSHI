import { api } from './client';

// ─── Products API ──────────────────────────────────────────────────────────────
export const productsApi = {
  list: (params?: any) => api.get('/products', { params }),
  get: (id: string) => api.get(`/products/${id}`),
  search: (q: string, limit = 20) => api.get('/products/search', { params: { q, limit } }),
  trending: (limit = 20) => api.get('/products/trending', { params: { limit } }),
  create: (data: any) => api.post('/products', data),
  update: (id: string, data: any) => api.put(`/products/${id}`, data),
  updateStatus: (id: string, status: string) => api.patch(`/products/${id}/status`, { status }),
  delete: (id: string) => api.delete(`/products/${id}`),
  importFromSupplier: (supplierId: string, productIds: string[]) =>
    api.post('/products/import', { supplierId, productIds }),
  bulkUpdatePrices: (updates: any[]) => api.post('/products/bulk/price-update', { updates }),
  getPricingHistory: (id: string) => api.get(`/products/${id}/pricing-history`),
  getVariants: (id: string) => api.get(`/products/${id}/variants`),
  triggerAiAnalysis: (id: string) => api.patch(`/products/${id}/ai-analyze`),
  getAnalytics: () => api.get('/products/analytics'),
};

// ─── Orders API ────────────────────────────────────────────────────────────────
export const ordersApi = {
  list: (params?: any) => api.get('/orders', { params }),
  get: (id: string) => api.get(`/orders/${id}`),
  create: (data: any) => api.post('/orders', data),
  updateStatus: (id: string, status: string, meta?: any) =>
    api.patch(`/orders/${id}/status`, { status, ...meta }),
  cancel: (id: string, reason: string) => api.post(`/orders/${id}/cancel`, { reason }),
  refund: (id: string, amount?: number) => api.post(`/orders/${id}/refund`, { amount }),
  updateTracking: (id: string, tracking: any) => api.patch(`/orders/${id}/tracking`, tracking),
  getAnalytics: (dateFrom: string, dateTo: string) =>
    api.get('/orders/analytics', { params: { dateFrom, dateTo } }),
};

// ─── Analytics API ─────────────────────────────────────────────────────────────
export const analyticsApi = {
  getDashboardStats: () => api.get('/analytics/dashboard'),
  getSalesTimeSeries: (period: string) =>
    api.get('/analytics/sales-timeseries', { params: { period } }),
  getTopProducts: (limit = 10) =>
    api.get('/analytics/top-products', { params: { limit } }),
  getAdPerformance: (period = '30d') =>
    api.get('/analytics/ads', { params: { period } }),
  getSupplierPerformance: () => api.get('/analytics/suppliers'),
  exportOrders: (dateFrom: string, dateTo: string) =>
    api.get('/analytics/export/orders', { params: { dateFrom, dateTo }, responseType: 'blob' }),
  exportProducts: () => api.get('/analytics/export/products', { responseType: 'blob' }),
};

// ─── AI API ────────────────────────────────────────────────────────────────────
export const aiApi = {
  // Product Research
  discoverTrending: (options?: any) => api.get('/ai/research/trending', { params: options }),
  analyzeProduct: (productId: string) => api.post(`/ai/research/analyze/${productId}`),
  researchKeywords: (seed: string) => api.get('/ai/research/keywords', { params: { seed } }),
  analyzeCompetitors: (productName: string) =>
    api.post('/ai/research/competitors', { productName }),

  // Dynamic Pricing
  suggestPrice: (productId: string, strategy?: string) =>
    api.get(`/ai/pricing/suggest/${productId}`, { params: { strategy } }),
  applyPrice: (productId: string, data: any) => api.post(`/ai/pricing/apply/${productId}`, data),
  simulateImpact: (productId: string, newPrice: number) =>
    api.post(`/ai/pricing/simulate/${productId}`, { newPrice }),
  runBatchPricing: (strategy: string) => api.post('/ai/pricing/batch', { strategy }),

  // Marketing
  generateAdCopy: (data: any) => api.post('/ai/marketing/generate-ad', data),
  generateABVariants: (adId: string, count?: number) =>
    api.post(`/ai/marketing/ab-variants/${adId}`, { count }),
  scheduleCampaign: (adId: string, schedule: any) =>
    api.post(`/ai/marketing/schedule/${adId}`, schedule),
  getAdAnalytics: () => api.get('/ai/marketing/analytics'),

  // Customer Support
  triageTicket: (ticketId: string) => api.post(`/ai/support/triage/${ticketId}`),
  processMessage: (ticketId: string, message: string) =>
    api.post(`/ai/support/chat/${ticketId}`, { message }),
  bulkTriage: () => api.post('/ai/support/bulk-triage'),
  getSupportAnalytics: () => api.get('/ai/support/analytics'),

  // Supplier Sync
  syncAll: () => api.post('/ai/supplier-sync/all'),
  syncSupplier: (supplierId: string) => api.post(`/ai/supplier-sync/${supplierId}`),
  monitorHealth: () => api.get('/ai/supplier-sync/health'),

  // Logs
  getLogs: (params?: any) => api.get('/ai/logs', { params }),
};

// ─── Suppliers API ─────────────────────────────────────────────────────────────
export const suppliersApi = {
  list: (params?: any) => api.get('/suppliers', { params }),
  get: (id: string) => api.get(`/suppliers/${id}`),
  create: (data: any) => api.post('/suppliers', data),
  update: (id: string, data: any) => api.put(`/suppliers/${id}`, data),
  delete: (id: string) => api.delete(`/suppliers/${id}`),
  testConnection: (id: string) => api.post(`/suppliers/${id}/test-connection`),
  getProducts: (id: string) => api.get(`/suppliers/${id}/products`),
};

// ─── Payments API ──────────────────────────────────────────────────────────────
export const paymentsApi = {
  createStripeIntent: (orderId: string, amount: number, currency?: string) =>
    api.post('/payments/stripe/intent', { orderId, amount, currency }),
  confirmStripe: (paymentIntentId: string) =>
    api.post('/payments/stripe/confirm', { paymentIntentId }),
  createPayPalOrder: (orderId: string, amount: number) =>
    api.post('/payments/paypal/create', { orderId, amount }),
  capturePayPal: (paypalOrderId: string) =>
    api.post('/payments/paypal/capture', { paypalOrderId }),
  initiateMpesa: (orderId: string, amount: number, phone: string) =>
    api.post('/payments/mpesa/stk-push', { orderId, amount, phone }),
};

// ─── Auth API ──────────────────────────────────────────────────────────────────
export const authApi = {
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
  register: (data: any) => api.post('/auth/register', data),
  refresh: (refreshToken: string) => api.post('/auth/refresh', { refreshToken }),
  logout: (refreshToken: string) => api.post('/auth/logout', { refreshToken }),
  me: () => api.get('/auth/me'),
  googleAuth: () => (window.location.href = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/google`),
};
