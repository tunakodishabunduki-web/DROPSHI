// analytics.api.ts — frontend API wrappers
import { api } from './client';

export const analyticsApi = {
  getDashboardStats: () => api.get('/analytics/dashboard'),
  getSalesTimeSeries: (period: string) =>
    api.get('/analytics/sales-timeseries', { params: { period } }),
  getTopProducts: (limit = 10) =>
    api.get('/analytics/top-products', { params: { limit } }),
  getAdPerformance: (period = '30d') =>
    api.get('/analytics/ads', { params: { period } }),
  getSupplierPerformance: () => api.get('/analytics/suppliers'),
  exportOrders: (dateFrom: string, dateTo: string) =>
    api.get('/analytics/export/orders', {
      params: { dateFrom, dateTo },
      responseType: 'blob',
    }),
};
