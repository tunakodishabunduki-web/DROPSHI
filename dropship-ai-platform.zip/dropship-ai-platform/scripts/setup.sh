#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# DropShip AI Platform — Quick Setup Script
# Usage: ./scripts/setup.sh [dev|docker|production]
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE=${1:-dev}
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo -e "${GREEN}"
echo "╔══════════════════════════════════════════╗"
echo "║     DropShip AI Platform Setup           ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# ── Check prerequisites ────────────────────────────────────────────────────────
check_cmd() {
  command -v "$1" &>/dev/null || error "$1 is required but not installed."
}

check_cmd node
check_cmd npm
check_cmd docker
check_cmd docker-compose

NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
[ "$NODE_VER" -ge 20 ] || error "Node.js 20+ is required (found v${NODE_VER})"

info "All prerequisites satisfied."

# ── Setup .env ────────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  info "Creating .env from template..."
  cp .env.example .env

  # Generate secrets
  JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
  JWT_REFRESH_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")

  if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' "s/super_secret_jwt_key_change_in_production/${JWT_SECRET}/" .env
    sed -i '' "s/super_secret_refresh_key_change_in_production/${JWT_REFRESH_SECRET}/" .env
  else
    sed -i "s/super_secret_jwt_key_change_in_production/${JWT_SECRET}/" .env
    sed -i "s/super_secret_refresh_key_change_in_production/${JWT_REFRESH_SECRET}/" .env
  fi

  warn ".env created — please add your API keys (OPENAI_API_KEY, STRIPE_SECRET_KEY, etc.)"
else
  info ".env already exists — skipping."
fi

# ── Mode-specific setup ───────────────────────────────────────────────────────
case $MODE in
  dev)
    info "Setting up development environment..."
    info "Installing root dependencies..."
    npm install

    info "Installing backend dependencies..."
    cd backend && npm install && cd ..

    info "Installing frontend dependencies..."
    cd frontend && npm install && cd ..

    info "Installing AI module dependencies..."
    cd ai-modules && pip3 install -r requirements.txt --break-system-packages 2>/dev/null || \
      python3 -m pip install -r requirements.txt 2>/dev/null || \
      warn "Python deps install failed — install manually with: pip install -r ai-modules/requirements.txt"
    cd ..

    info "Starting infrastructure services..."
    docker-compose up -d postgres redis rabbitmq

    info "Waiting for PostgreSQL..."
    sleep 5
    until docker-compose exec -T postgres pg_isready -U dropship 2>/dev/null; do
      sleep 2
    done

    info "Running database migrations..."
    docker-compose exec -T postgres psql -U dropship -d dropship_db \
      -f /docker-entrypoint-initdb.d/001_initial_schema.sql 2>/dev/null || \
      PGPASSWORD=dropship_secret psql -h localhost -U dropship -d dropship_db \
        -f database/migrations/001_initial_schema.sql

    info "Seeding demo data..."
    PGPASSWORD=dropship_secret psql -h localhost -U dropship -d dropship_db \
      -f database/seeds/001_demo_data.sql 2>/dev/null || warn "Seed failed — run manually"

    echo ""
    echo -e "${GREEN}✅ Development setup complete!${NC}"
    echo ""
    echo "  Start the dev servers:"
    echo "    npm run dev           # starts backend + frontend"
    echo "    npm run dev:backend   # backend only (http://localhost:4000)"
    echo "    npm run dev:frontend  # frontend only (http://localhost:3000)"
    echo ""
    echo "  Infrastructure (already running):"
    echo "    PostgreSQL:   localhost:5432"
    echo "    Redis:        localhost:6379"
    echo "    RabbitMQ UI:  http://localhost:15672 (dropship/rabbitmq_secret)"
    echo ""
    ;;

  docker)
    info "Building and starting Docker Compose stack..."
    docker-compose build --parallel
    docker-compose up -d

    info "Waiting for services to start..."
    sleep 15

    info "Running migrations..."
    docker-compose exec backend node dist/main --migrate || true

    echo ""
    echo -e "${GREEN}✅ Docker stack running!${NC}"
    echo ""
    echo "  Frontend:       http://localhost:3000"
    echo "  Backend API:    http://localhost:4000"
    echo "  API Docs:       http://localhost:4000/api/docs"
    echo "  RabbitMQ UI:    http://localhost:15672"
    echo "  Grafana:        http://localhost:3001"
    echo "  Prometheus:     http://localhost:9090"
    echo ""
    ;;

  production)
    info "Production setup requires Kubernetes. Check infra/kubernetes/ for manifests."
    info "1. Apply namespace:  kubectl apply -f infra/kubernetes/namespace.yaml"
    info "2. Apply secrets:    kubectl apply -f infra/kubernetes/secrets.yaml"
    info "3. Apply configs:    kubectl apply -f infra/kubernetes/configmaps/"
    info "4. Deploy services:  kubectl apply -f infra/kubernetes/deployments/"
    info "5. Expose services:  kubectl apply -f infra/kubernetes/services/"
    info "6. Auto-scaling:     kubectl apply -f infra/kubernetes/hpa/"
    ;;

  *)
    error "Unknown mode: $MODE. Use: dev, docker, or production"
    ;;
esac
