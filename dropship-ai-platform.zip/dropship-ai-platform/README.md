# DropShip AI Platform

> A fully automated, AI-powered drop shipping SaaS platform with intelligent pricing, marketing, customer support, and supplier management.

[![CI/CD](https://github.com/your-org/dropship-ai/actions/workflows/ci.yml/badge.svg)](https://github.com/your-org/dropship-ai/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        NGINX (Reverse Proxy)                     │
└──────────────────┬──────────────────────┬───────────────────────┘
                   │                      │
        ┌──────────▼──────────┐  ┌────────▼────────────┐
        │   Next.js Frontend  │  │   NestJS Backend     │
        │   (SSR + PWA)       │  │   (REST + GraphQL)   │
        └─────────────────────┘  └────────┬────────────┘
                                          │
              ┌───────────────────────────┼───────────────────────┐
              │                           │                        │
    ┌─────────▼──────┐        ┌──────────▼──────┐     ┌──────────▼──────┐
    │  PostgreSQL 16  │        │   Redis Cache    │     │   RabbitMQ       │
    │  (partitioned)  │        │   (sessions +    │     │  (5 queues)      │
    └─────────────────┘        │    hot data)     │     └─────────┬────────┘
                               └─────────────────┘               │
                                                    ┌─────────────▼──────────┐
                                                    │     AI Module Workers   │
                                                    │  ┌─────────────────┐    │
                                                    │  │ Product Research│    │
                                                    │  │ Dynamic Pricing │    │
                                                    │  │ Marketing AI    │    │
                                                    │  │ Customer Support│    │
                                                    │  │ Supplier Sync   │    │
                                                    │  └─────────────────┘    │
                                                    └────────────────────────┘
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, TypeScript, Tailwind CSS, Framer Motion |
| Backend | NestJS 10, TypeScript, Passport.js, GraphQL |
| Database | PostgreSQL 16 (partitioned tables), TypeORM |
| Cache | Redis 7 |
| Queue | RabbitMQ 3.13 (with DLQ + retry policies) |
| AI Modules | Python 3.12, OpenAI GPT-4o |
| Payments | Stripe, PayPal, M-Pesa |
| Suppliers | AliExpress, Shopify, Amazon FBA |
| Monitoring | Prometheus, Grafana |
| DevOps | Docker, Kubernetes, GitHub Actions |

---

## Project Structure

```
dropship-ai-platform/
├── frontend/                   # Next.js web application
│   ├── src/
│   │   ├── app/                # App Router pages
│   │   │   ├── auth/           # Login, register
│   │   │   └── dashboard/      # Main SaaS dashboard
│   │   ├── components/         # Reusable UI components
│   │   ├── lib/
│   │   │   ├── api/            # API client & endpoints
│   │   │   └── stores/         # Zustand state stores
│   │   └── hooks/              # Custom React hooks
│   └── Dockerfile
│
├── backend/                    # NestJS API server
│   └── src/
│       ├── modules/
│       │   ├── auth/           # JWT + OAuth2 authentication
│       │   ├── products/       # Product catalog management
│       │   ├── orders/         # Order lifecycle management
│       │   ├── suppliers/      # Supplier integrations
│       │   ├── payments/       # Stripe + PayPal + M-Pesa
│       │   ├── analytics/      # Reporting & dashboards
│       │   ├── ai/             # AI module orchestration
│       │   └── webhooks/       # Payment & shipping webhooks
│       ├── common/             # Guards, filters, interceptors
│       └── config/             # App configuration
│
├── ai-modules/                 # Python AI workers
│   ├── product_research/       # Trend discovery & product scoring
│   ├── dynamic_pricing/        # Price optimization strategies
│   ├── marketing/              # Ad copy & campaign generation
│   ├── customer_support/       # Ticket triage & auto-responses
│   ├── supplier_sync/          # Inventory sync & failover
│   └── shared/                 # Base worker & RabbitMQ utilities
│
├── database/
│   ├── migrations/             # PostgreSQL schema migrations
│   └── seeds/                  # Demo data seeds
│
├── infra/
│   ├── docker/                 # Nginx config
│   ├── kubernetes/             # K8s deployments, services, HPA
│   ├── ci-cd/                  # GitHub Actions pipeline
│   └── monitoring/             # Prometheus + Grafana config
│
├── scripts/                    # Setup & utility scripts
└── docker-compose.yml          # Full local stack
```

---

## Quick Start

### Option 1: Docker (Recommended)

```bash
# 1. Clone and setup
git clone https://github.com/your-org/dropship-ai.git
cd dropship-ai-platform

# 2. Configure environment
cp .env.example .env
# Edit .env and add your API keys

# 3. Launch everything
docker-compose up -d

# 4. Access the platform
open http://localhost:3000
```

### Option 2: Local Development

```bash
# Prerequisites: Node 20+, Python 3.12+, PostgreSQL 16, Redis, RabbitMQ

# 1. Run setup script
chmod +x scripts/setup.sh
./scripts/setup.sh dev

# 2. Start all services
npm run dev
```

Services will be available at:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:4000
- **API Docs (Swagger)**: http://localhost:4000/api/docs
- **RabbitMQ Management**: http://localhost:15672
- **Grafana**: http://localhost:3001
- **Prometheus**: http://localhost:9090

---

## Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
# Required
DATABASE_URL=postgresql://...
REDIS_URL=redis://...
RABBITMQ_URL=amqp://...
JWT_SECRET=<generate-strong-secret>
OPENAI_API_KEY=sk-...
STRIPE_SECRET_KEY=sk_test_...

# Optional but recommended
PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...
MPESA_CONSUMER_KEY=...
ALIEXPRESS_APP_KEY=...
SHOPIFY_API_KEY=...
GOOGLE_CLIENT_ID=...
```

---

## AI Modules

| Module | Queue | Description |
|--------|-------|-------------|
| **Product Research** | `ai_tasks_queue` | Analyzes product viability (GPT-4o), scores trends, discovers winning products |
| **Dynamic Pricing** | `ai_tasks_queue` | 6 strategies: cost-plus, competitor, demand-based, AI-optimal, penetration, premium |
| **Marketing AI** | `marketing_campaign_queue` | Generates platform-specific ad copy (TikTok, Instagram, Facebook, Google), A/B variants |
| **Customer Support** | `customer_support_queue` | Auto-triages tickets, generates responses, escalates when needed |
| **Supplier Sync** | `supplier_sync_queue` | Monitors inventory, applies failover in <60s, tracks reliability scores |

---

## API Overview

```
POST   /api/v1/auth/register          # Register new account
POST   /api/v1/auth/login             # Login (JWT)
POST   /api/v1/auth/refresh           # Refresh access token

GET    /api/v1/products               # List products (filtered + paginated)
GET    /api/v1/products/trending      # AI-ranked trending products
POST   /api/v1/products               # Create product
PATCH  /api/v1/products/:id/ai-analyze # Trigger AI analysis

GET    /api/v1/orders                 # List orders
POST   /api/v1/orders                 # Create order
PATCH  /api/v1/orders/:id/status      # Update order status

POST   /api/v1/payments/stripe/intent # Create Stripe payment intent
POST   /api/v1/payments/paypal/create # Create PayPal order
POST   /api/v1/payments/mpesa/stk-push # M-Pesa STK push

GET    /api/v1/analytics/dashboard    # Dashboard KPIs
GET    /api/v1/analytics/sales-timeseries # Revenue over time

POST   /api/v1/ai/pricing/suggest/:id # AI price suggestion
POST   /api/v1/ai/marketing/generate-ad # Generate ad creatives
POST   /api/v1/ai/supplier-sync/all   # Sync all suppliers
```

Full Swagger docs at `/api/docs`.

---

## Database Design

- **Multi-tenant isolation** via `tenant_id` on every table
- **Partitioned tables** for high-volume data: `orders`, `ai_logs`, `trends`, `audit_logs`, `pricing_history`
- **Full-text search** via `pg_trgm` and tsvector indexes on products
- **Automatic aggregation** of daily analytics via triggers

---

## Deployment

### Docker Compose (staging)
```bash
docker-compose -f docker-compose.yml up -d
```

### Kubernetes (production)
```bash
# Apply namespace and secrets
kubectl apply -f infra/kubernetes/

# Check status
kubectl get pods -n dropship

# Scale backend
kubectl scale deployment dropship-backend --replicas=5 -n dropship
```

The CI/CD pipeline (GitHub Actions) handles:
1. Lint & test on every PR
2. Build and push Docker images on merge to `main`
3. Rolling deployment to Kubernetes
4. Blue-green deployment with automatic rollback

---

## Running Tests

```bash
# Backend unit + integration tests
cd backend && npm run test:cov

# Frontend tests
cd frontend && npm run test

# E2E tests
cd backend && npm run test:e2e
```

---

## Multi-tenancy

Each tenant gets complete data isolation:
- All tables include `tenant_id` foreign key
- JWT tokens carry `tenantId` claim
- API requests validated against JWT's tenant
- Separate RabbitMQ routing per tenant
- Tenant-specific caching keys in Redis

---

## Security

- Argon2id password hashing
- JWT access tokens (15m) + refresh token rotation with family invalidation
- Rate limiting (NestJS Throttler + Nginx)
- Helmet.js security headers
- Input validation with class-validator
- Audit log for all write operations
- Webhook signature verification (Stripe HMAC)
- Encrypted supplier API credentials (stored in JSONB, encrypted at app level)

---

## License

MIT — see [LICENSE](LICENSE)
