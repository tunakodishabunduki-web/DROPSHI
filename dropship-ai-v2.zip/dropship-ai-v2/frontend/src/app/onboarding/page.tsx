'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Store, ChevronRight, ChevronLeft, CheckCircle,
  Truck, CreditCard, Instagram, Globe, Zap,
  DollarSign, Music2, Facebook, ArrowRight, Loader2,
} from 'lucide-react';
import { api } from '@/lib/api/client';

const STEPS = [
  { id: 1, title: 'Store Profile', icon: Store, description: 'Tell us about your store' },
  { id: 2, title: 'Connect Supplier', icon: Truck, description: 'Link your product source' },
  { id: 3, title: 'Profit Rules', icon: DollarSign, description: 'Set your margins & limits' },
  { id: 4, title: 'Payments', icon: CreditCard, description: 'Accept customer payments' },
  { id: 5, title: 'Social Media', icon: Instagram, description: 'Automate your advertising' },
];

const NICHES = ['Electronics', 'Fashion & Apparel', 'Home & Garden', 'Health & Beauty', 'Sports & Outdoors', 'Toys & Games', 'Pet Supplies', 'General'];
const MARKETS = ['USA', 'UK', 'Europe', 'East Africa', 'West Africa', 'Australia', 'Global'];
const CURRENCIES = ['USD', 'EUR', 'GBP', 'TZS', 'KES', 'NGN'];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [completing, setCompleting] = useState(false);
  const [profile, setProfile] = useState({
    storeName: '',
    niche: 'Electronics',
    market: 'USA',
    currency: 'USD',
    timezone: 'UTC',
  });
  const [supplier, setSupplier] = useState({ type: 'aliexpress', connected: false });
  const [profitRules, setProfitRules] = useState({
    minMarginPercent: 35,
    maxDailyAdSpend: 50,
    autoImportThreshold: 75,
    autopilotEnabled: false,
  });
  const [payments, setPayments] = useState({ stripe: false, paypal: false, mpesa: false });
  const [socials, setSocials] = useState({ tiktok: false, instagram: false, facebook: false });

  const progress = ((step - 1) / (STEPS.length - 1)) * 100;

  const handleNext = () => {
    if (step < STEPS.length) setStep(step + 1);
    else handleComplete();
  };

  const handleComplete = async () => {
    setCompleting(true);
    try {
      await api.post('/onboarding/complete', { profile, profitRules });
      router.push('/dashboard');
    } catch {
      router.push('/dashboard');
    } finally {
      setCompleting(false);
    }
  };

  const canNext = () => {
    if (step === 1) return profile.storeName.length >= 2;
    if (step === 4) return payments.stripe || payments.paypal || payments.mpesa;
    return true;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-950 via-background to-background flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-80 xl:w-96 bg-card/50 backdrop-blur border-r border-border flex-col p-8">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-9 h-9 rounded-xl bg-brand-500 flex items-center justify-center shadow-lg shadow-brand-500/30">
            <Store className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg">DropShip AI</span>
        </div>

        <h2 className="text-2xl font-bold mb-2">Set up your store</h2>
        <p className="text-sm text-muted-foreground mb-8">5 steps to your first AI-powered drop shipping store</p>

        {/* Progress bar */}
        <div className="mb-8">
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-brand-500 rounded-full"
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">{step} of {STEPS.length} steps</p>
        </div>

        {/* Steps list */}
        <div className="space-y-1">
          {STEPS.map((s) => {
            const Icon = s.icon;
            const done = step > s.id;
            const active = step === s.id;
            return (
              <div key={s.id} className={`flex items-center gap-3 p-3 rounded-xl transition-colors ${
                active ? 'bg-brand-500/10 text-brand-500' : done ? 'text-muted-foreground' : 'text-muted-foreground/50'
              }`}>
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  done ? 'bg-emerald-500/10' : active ? 'bg-brand-500/20' : 'bg-muted'
                }`}>
                  {done
                    ? <CheckCircle className="w-4 h-4 text-emerald-500" />
                    : <Icon className={`w-4 h-4 ${active ? 'text-brand-500' : ''}`} />}
                </div>
                <div>
                  <p className={`text-sm font-medium ${active ? 'text-brand-500' : done ? 'text-foreground' : ''}`}>{s.title}</p>
                  <p className="text-xs text-muted-foreground">{s.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-auto">
          <div className="p-4 rounded-xl bg-brand-500/5 border border-brand-500/20">
            <p className="text-xs font-semibold text-brand-500 mb-1">💡 Quick Tip</p>
            <p className="text-xs text-muted-foreground">
              {step === 1 && 'Choose a specific niche rather than "general" — it helps the AI find better trending products for your market.'}
              {step === 2 && 'AliExpress is recommended for beginners. You can add more suppliers later from the Suppliers page.'}
              {step === 3 && 'Set minimum margin to 35%+ after all costs. Lower margins leave no buffer for refunds and fees.'}
              {step === 4 && 'Stripe is recommended for US/EU sales. Add M-Pesa for East African customers.'}
              {step === 5 && 'TikTok delivers the best ROI for most drop shipping niches. Start with one platform and expand.'}
            </p>
          </div>
        </div>
      </div>

      {/* Right panel - step content */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="w-full max-w-lg">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              {/* Step header */}
              <div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                  <span>Step {step} of {STEPS.length}</span>
                  <span>·</span>
                  <span>{STEPS[step - 1].description}</span>
                </div>
                <h2 className="text-3xl font-bold">{STEPS[step - 1].title}</h2>
              </div>

              {/* ── Step 1: Store Profile ────────────────────────────── */}
              {step === 1 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Store Name *</label>
                    <input
                      value={profile.storeName}
                      onChange={(e) => setProfile({ ...profile, storeName: e.target.value })}
                      placeholder="e.g. TechGadgetsHub, StyleDrops, QuickDeals"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all"
                    />
                    <p className="text-xs text-muted-foreground mt-1.5">This appears in your store and emails</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1.5">Product Niche</label>
                    <div className="grid grid-cols-2 gap-2">
                      {NICHES.map((n) => (
                        <button key={n} onClick={() => setProfile({ ...profile, niche: n })}
                          className={`py-2.5 px-3 rounded-xl border text-sm font-medium transition-all text-left ${
                            profile.niche === n
                              ? 'border-brand-500 bg-brand-500/10 text-brand-500'
                              : 'border-border hover:border-brand-500/30 text-muted-foreground hover:text-foreground'
                          }`}>
                          {n}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Primary Market</label>
                      <select value={profile.market} onChange={(e) => setProfile({ ...profile, market: e.target.value })}
                        className="w-full px-3 py-3 rounded-xl border border-border bg-background text-sm outline-none focus:ring-2 focus:ring-brand-500/30">
                        {MARKETS.map((m) => <option key={m} value={m}>{m}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5">Currency</label>
                      <select value={profile.currency} onChange={(e) => setProfile({ ...profile, currency: e.target.value })}
                        className="w-full px-3 py-3 rounded-xl border border-border bg-background text-sm outline-none focus:ring-2 focus:ring-brand-500/30">
                        {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* ── Step 2: Supplier ────────────────────────────────── */}
              {step === 2 && (
                <div className="space-y-3">
                  {[
                    { id: 'aliexpress', name: 'AliExpress', desc: 'Largest selection, 30-60 day shipping', badge: 'Recommended', color: 'text-orange-500' },
                    { id: 'cj_dropshipping', name: 'CJ Dropshipping', desc: 'Faster shipping (7-15 days), good margins', badge: 'Fast', color: 'text-blue-500' },
                    { id: 'shopify', name: 'Shopify Supplier', desc: 'Connect any Shopify wholesale store', badge: null, color: 'text-brand-500' },
                    { id: 'custom', name: 'Custom API', desc: 'Connect your own supplier via API', badge: null, color: 'text-muted-foreground' },
                  ].map((s) => (
                    <div key={s.id}
                      onClick={() => setSupplier({ type: s.id, connected: false })}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        supplier.type === s.id
                          ? 'border-brand-500 bg-brand-500/5'
                          : 'border-border hover:border-brand-500/30'
                      }`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-semibold text-sm">{s.name}</p>
                            {s.badge && (
                              <span className={`text-xs font-bold px-2 py-0.5 rounded-full bg-muted ${s.color}`}>
                                {s.badge}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">{s.desc}</p>
                        </div>
                        {supplier.type === s.id && <CheckCircle className="w-5 h-5 text-brand-500" />}
                      </div>
                    </div>
                  ))}
                  <p className="text-xs text-muted-foreground pt-2">
                    ✓ We'll connect to your supplier after setup. The AI will start scanning for products in your niche immediately.
                  </p>
                </div>
              )}

              {/* ── Step 3: Profit Rules ──────────────────────────── */}
              {step === 3 && (
                <div className="space-y-5">
                  <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20">
                    <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">⚠️ This step is critical</p>
                    <p className="text-xs text-muted-foreground">These rules protect your money. The AI will never violate them — even in Autopilot mode.</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Minimum Profit Margin: <span className="text-brand-500 font-bold">{profitRules.minMarginPercent}%</span>
                    </label>
                    <input type="range" min="15" max="80" step="5"
                      value={profitRules.minMarginPercent}
                      onChange={(e) => setProfitRules({ ...profitRules, minMarginPercent: +e.target.value })}
                      className="w-full accent-brand-500" />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>15% (risky)</span>
                      <span className="text-emerald-500 font-medium">35-40% (recommended)</span>
                      <span>80% (conservative)</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      The AI will never price a product below this margin. After payment fees, shipping, and refunds, margins below 25% can result in actual losses.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Max Daily Ad Spend: <span className="text-brand-500 font-bold">${profitRules.maxDailyAdSpend}</span>
                    </label>
                    <input type="range" min="5" max="500" step="5"
                      value={profitRules.maxDailyAdSpend}
                      onChange={(e) => setProfitRules({ ...profitRules, maxDailyAdSpend: +e.target.value })}
                      className="w-full accent-brand-500" />
                    <p className="text-xs text-muted-foreground mt-1">Hard cap. Autopilot will never exceed this even if ROAS is high.</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Auto-Import Score Threshold: <span className="text-brand-500 font-bold">{profitRules.autoImportThreshold}/100</span>
                    </label>
                    <input type="range" min="50" max="95" step="5"
                      value={profitRules.autoImportThreshold}
                      onChange={(e) => setProfitRules({ ...profitRules, autoImportThreshold: +e.target.value })}
                      className="w-full accent-brand-500" />
                    <p className="text-xs text-muted-foreground mt-1">Products scoring above this are auto-imported. Higher = fewer but better products.</p>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                    <div>
                      <p className="text-sm font-medium">Enable Autopilot Mode</p>
                      <p className="text-xs text-muted-foreground">Let AI manage pricing, ads, and suppliers automatically</p>
                    </div>
                    <div
                      onClick={() => setProfitRules({ ...profitRules, autopilotEnabled: !profitRules.autopilotEnabled })}
                      className={`w-12 h-6 rounded-full transition-colors cursor-pointer ${profitRules.autopilotEnabled ? 'bg-brand-500' : 'bg-muted'}`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white shadow-sm mt-0.5 transition-transform ${profitRules.autopilotEnabled ? 'translate-x-6' : 'translate-x-0.5'}`} />
                    </div>
                  </div>
                </div>
              )}

              {/* ── Step 4: Payments ─────────────────────────────── */}
              {step === 4 && (
                <div className="space-y-3">
                  {[
                    { id: 'stripe', name: 'Stripe', desc: 'Credit/debit cards, Apple Pay, Google Pay. Best for US/EU.', logo: '💳', recommended: true },
                    { id: 'paypal', name: 'PayPal', desc: 'PayPal balance, cards. Popular worldwide.', logo: '🅿️', recommended: false },
                    { id: 'mpesa', name: 'M-Pesa', desc: 'Mobile money for East Africa (Kenya, Tanzania).', logo: '📱', recommended: false },
                  ].map((p) => (
                    <div key={p.id}
                      onClick={() => setPayments((prev) => ({ ...prev, [p.id]: !prev[p.id as keyof typeof prev] }))}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        payments[p.id as keyof typeof payments]
                          ? 'border-brand-500 bg-brand-500/5'
                          : 'border-border hover:border-brand-500/30'
                      }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{p.logo}</span>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-sm">{p.name}</p>
                              {p.recommended && <span className="text-xs font-bold text-brand-500 bg-brand-500/10 px-2 py-0.5 rounded-full">Recommended</span>}
                            </div>
                            <p className="text-xs text-muted-foreground mt-0.5">{p.desc}</p>
                          </div>
                        </div>
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          payments[p.id as keyof typeof payments]
                            ? 'border-brand-500 bg-brand-500'
                            : 'border-border'
                        }`}>
                          {payments[p.id as keyof typeof payments] && <CheckCircle className="w-3 h-3 text-white" />}
                        </div>
                      </div>
                    </div>
                  ))}
                  <p className="text-xs text-muted-foreground">
                    ✓ You'll connect API keys on the next screen. Select all payment methods you want to offer customers.
                  </p>
                </div>
              )}

              {/* ── Step 5: Social Media ─────────────────────────── */}
              {step === 5 && (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-brand-500/5 border border-brand-500/20">
                    <p className="text-xs font-semibold text-brand-500 mb-1">🚀 Highest ROI Feature</p>
                    <p className="text-xs text-muted-foreground">Connected stores generate 3-5x more revenue than unconnected stores through automated AI advertising.</p>
                  </div>

                  {[
                    { id: 'tiktok', name: 'TikTok', desc: 'Best for viral products & Gen Z. Average 3-5x ROAS.', icon: Music2, gradient: 'from-black to-gray-800', badge: 'Best ROI' },
                    { id: 'instagram', name: 'Instagram', desc: 'Aesthetic products, lifestyle brands. Strong for fashion/beauty.', icon: Instagram, gradient: 'from-purple-600 to-pink-500', badge: null },
                    { id: 'facebook', name: 'Facebook', desc: 'Best retargeting, broad audiences. Ideal for home/garden.', icon: Facebook, gradient: 'from-blue-700 to-blue-500', badge: null },
                  ].map((s) => {
                    const Icon = s.icon;
                    const connected = socials[s.id as keyof typeof socials];
                    return (
                      <div key={s.id}
                        onClick={() => setSocials((prev) => ({ ...prev, [s.id]: !prev[s.id as keyof typeof prev] }))}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${
                          connected ? 'border-brand-500 bg-brand-500/5' : 'border-border hover:border-brand-500/30'
                        }`}>
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.gradient} flex items-center justify-center flex-shrink-0`}>
                            <Icon className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-sm">{s.name}</p>
                              {s.badge && <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">{s.badge}</span>}
                            </div>
                            <p className="text-xs text-muted-foreground mt-0.5">{s.desc}</p>
                          </div>
                          <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${connected ? 'border-brand-500 bg-brand-500' : 'border-border'}`}>
                            {connected && <CheckCircle className="w-3 h-3 text-white" />}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <p className="text-xs text-muted-foreground">
                    ✓ You can skip this now and connect from Settings → Social Media later. The store will still work — you'll just approve ads manually.
                  </p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Navigation buttons */}
          <div className="flex items-center gap-3 mt-8">
            {step > 1 && (
              <button onClick={() => setStep(step - 1)}
                className="flex items-center gap-2 px-4 py-3 border border-border rounded-xl text-sm hover:bg-muted transition-colors">
                <ChevronLeft className="w-4 h-4" /> Back
              </button>
            )}
            <button
              onClick={handleNext}
              disabled={!canNext() || completing}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-brand-500 hover:bg-brand-600 text-white font-semibold rounded-xl transition-colors disabled:opacity-50"
            >
              {completing ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Setting up your store...</>
              ) : step === STEPS.length ? (
                <><Zap className="w-4 h-4" /> Launch My Store</>
              ) : (
                <>Continue <ChevronRight className="w-4 h-4" /></>
              )}
            </button>
          </div>

          {step === STEPS.length && (
            <button onClick={() => router.push('/dashboard')}
              className="w-full mt-2 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              Skip for now and set up later
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
