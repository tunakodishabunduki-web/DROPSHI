'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Zap, Power, Shield, TrendingUp, DollarSign,
  Truck, CheckCircle, Clock, AlertTriangle, RefreshCw,
  Settings, ChevronRight, Bot, BarChart2, Play, Pause,
} from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatCurrency, formatRelativeTime } from '@/lib/utils';

const ACTION_ICONS: Record<string, any> = {
  PRICE_UPDATE: DollarSign,
  PAUSE_AD: Pause,
  SUPPLIER_FAILOVER: Truck,
  AUTO_IMPORT: Play,
  RESPOND_TICKET: Bot,
};

const ACTION_COLORS: Record<string, string> = {
  PRICE_UPDATE: 'text-blue-500 bg-blue-500/10',
  PAUSE_AD: 'text-amber-500 bg-amber-500/10',
  SUPPLIER_FAILOVER: 'text-rose-500 bg-rose-500/10',
  AUTO_IMPORT: 'text-emerald-500 bg-emerald-500/10',
  RESPOND_TICKET: 'text-purple-500 bg-purple-500/10',
};

export default function AutopilotPage() {
  const qc = useQueryClient();
  const [showConfig, setShowConfig] = useState(false);
  const [configDraft, setConfigDraft] = useState<any>(null);

  const { data: status, isLoading } = useQuery({
    queryKey: ['autopilot-status'],
    queryFn: () => api.get('/autopilot/status'),
    refetchInterval: 30_000,
  });

  const { data: decisionsData } = useQuery({
    queryKey: ['autopilot-decisions'],
    queryFn: () => api.get('/autopilot/decisions?limit=20'),
    refetchInterval: 30_000,
  });

  const enableMutation = useMutation({
    mutationFn: () => api.post('/autopilot/enable'),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['autopilot-status'] }),
  });

  const disableMutation = useMutation({
    mutationFn: () => api.post('/autopilot/disable'),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['autopilot-status'] }),
  });

  const updateConfigMutation = useMutation({
    mutationFn: (cfg: any) => api.put('/autopilot/config', cfg),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['autopilot-status'] });
      setShowConfig(false);
    },
  });

  const importMutation = useMutation({
    mutationFn: () => api.post('/autopilot/auto-import'),
  });

  const s: any = (status as any)?.data;
  const decisions: any[] = (decisionsData as any)?.data?.data || [];
  const isEnabled = s?.enabled || false;
  const weekStats: any = s?.weeklyStats || {};

  return (
    <div className="space-y-6 max-w-[1400px]">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Autopilot Mode</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            AI-powered store management — works 24/7 so you don't have to
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => importMutation.mutate()}
            disabled={importMutation.isPending}
            className="flex items-center gap-2 px-3 py-2 text-sm border border-border rounded-lg hover:bg-muted transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${importMutation.isPending ? 'animate-spin' : ''}`} />
            Import Products
          </button>
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="flex items-center gap-2 px-3 py-2 text-sm border border-border rounded-lg hover:bg-muted transition-colors"
          >
            <Settings className="w-3.5 h-3.5" />
            Configure Rules
          </button>
        </div>
      </div>

      {/* Main Power Toggle */}
      <motion.div
        className={`relative rounded-2xl p-8 overflow-hidden transition-all duration-500 ${
          isEnabled
            ? 'bg-gradient-to-br from-brand-600 to-brand-800 text-white'
            : 'bg-card border border-border'
        }`}
        animate={{ scale: isEnabled ? 1.01 : 1 }}
      >
        {isEnabled && (
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-white rounded-full opacity-30"
                style={{ left: `${15 + i * 15}%`, top: `${20 + (i % 3) * 25}%` }}
                animate={{ y: [-10, 10, -10], opacity: [0.2, 0.5, 0.2] }}
                transition={{ duration: 2 + i * 0.5, repeat: Infinity }}
              />
            ))}
          </div>
        )}

        <div className="relative z-10 flex items-center justify-between flex-wrap gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className={`w-3 h-3 rounded-full ${isEnabled ? 'bg-green-400 animate-pulse' : 'bg-muted-foreground/30'}`} />
              <span className={`text-sm font-medium ${isEnabled ? 'text-brand-100' : 'text-muted-foreground'}`}>
                {isEnabled ? 'AUTOPILOT ACTIVE — Running 24/7' : 'AUTOPILOT OFFLINE'}
              </span>
            </div>
            <h2 className={`text-3xl font-bold ${isEnabled ? 'text-white' : 'text-foreground'}`}>
              {isEnabled ? 'Your AI is Managing Your Store' : 'Enable AI Store Manager'}
            </h2>
            <p className={`text-sm mt-2 max-w-lg ${isEnabled ? 'text-brand-200' : 'text-muted-foreground'}`}>
              {isEnabled
                ? `Autopilot has made ${weekStats.total_decisions || 0} decisions this week — ${weekStats.auto_approved || 0} applied automatically, saving you hours of manual work.`
                : 'Turn on the AI to automatically optimize prices, pause bad ads, switch failing suppliers, and import trending products — all without you lifting a finger.'}
            </p>
          </div>

          <button
            onClick={() => isEnabled ? disableMutation.mutate() : enableMutation.mutate()}
            disabled={enableMutation.isPending || disableMutation.isPending}
            className={`flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-lg transition-all ${
              isEnabled
                ? 'bg-white/20 hover:bg-white/30 text-white border border-white/30'
                : 'bg-brand-500 hover:bg-brand-600 text-white shadow-lg shadow-brand-500/30'
            }`}
          >
            <Power className="w-6 h-6" />
            {enableMutation.isPending || disableMutation.isPending
              ? 'Working...'
              : isEnabled ? 'Disable Autopilot' : 'Enable Autopilot'}
          </button>
        </div>
      </motion.div>

      {/* Safety Rules Panel */}
      {showConfig && s?.config && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="stat-card border-brand-500/20 space-y-5"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-semibold flex items-center gap-2">
              <Shield className="w-4 h-4 text-brand-500" />
              Safety Rules & Limits
            </h3>
            <span className="text-xs text-muted-foreground">These protect your money from AI mistakes</span>
          </div>

          <div className="grid grid-cols-2 xl:grid-cols-3 gap-4">
            {[
              { key: 'minMarginPercent', label: 'Min Profit Margin', suffix: '%', description: 'AI never prices below this margin', min: 15, max: 80 },
              { key: 'maxDailyAdSpend', label: 'Max Daily Ad Spend', prefix: '$', description: 'Hard cap on daily advertising budget' },
              { key: 'minRoasThreshold', label: 'Pause Ads Below ROAS', suffix: 'x', description: 'Pause ads earning less than this return', step: 0.1 },
              { key: 'autoImportThreshold', label: 'Auto-Import Score Threshold', suffix: '/100', description: 'Import products scoring above this' },
              { key: 'maxPriceIncreasePercent', label: 'Max Price Increase/Cycle', suffix: '%', description: 'Limit price jumps per 4-hour cycle', max: 50 },
              { key: 'minSupplierReliability', label: 'Min Supplier Reliability', suffix: '%', description: 'Switch supplier below this score' },
            ].map((field) => {
              const value = (configDraft || s.config)[field.key];
              const displayValue = field.key === 'minSupplierReliability'
                ? (parseFloat(value) * 100).toFixed(0)
                : value;

              return (
                <div key={field.key}>
                  <label className="block text-xs font-medium mb-1">{field.label}</label>
                  <div className="relative flex items-center">
                    {field.prefix && <span className="absolute left-3 text-muted-foreground text-sm">{field.prefix}</span>}
                    <input
                      type="number"
                      value={displayValue}
                      step={field.step || 1}
                      min={field.min || 0}
                      max={field.max || 100}
                      onChange={(e) => {
                        const val = field.key === 'minSupplierReliability'
                          ? parseFloat(e.target.value) / 100
                          : parseFloat(e.target.value);
                        setConfigDraft((prev: any) => ({
                          ...(prev || s.config),
                          [field.key]: val,
                        }));
                      }}
                      className={`w-full py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 ${field.prefix ? 'pl-7 pr-10' : 'px-3 pr-10'}`}
                    />
                    {field.suffix && (
                      <span className="absolute right-3 text-muted-foreground text-sm">{field.suffix}</span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{field.description}</p>
                </div>
              );
            })}
          </div>

          <div className="flex gap-2 pt-2 border-t border-border">
            <button
              onClick={() => updateConfigMutation.mutate(configDraft || s.config)}
              disabled={updateConfigMutation.isPending}
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors"
            >
              {updateConfigMutation.isPending ? 'Saving...' : 'Save Rules'}
            </button>
            <button
              onClick={() => { setShowConfig(false); setConfigDraft(null); }}
              className="px-4 py-2 border border-border text-sm rounded-lg hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      )}

      {/* Weekly Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: 'Decisions This Week', value: weekStats.total_decisions || 0, icon: Bot, color: 'text-brand-500', bg: 'bg-brand-500/10' },
          { label: 'Auto-Applied', value: weekStats.auto_approved || 0, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
          { label: 'Pending Approval', value: weekStats.pending_approval || 0, icon: Clock, color: 'text-amber-500', bg: 'bg-amber-500/10' },
          { label: 'Avg Confidence', value: `${((parseFloat(weekStats.avg_confidence || 0)) * 100).toFixed(0)}%`, icon: Shield, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="stat-card flex items-center gap-4">
              <div className={`p-2.5 rounded-xl ${s.bg}`}><Icon className={`w-5 h-5 ${s.color}`} /></div>
              <div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Decision Log */}
      <div className="stat-card">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-semibold text-sm">AI Decision Log</h3>
          <span className="text-xs text-muted-foreground">Every action the AI has taken</span>
        </div>
        <div className="space-y-2 max-h-[400px] overflow-y-auto scrollbar-thin pr-1">
          {(decisions.length ? decisions : MOCK_DECISIONS).map((d: any, i: number) => {
            const Icon = ACTION_ICONS[d.action] || Zap;
            const colors = ACTION_COLORS[d.action] || 'text-brand-500 bg-brand-500/10';
            return (
              <motion.div
                key={d.id || i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className={`flex items-start gap-3 p-3 rounded-lg border ${
                  d.requiresApproval && !d.approved
                    ? 'border-amber-500/30 bg-amber-500/5'
                    : 'border-border bg-muted/20'
                }`}
              >
                <div className={`p-1.5 rounded-lg flex-shrink-0 ${colors}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-semibold capitalize">
                      {d.action?.replace(/_/g, ' ').toLowerCase()}
                    </p>
                    <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                      d.approved
                        ? 'bg-emerald-500/10 text-emerald-600'
                        : 'bg-amber-500/10 text-amber-600'
                    }`}>
                      {d.approved ? 'Applied' : 'Pending'}
                    </span>
                    <span className="text-xs text-muted-foreground ml-auto">
                      {d.confidence ? `${(d.confidence * 100).toFixed(0)}% confident` : ''}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{d.reasoning}</p>
                  {d.requiresApproval && !d.approved && (
                    <button
                      onClick={() => api.post(`/autopilot/decisions/${d.id}/approve`).then(() => qc.invalidateQueries({ queryKey: ['autopilot-decisions'] }))}
                      className="mt-2 px-3 py-1 text-xs bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
                    >
                      Approve This Action
                    </button>
                  )}
                </div>
                <span className="text-xs text-muted-foreground flex-shrink-0 self-center">
                  {d.createdAt ? formatRelativeTime(d.createdAt) : '2h ago'}
                </span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

const MOCK_DECISIONS = [
  { id: '1', action: 'PRICE_UPDATE', reasoning: 'Competitor prices are 12% higher on Amazon. Raised price from $24.99 to $27.49 to capture additional margin. Expected revenue increase: +$120/week.', confidence: 0.88, approved: true, requiresApproval: false, createdAt: new Date(Date.now() - 900000) },
  { id: '2', action: 'PAUSE_AD', reasoning: 'Facebook ad "Wireless Earbuds Pro" has ROAS 1.1x after 5,000 impressions — below break-even threshold of 1.6x. Pausing to prevent further losses.', confidence: 0.95, approved: true, requiresApproval: false, createdAt: new Date(Date.now() - 1800000) },
  { id: '3', action: 'AUTO_IMPORT', reasoning: 'Portable LED Strip Lights scored 84/100 viral score. TikTok hashtag views up 340% in 72 hours. Auto-importing for immediate listing.', confidence: 0.82, approved: true, requiresApproval: false, createdAt: new Date(Date.now() - 3600000) },
  { id: '4', action: 'SUPPLIER_FAILOVER', reasoning: 'Primary AliExpress supplier reliability dropped to 82% (3 failed deliveries this week). Switching 47 products to backup Shopify warehouse supplier.', confidence: 0.91, approved: false, requiresApproval: true, createdAt: new Date(Date.now() - 7200000) },
  { id: '5', action: 'PRICE_UPDATE', reasoning: 'Demand signal for "Smart Watch" trending +28% on Google. Raised price 8% to $54.99 — still 5% below competitor average while capturing trend premium.', confidence: 0.79, approved: true, requiresApproval: false, createdAt: new Date(Date.now() - 10800000) },
];
