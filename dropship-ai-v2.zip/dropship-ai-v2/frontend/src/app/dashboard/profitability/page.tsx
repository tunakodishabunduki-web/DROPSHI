'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import {
  DollarSign, TrendingUp, TrendingDown, ShoppingCart,
  Download, AlertTriangle, CheckCircle, Package, Truck,
  CreditCard, BarChart2, Users, Star,
} from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatCurrency, formatNumber } from '@/lib/utils';

const PERIODS = ['7d', '30d', '90d'] as const;
const PIE_COLORS = ['#4f63ff', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6'];

const COST_LABELS: Record<string, string> = {
  supplierCost: 'Supplier Cost',
  shippingCost: 'Shipping',
  paymentFees: 'Payment Fees',
  adSpend: 'Ad Spend',
  refunds: 'Refunds',
};

export default function ProfitabilityPage() {
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('30d');
  const [activeTab, setActiveTab] = useState<'products' | 'suppliers' | 'campaigns' | 'customers'>('products');

  const { data: overviewData, isLoading } = useQuery({
    queryKey: ['profitability-overview', period],
    queryFn: () => api.get(`/profitability/overview?period=${period}`),
    refetchInterval: 300_000,
  });

  const { data: productsData } = useQuery({
    queryKey: ['profitability-products'],
    queryFn: () => api.get('/profitability/products'),
  });

  const { data: suppliersData } = useQuery({
    queryKey: ['profitability-suppliers'],
    queryFn: () => api.get('/profitability/suppliers'),
  });

  const { data: campaignsData } = useQuery({
    queryKey: ['profitability-campaigns'],
    queryFn: () => api.get('/profitability/campaigns'),
  });

  const { data: customerData } = useQuery({
    queryKey: ['profitability-customers'],
    queryFn: () => api.get('/profitability/customers'),
  });

  const overview: any = (overviewData as any)?.data || MOCK_OVERVIEW;
  const products: any[] = (productsData as any)?.data || MOCK_PRODUCTS;
  const suppliers: any[] = (suppliersData as any)?.data || MOCK_SUPPLIERS;
  const campaigns: any[] = (campaignsData as any)?.data || MOCK_CAMPAIGNS;
  const customers: any[] = (customerData as any)?.data || MOCK_CUSTOMERS;

  const costPieData = overview.costs
    ? Object.entries(overview.costs)
        .filter(([k]) => k !== 'total')
        .map(([key, val]) => ({
          name: COST_LABELS[key] || key,
          value: parseFloat(val as string) || 0,
        }))
        .filter((d) => d.value > 0)
    : [];

  const healthColor = overview.healthStatus === 'excellent' ? 'text-emerald-500'
    : overview.healthStatus === 'good' ? 'text-blue-500'
    : overview.healthStatus === 'fair' ? 'text-amber-500'
    : 'text-red-500';

  const handleExport = () => {
    api.get(`/profitability/report?period=${period}`, { responseType: 'blob' } as any)
      .then((blob: any) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `profitability-${period}.csv`;
        a.click();
      });
  };

  return (
    <div className="space-y-6 max-w-[1400px]">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Profitability Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            True profit after supplier costs, shipping, payment fees, ads, and refunds
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-muted rounded-lg p-1 gap-0.5">
            {PERIODS.map((p) => (
              <button key={p} onClick={() => setPeriod(p)}
                className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${period === p ? 'bg-card shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                {p}
              </button>
            ))}
          </div>
          <button onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-2 border border-border rounded-lg text-sm hover:bg-muted transition-colors">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
        </div>
      </div>

      {/* Health Banner */}
      <div className={`rounded-xl p-4 border flex items-center gap-4 ${
        overview.healthStatus === 'excellent' ? 'bg-emerald-500/5 border-emerald-500/20' :
        overview.healthStatus === 'good' ? 'bg-blue-500/5 border-blue-500/20' :
        overview.healthStatus === 'fair' ? 'bg-amber-500/5 border-amber-500/20' :
        'bg-red-500/5 border-red-500/20'
      }`}>
        {overview.healthStatus === 'excellent' || overview.healthStatus === 'good'
          ? <CheckCircle className={`w-5 h-5 ${healthColor} flex-shrink-0`} />
          : <AlertTriangle className={`w-5 h-5 ${healthColor} flex-shrink-0`} />}
        <div>
          <p className={`text-sm font-semibold ${healthColor}`}>
            Store Health: {(overview.healthStatus || 'unknown').toUpperCase()}
          </p>
          <p className="text-xs text-muted-foreground">
            {overview.healthStatus === 'excellent'
              ? `Outstanding! Your ${overview.trueMarginPercent}% true margin is well above the 30% target. Keep scaling.`
              : overview.healthStatus === 'good'
              ? `Good performance. ${overview.trueMarginPercent}% margin. Look for ways to reduce ad spend or increase prices.`
              : overview.healthStatus === 'fair'
              ? `Margin at ${overview.trueMarginPercent}% is below target. Review ad ROAS and consider price increases.`
              : `Critical: ${overview.trueMarginPercent}% margin means you're barely breaking even after all costs. Action required.`}
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          {
            label: 'Total Revenue',
            value: formatCurrency(overview.revenue || 0),
            sub: `${overview.orderCount || 0} orders`,
            icon: DollarSign,
            color: 'text-brand-500',
            bg: 'bg-brand-500/10',
          },
          {
            label: 'TRUE Profit',
            value: formatCurrency(overview.trueProfit || 0),
            sub: 'After ALL costs',
            icon: overview.trueProfit >= 0 ? TrendingUp : TrendingDown,
            color: overview.trueProfit >= 0 ? 'text-emerald-500' : 'text-red-500',
            bg: overview.trueProfit >= 0 ? 'bg-emerald-500/10' : 'bg-red-500/10',
            highlight: true,
          },
          {
            label: 'True Margin',
            value: `${overview.trueMarginPercent || 0}%`,
            sub: overview.healthStatus || 'calculating...',
            icon: BarChart2,
            color: healthColor,
            bg: 'bg-muted',
          },
          {
            label: 'Avg Profit/Order',
            value: formatCurrency(overview.avgOrderProfit || 0),
            sub: 'True per-order profit',
            icon: ShoppingCart,
            color: 'text-purple-500',
            bg: 'bg-purple-500/10',
          },
        ].map((k, i) => {
          const Icon = k.icon;
          return (
            <motion.div
              key={k.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }}
              className={`stat-card ${k.highlight ? 'ring-2 ring-emerald-500/30' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium text-muted-foreground">{k.label}</p>
                  {isLoading
                    ? <div className="skeleton h-8 w-24 rounded mt-1" />
                    : <p className={`text-2xl font-bold mt-1 tracking-tight ${k.highlight ? k.color : ''}`}>{k.value}</p>}
                </div>
                <div className={`p-2 rounded-lg ${k.bg}`}>
                  <Icon className={`w-4 h-4 ${k.color}`} />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">{k.sub}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Cost Breakdown + Revenue Chart */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Revenue vs Profit chart */}
        <div className="xl:col-span-2 stat-card">
          <h3 className="font-semibold text-sm mb-5">Revenue vs True Profit Breakdown</h3>
          <div className="flex items-center gap-6 mb-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-brand-500" />
              <span className="text-muted-foreground">Revenue: <strong>{formatCurrency(overview.revenue || 0)}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-muted-foreground">True Profit: <strong className="text-emerald-500">{formatCurrency(overview.trueProfit || 0)}</strong></span>
            </div>
          </div>
          {/* Waterfall-style cost breakdown */}
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground w-28 text-right">Revenue</span>
              <div className="flex-1 bg-brand-500 h-7 rounded-r-lg flex items-center px-3">
                <span className="text-xs text-white font-semibold">{formatCurrency(overview.revenue || 0)}</span>
              </div>
            </div>
            {overview.costs && Object.entries(overview.costs)
              .filter(([k]) => k !== 'total')
              .map(([key, val]: [string, any]) => {
                const amount = parseFloat(val) || 0;
                if (amount === 0) return null;
                const pct = overview.revenue > 0 ? (amount / overview.revenue) * 100 : 0;
                return (
                  <div key={key} className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground w-28 text-right">- {COST_LABELS[key] || key}</span>
                    <div className="flex-1 relative h-7 bg-muted rounded-r-lg overflow-hidden">
                      <div className="absolute inset-y-0 left-0 bg-red-400/40" style={{ width: `${Math.min(pct, 100)}%` }} />
                      <span className="absolute inset-0 flex items-center px-3 text-xs font-medium">{formatCurrency(amount)}</span>
                    </div>
                  </div>
                );
              })}
            <div className="border-t border-border pt-2 flex items-center gap-3">
              <span className="text-xs font-bold w-28 text-right text-emerald-600">= True Profit</span>
              <div className="flex-1 bg-emerald-500 h-7 rounded-r-lg flex items-center px-3">
                <span className="text-xs text-white font-bold">{formatCurrency(overview.trueProfit || 0)} ({overview.trueMarginPercent || 0}% margin)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Cost Pie */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4">Cost Distribution</h3>
          {costPieData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={costPieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                    {costPieData.map((_, idx) => <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v: any) => [formatCurrency(v), '']} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {costPieData.map((d, idx) => (
                  <div key={d.name} className="flex items-center gap-2 text-xs">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: PIE_COLORS[idx % PIE_COLORS.length] }} />
                    <span className="text-muted-foreground flex-1">{d.name}</span>
                    <span className="font-semibold">{formatCurrency(d.value)}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-40 text-sm text-muted-foreground">No cost data yet</div>
          )}
        </div>
      </div>

      {/* Tabbed Detail Sections */}
      <div className="stat-card !p-0 overflow-hidden">
        <div className="flex border-b border-border overflow-x-auto">
          {[
            { id: 'products', label: 'Products', icon: Package },
            { id: 'suppliers', label: 'Suppliers', icon: Truck },
            { id: 'campaigns', label: 'Ad Campaigns', icon: BarChart2 },
            { id: 'customers', label: 'Customer LTV', icon: Users },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-5 py-3.5 text-sm font-medium border-b-2 transition-colors flex-shrink-0 ${
                  activeTab === tab.id ? 'border-brand-500 text-brand-500' : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}>
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="overflow-x-auto">
          {activeTab === 'products' && (
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  <th className="px-5 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">Product</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">Units Sold</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">Revenue</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">Supplier Cost</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">True Profit</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">Margin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {products.map((p: any, i: number) => {
                  const margin = parseFloat(p.gross_margin || p.margin || 0);
                  return (
                    <tr key={p.id || i} className="hover:bg-muted/20 transition-colors">
                      <td className="px-5 py-3">
                        <p className="font-medium text-xs">{p.name}</p>
                      </td>
                      <td className="px-4 py-3 text-right text-xs">{p.units_sold || 0}</td>
                      <td className="px-4 py-3 text-right text-xs font-semibold">{formatCurrency(p.gross_revenue || p.revenue || 0)}</td>
                      <td className="px-4 py-3 text-right text-xs text-muted-foreground">{formatCurrency(p.supplier_cost || p.cost || 0)}</td>
                      <td className="px-4 py-3 text-right text-xs font-bold text-emerald-500">{formatCurrency(p.estimated_true_profit || p.profit || 0)}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={`text-xs font-bold ${margin >= 30 ? 'text-emerald-500' : margin >= 20 ? 'text-amber-500' : 'text-red-500'}`}>
                          {margin.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {activeTab === 'suppliers' && (
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {['Supplier', 'Orders', 'Revenue', 'Cost', 'Profit', 'Margin', 'Reliability'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {suppliers.map((s: any, i: number) => (
                  <tr key={s.id || i} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 font-medium text-xs">{s.name}</td>
                    <td className="px-4 py-3 text-xs">{s.total_orders || 0}</td>
                    <td className="px-4 py-3 text-xs font-semibold">{formatCurrency(s.total_revenue || 0)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{formatCurrency(s.total_cost || 0)}</td>
                    <td className="px-4 py-3 text-xs font-bold text-emerald-500">{formatCurrency(s.gross_profit || 0)}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-bold ${parseFloat(s.margin || 0) >= 30 ? 'text-emerald-500' : 'text-amber-500'}`}>
                        {parseFloat(s.margin || 0).toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <div className="w-16 bg-muted rounded-full h-1.5">
                          <div className="h-full rounded-full bg-brand-500" style={{ width: `${(s.reliability_score || 0) * 100}%` }} />
                        </div>
                        <span className="text-xs">{((s.reliability_score || 0) * 100).toFixed(0)}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'campaigns' && (
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {['Campaign', 'Platforms', 'Ad Spend', 'Revenue', 'Profit', 'ROAS'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {campaigns.map((c: any, i: number) => {
                  const roas = parseFloat(c.roas || 0);
                  return (
                    <tr key={c.id || i} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 font-medium text-xs max-w-[200px] truncate">{c.name}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground capitalize">
                        {(c.platforms || []).join(', ')}
                      </td>
                      <td className="px-4 py-3 text-xs text-red-500">{formatCurrency(c.ad_spend || 0)}</td>
                      <td className="px-4 py-3 text-xs font-semibold">{formatCurrency(c.attributed_revenue || 0)}</td>
                      <td className="px-4 py-3 text-xs font-bold" style={{ color: (c.profit || 0) >= 0 ? '#10b981' : '#ef4444' }}>
                        {formatCurrency(c.profit || 0)}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${roas >= 2.5 ? 'bg-emerald-500/10 text-emerald-500' : roas >= 1.6 ? 'bg-amber-500/10 text-amber-500' : 'bg-red-500/10 text-red-500'}`}>
                          {roas.toFixed(2)}x
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {activeTab === 'customers' && (
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {['Customer', 'Orders', 'Total Spent', 'Avg Order', 'Pred. Annual LTV', 'Segment'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {customers.map((c: any, i: number) => {
                  const segmentColors: Record<string, string> = {
                    champion: 'bg-brand-500/10 text-brand-500',
                    loyal: 'bg-emerald-500/10 text-emerald-500',
                    repeat: 'bg-blue-500/10 text-blue-500',
                    at_risk: 'bg-amber-500/10 text-amber-500',
                    new: 'bg-muted text-muted-foreground',
                  };
                  return (
                    <tr key={c.id || i} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3">
                        <p className="font-medium text-xs">{c.first_name} {c.last_name}</p>
                        <p className="text-xs text-muted-foreground">{c.email}</p>
                      </td>
                      <td className="px-4 py-3 text-xs font-semibold">{c.order_count || 0}</td>
                      <td className="px-4 py-3 text-xs font-semibold">{formatCurrency(c.total_revenue || c.total_spent || 0)}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatCurrency(c.avg_order || c.avg_order_value || 0)}</td>
                      <td className="px-4 py-3 text-xs font-bold text-emerald-500">{formatCurrency(c.predicted_annual_ltv || 0)}</td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${segmentColors[c.segment] || 'bg-muted text-muted-foreground'}`}>
                          {c.segment || 'new'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

const MOCK_OVERVIEW = {
  period: '30d', revenue: 18450, trueProfit: 6230, trueMarginPercent: 33.8,
  orderCount: 142, avgOrderProfit: 43.87, healthStatus: 'good',
  costs: { supplierCost: 7200, shippingCost: 1820, paymentFees: 540, adSpend: 2100, refunds: 560 },
};
const MOCK_PRODUCTS = [
  { name: 'Wireless Earbuds Pro', units_sold: 84, gross_revenue: 4199, supplier_cost: 1050, estimated_true_profit: 1820, gross_margin: 43.3 },
  { name: 'LED Strip Lights 5m', units_sold: 96, gross_revenue: 2399, supplier_cost: 499, estimated_true_profit: 1240, gross_margin: 51.7 },
  { name: 'Smart Watch Fitness', units_sold: 31, gross_revenue: 2479, supplier_cost: 558, estimated_true_profit: 980, gross_margin: 39.5 },
  { name: 'Portable Blender USB', units_sold: 47, gross_revenue: 1645, supplier_cost: 418, estimated_true_profit: 720, gross_margin: 43.8 },
];
const MOCK_SUPPLIERS = [
  { name: 'AliExpress Main', total_orders: 124, total_revenue: 12450, total_cost: 4980, gross_profit: 7470, margin: 60.0, reliability_score: 0.92 },
  { name: 'Shopify Warehouse', total_orders: 18, total_revenue: 6000, total_cost: 3120, gross_profit: 2880, margin: 48.0, reliability_score: 0.97 },
];
const MOCK_CAMPAIGNS = [
  { name: 'Earbuds — TikTok Push', platforms: ['tiktok'], ad_spend: 420, attributed_revenue: 1680, profit: 920, roas: 4.0 },
  { name: 'LED — Instagram Reels', platforms: ['instagram'], ad_spend: 280, attributed_revenue: 700, profit: 210, roas: 2.5 },
  { name: 'Watch — Facebook Broad', platforms: ['facebook'], ad_spend: 380, attributed_revenue: 570, profit: -32, roas: 1.5 },
];
const MOCK_CUSTOMERS = [
  { first_name: 'James', last_name: 'Lee', email: 'james@example.com', order_count: 24, total_revenue: 3600, avg_order: 150, predicted_annual_ltv: 4320, segment: 'champion' },
  { first_name: 'Sarah', last_name: 'Johnson', email: 'sarah@example.com', order_count: 12, total_revenue: 1840, avg_order: 153, predicted_annual_ltv: 2200, segment: 'loyal' },
  { first_name: 'Marcus', last_name: 'Williams', email: 'marcus@example.com', order_count: 7, total_revenue: 920, avg_order: 131, predicted_annual_ltv: 1320, segment: 'repeat' },
];
