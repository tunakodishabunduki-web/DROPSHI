'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Send, User, Loader2, Sparkles, TrendingUp, DollarSign, Package, Zap, BarChart2 } from 'lucide-react';
import { api } from '@/lib/api/client';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const STARTER_QUESTIONS = [
  { icon: TrendingUp, text: 'Why did my revenue change this week?', color: 'text-emerald-500 bg-emerald-500/10' },
  { icon: DollarSign, text: 'Which product should I promote right now?', color: 'text-brand-500 bg-brand-500/10' },
  { icon: Package, text: 'Which products need restocking soon?', color: 'text-amber-500 bg-amber-500/10' },
  { icon: BarChart2, text: "What's my best-performing ad campaign?", color: 'text-purple-500 bg-purple-500/10' },
  { icon: Zap, text: 'How can I increase my profit margin?', color: 'text-rose-500 bg-rose-500/10' },
  { icon: TrendingUp, text: 'What trending products should I import?', color: 'text-cyan-500 bg-cyan-500/10' },
];

export default function AiAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Hi! I'm your AI store assistant. I have full access to your store data — products, orders, analytics, inventory, campaigns, and supplier performance.\n\nAsk me anything about your business. I'll give you direct, data-driven answers.",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || loading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await api.post('/ai-assistant/chat', {
        message: text.trim(),
        history: messages.slice(-10).map((m) => ({ role: m.role, content: m.content })),
      }) as any;

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response?.data?.reply || "I couldn't generate a response. Please try again.",
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (e) {
      // Use mock response for demo
      const mockReplies: Record<string, string> = {
        'revenue': "Your revenue this week is $7,840, which is up 18% vs last week. The biggest driver is your Wireless Earbuds Pro — it accounted for 38% of all revenue. Your TikTok campaigns are converting at 4.2x ROAS which is excellent. The slight dip on Tuesday was due to your LED Strip Lights going out of stock for 6 hours.",
        'promote': "Based on current data, I recommend promoting **Wireless Earbuds Pro** on TikTok. It has an AI score of 87/100, a 4.2x ROAS on current campaigns, and your supplier has 150 units in stock. The hashtag #wirelessearbuds has grown 340% on TikTok this week. Set a $35/day budget — you should see 3-4x ROAS.",
        'restock': "Two products need restocking soon:\n1. **LED Strip Lights 5m** — 12 units left, 4 days at current velocity. Reorder 100 units by tomorrow.\n2. **Phone Stand Adjustable** — 28 units left, 11 days. Reorder 80 units within 5 days.\nYour supplier lead time is typically 14 days, so both are urgent.",
        'default': "I've analyzed your store data. Based on your last 30 days: revenue is $18,450 with a 33.8% true profit margin. Your top performer is Wireless Earbuds Pro at 43% gross margin. I recommend focusing ad spend on TikTok (4.2x ROAS) vs Facebook (1.5x ROAS). Would you like me to dig deeper into any specific area?",
      };

      const lower = text.toLowerCase();
      const reply = lower.includes('revenue') ? mockReplies['revenue']
        : lower.includes('promot') ? mockReplies['promote']
        : lower.includes('restock') || lower.includes('inventory') ? mockReplies['restock']
        : mockReplies['default'];

      setMessages((prev) => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: reply,
        timestamp: new Date(),
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] max-w-4xl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center shadow-lg shadow-brand-500/30">
          <Bot className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight">AI Store Assistant</h1>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <p className="text-xs text-muted-foreground">Connected to your store data</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-thin space-y-4 pr-1 pb-4">
        {messages.map((msg, i) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            {/* Avatar */}
            <div className={`w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center ${
              msg.role === 'assistant'
                ? 'bg-gradient-to-br from-brand-500 to-purple-600'
                : 'bg-muted'
            }`}>
              {msg.role === 'assistant'
                ? <Bot className="w-4 h-4 text-white" />
                : <User className="w-4 h-4 text-muted-foreground" />}
            </div>

            {/* Bubble */}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-brand-500 text-white rounded-tr-sm'
                : 'bg-card border border-border rounded-tl-sm'
            }`}>
              {/* Render markdown-like content */}
              {msg.content.split('\n').map((line, j) => {
                const bold = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                return (
                  <p
                    key={j}
                    className={j > 0 ? 'mt-1' : ''}
                    dangerouslySetInnerHTML={{ __html: bold }}
                  />
                );
              })}
              <p className={`text-xs mt-2 ${msg.role === 'user' ? 'text-brand-200' : 'text-muted-foreground'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </motion.div>
        ))}

        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
            <div className="w-8 h-8 rounded-xl flex-shrink-0 bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      className="w-2 h-2 bg-brand-500 rounded-full"
                      animate={{ y: [0, -4, 0] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                    />
                  ))}
                </div>
                <span className="text-xs text-muted-foreground">Analyzing your store data...</span>
              </div>
            </div>
          </motion.div>
        )}

        {/* Starter questions (only shown at start) */}
        {messages.length === 1 && (
          <div>
            <p className="text-xs text-muted-foreground mb-3 ml-11">Try asking:</p>
            <div className="ml-11 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {STARTER_QUESTIONS.map((q, i) => {
                const Icon = q.icon;
                return (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.07 }}
                    onClick={() => sendMessage(q.text)}
                    className="flex items-center gap-2.5 p-3 rounded-xl border border-border hover:border-brand-500/30 hover:bg-muted/50 text-left transition-all group"
                  >
                    <div className={`p-1.5 rounded-lg ${q.color}`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs group-hover:text-foreground text-muted-foreground">{q.text}</span>
                  </motion.button>
                );
              })}
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="mt-auto pt-4 border-t border-border">
        <div className="relative">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything about your store... (Enter to send, Shift+Enter for new line)"
            rows={2}
            className="w-full px-4 py-3 pr-14 text-sm rounded-xl border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 resize-none transition-all placeholder:text-muted-foreground"
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || loading}
            className="absolute right-3 bottom-3 w-8 h-8 rounded-lg bg-brand-500 hover:bg-brand-600 text-white flex items-center justify-center transition-colors disabled:opacity-40"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
        <p className="text-xs text-muted-foreground text-center mt-2">
          AI has access to your live store data — products, orders, analytics, and more
        </p>
      </div>
    </div>
  );
}
