'use client';
// ─── Viral Products Page ────────────────────────────────────────────────────
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { TrendingUp, Zap, Plus, RefreshCw, Flame, Eye, ShoppingBag, BarChart2 } from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatCurrency } from '@/lib/utils';

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 75 ? 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20'
    : score >= 55 ? 'text-amber-500 bg-amber-500/10 border-amber-500/20'
    : 'text-muted-foreground bg-muted border-border';
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-bold ${color}`}>
      <Flame className="w-3 h-3" />
      {score}
    </span>
  );
}

export default function ViralProductsPage() {
  const qc = useQueryClient();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['viral-products'],
    queryFn: () => api.get('/viral/scores?limit=30'),
    refetchInterval: 300_000,
  });

  const { data: historyData } = useQuery({
    queryKey: ['viral-history'],
    queryFn: () => api.get('/viral/history?days=7'),
  });

  const importMutation = useMutation({
    mutationFn: (keyword: string) => api.post('/autopilot/auto-import', { keyword }),
  });

  const products: any[] = (data as any)?.data || MOCK_VIRAL;
  const recommended = products.filter((p) => p.recommendation === 'import_now' || p.score >= 75);

  return (
    <div className="space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Viral Product Detector</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            AI identifies trending products 2–4 weeks before they peak
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => refetch()} className="flex items-center gap-1.5 px-3 py-2 border border-border rounded-lg text-sm hover:bg-muted transition-colors">
            <RefreshCw className="w-3.5 h-3.5" /> Refresh Signals
          </button>
        </div>
      </div>

      {/* Hot Right Now Banner */}
      {recommended.length > 0 && (
        <div className="rounded-xl p-4 bg-gradient-to-r from-orange-500/10 to-rose-500/10 border border-orange-500/20">
          <div className="flex items-center gap-2 mb-2">
            <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
            <span className="text-sm font-semibold text-orange-600 dark:text-orange-400">
              {recommended.length} products ready to import — trending now
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            These products show strong viral signals across TikTok, Google Trends, and social media. Import them before competitors do.
          </p>
        </div>
      )}

      {/* Product Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {isLoading
          ? Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="stat-card space-y-3">
              <div className="skeleton h-5 w-32 rounded" />
              <div className="skeleton h-4 rounded" />
              <div className="grid grid-cols-4 gap-2">
                {[1,2,3,4].map(j => <div key={j} className="skeleton h-8 rounded" />)}
              </div>
            </div>
          ))
          : products.map((p: any, i: number) => (
            <motion.div
              key={p.keyword || i}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className={`stat-card relative overflow-hidden ${p.score >= 75 ? 'border-orange-500/20' : ''}`}
            >
              {p.score >= 75 && (
                <div className="absolute top-0 right-0 w-16 h-16 bg-orange-500/10 rounded-bl-3xl" />
              )}
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{p.keyword}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 capitalize">{p.platform || 'Multiple'}</p>
                </div>
                <ScoreBadge score={p.score || p.overallScore || 50} />
              </div>

              {/* Score breakdown */}
              <div className="grid grid-cols-4 gap-2 mb-4">
                {[
                  { label: 'TikTok', value: p.tiktokScore || p.score },
                  { label: 'Google', value: p.googleTrendsScore || Math.floor((p.score || 50) * 0.9) },
                  { label: 'Impulse', value: p.impulseScore || Math.floor((p.score || 50) * 1.1) },
                  { label: 'Proof', value: p.socialProofScore || Math.floor((p.score || 50) * 0.95) },
                ].map((metric) => {
                  const val = Math.min(metric.value, 100);
                  const color = val >= 75 ? '#10b981' : val >= 55 ? '#f59e0b' : '#94a3b8';
                  return (
                    <div key={metric.label} className="text-center">
                      <div className="relative w-full bg-muted rounded-full h-1.5 mb-1">
                        <div className="h-full rounded-full" style={{ width: `${val}%`, backgroundColor: color }} />
                      </div>
                      <p className="text-xs text-muted-foreground">{metric.label}</p>
                      <p className="text-xs font-bold">{val}</p>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">
                  Peak in ~{p.predictedPeakDays || '14'} days
                  {p.estimatedRevenue ? ` · est. $${p.estimatedRevenue}/mo` : ''}
                </div>
                <button
                  onClick={() => importMutation.mutate(p.keyword)}
                  disabled={importMutation.isPending}
                  className={`flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    p.score >= 75
                      ? 'bg-orange-500 hover:bg-orange-600 text-white'
                      : 'bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Plus className="w-3 h-3" />
                  {p.score >= 75 ? 'Import Now' : 'Watch'}
                </button>
              </div>
            </motion.div>
          ))}
      </div>
    </div>
  );
}

const MOCK_VIRAL = [
  { keyword: 'LED Desk Lamp USB', score: 94, platform: 'TikTok', tiktokScore: 96, googleTrendsScore: 88, impulseScore: 91, socialProofScore: 85, predictedPeakDays: 8, estimatedRevenue: 2400, recommendation: 'import_now' },
  { keyword: 'Magnetic Phone Holder', score: 89, platform: 'Instagram', tiktokScore: 85, googleTrendsScore: 82, impulseScore: 94, socialProofScore: 88, predictedPeakDays: 12, estimatedRevenue: 1800, recommendation: 'import_now' },
  { keyword: 'Portable Neck Massager', score: 85, platform: 'TikTok', tiktokScore: 92, googleTrendsScore: 76, impulseScore: 82, socialProofScore: 80, predictedPeakDays: 10, estimatedRevenue: 3200, recommendation: 'import_now' },
  { keyword: 'Collapsible Silicone Cup', score: 72, platform: 'Instagram', tiktokScore: 70, googleTrendsScore: 74, impulseScore: 76, socialProofScore: 68, predictedPeakDays: 18, estimatedRevenue: 980 },
  { keyword: 'Smart Plant Moisture Sensor', score: 68, platform: 'Multiple', tiktokScore: 65, googleTrendsScore: 72, impulseScore: 64, socialProofScore: 70, predictedPeakDays: 21, estimatedRevenue: 740 },
  { keyword: 'Car Air Freshener Vent', score: 62, platform: 'Facebook', tiktokScore: 58, googleTrendsScore: 68, impulseScore: 65, socialProofScore: 55, predictedPeakDays: 25, estimatedRevenue: 560 },
];
