'use client';

import { useQuery, useMutation } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Bot, TrendingUp, TrendingDown, AlertTriangle,
  CheckCircle, Package, Megaphone, RefreshCw,
  Zap, DollarSign, ShoppingCart, Star, Clock,
} from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatCurrency, formatNumber, formatRelativeTime } from '@/lib/utils';

export default function DailyReportPage() {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['daily-report-latest'],
    queryFn: () => api.get('/daily-report/latest'),
  });

  const { data: historyData } = useQuery({
    queryKey: ['daily-report-history'],
    queryFn: () => api.get('/daily-report/history?days=14'),
  });

  const generateMutation = useMutation({
    mutationFn: () => api.post('/daily-report/generate'),
    onSuccess: () => refetch(),
  });

  const report: any = (data as any)?.data?.data || MOCK_REPORT;
  const history: any[] = (historyData as any)?.data || [];
  const summary = report.summary || {};
  const anomalies: any[] = report.anomalies || [];
  const actions: string[] = report.actionsRequired || [];
  const inventoryAlerts: any[] = report.inventoryAlerts || [];
  const adPerf: any[] = report.adPerformance || [];

  const revenueGrowth = summary.revenue?.growthPercent || 0;
  const isPositive = revenueGrowth >= 0;

  return (
    <div className="space-y-6 max-w-[1200px]">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Daily AI Report</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            AI-generated business summary — delivered every morning at 8:00 AM
          </p>
        </div>
        <button
          onClick={() => generateMutation.mutate()}
          disabled={generateMutation.isPending}
          className="flex items-center gap-2 px-3 py-2 border border-border rounded-lg text-sm hover:bg-muted transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${generateMutation.isPending ? 'animate-spin' : ''}`} />
          Regenerate
        </button>
      </div>

      {/* AI Narrative Card */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl p-6 bg-gradient-to-br from-brand-600 to-brand-800 text-white relative overflow-hidden"
      >
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'radial-gradient(circle at 30% 50%, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold">Your AI Business Advisor</p>
              <p className="text-brand-200 text-xs">
                {report.generatedAt ? formatRelativeTime(report.generatedAt) : 'Generated today'}
              </p>
            </div>
          </div>
          {isLoading ? (
            <div className="space-y-2">
              <div className="skeleton h-4 rounded bg-white/20" />
              <div className="skeleton h-4 rounded bg-white/20 w-3/4" />
            </div>
          ) : (
            <p className="text-brand-50 leading-relaxed text-sm">
              {report.aiNarrative || 'Generating your personalized business analysis...'}
            </p>
          )}
        </div>
      </motion.div>

      {/* Revenue KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          {
            label: "Today's Revenue",
            value: formatCurrency(summary.revenue?.today || 0),
            change: revenueGrowth,
            icon: DollarSign,
            sub: `vs yesterday ${formatCurrency(summary.revenue?.yesterday || 0)}`,
          },
          {
            label: 'Orders Today',
            value: summary.orders?.today || 0,
            change: null,
            icon: ShoppingCart,
            sub: `${summary.orders?.yesterday || 0} yesterday`,
          },
          {
            label: 'This Week',
            value: formatCurrency(summary.revenue?.week || 0),
            change: null,
            icon: TrendingUp,
            sub: 'Last 7 days revenue',
          },
          {
            label: 'Profit Margin',
            value: `${summary.profit?.margin || 0}%`,
            change: null,
            icon: Star,
            sub: summary.profit?.status || 'status',
            statusColor: summary.profit?.status === 'excellent' ? 'text-emerald-500'
              : summary.profit?.status === 'good' ? 'text-blue-500'
              : summary.profit?.status === 'fair' ? 'text-amber-500'
              : 'text-red-500',
          },
        ].map((k, i) => {
          const Icon = k.icon;
          return (
            <motion.div
              key={k.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }}
              className="stat-card"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-medium">{k.label}</p>
                  <p className="text-2xl font-bold mt-1 tracking-tight">{k.value}</p>
                </div>
                <div className="p-2 rounded-lg bg-brand-500/10">
                  <Icon className="w-4 h-4 text-brand-500" />
                </div>
              </div>
              <div className="flex items-center gap-2 mt-2">
                {k.change !== null && k.change !== undefined && (
                  <span className={`flex items-center gap-0.5 text-xs font-semibold ${k.change >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                    {k.change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    {Math.abs(k.change).toFixed(1)}%
                  </span>
                )}
                <span className={`text-xs text-muted-foreground ${(k as any).statusColor || ''}`}>{k.sub}</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        {/* Action Items */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" />
            Action Required
            {actions.length > 0 && (
              <span className="ml-auto px-2 py-0.5 bg-amber-500/10 text-amber-500 text-xs rounded-full font-bold">
                {actions.length}
              </span>
            )}
          </h3>
          {actions.length === 0 && anomalies.filter((a) => a.severity === 'critical').length === 0 ? (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
              <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
              <p className="text-sm text-emerald-700 dark:text-emerald-400">All systems normal — no actions required today</p>
            </div>
          ) : (
            <div className="space-y-2">
              {[...actions, ...anomalies.filter((a) => a.severity === 'critical').map((a) => a.actionRequired)]
                .filter(Boolean)
                .map((action, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-amber-500/20 bg-amber-500/5">
                    <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                    <p className="text-xs leading-relaxed">{action}</p>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Anomalies */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-brand-500" />
            Anomaly Monitor
          </h3>
          {anomalies.length === 0 ? (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
              <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
              <p className="text-sm text-emerald-700 dark:text-emerald-400">No anomalies detected in last 24 hours</p>
            </div>
          ) : (
            <div className="space-y-2">
              {anomalies.map((a: any, i: number) => (
                <div key={i} className={`p-3 rounded-lg border text-xs ${
                  a.severity === 'critical'
                    ? 'border-red-500/20 bg-red-500/5'
                    : 'border-amber-500/20 bg-amber-500/5'
                }`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`w-2 h-2 rounded-full ${a.severity === 'critical' ? 'bg-red-500' : 'bg-amber-500'}`} />
                    <span className={`font-semibold uppercase text-xs tracking-wide ${a.severity === 'critical' ? 'text-red-500' : 'text-amber-500'}`}>
                      {a.severity}
                    </span>
                  </div>
                  <p className="font-medium">{a.message}</p>
                  <p className="text-muted-foreground mt-0.5 leading-relaxed">{a.actionRequired}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Inventory Alerts */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <Package className="w-4 h-4 text-purple-500" />
            Inventory Alerts
          </h3>
          {inventoryAlerts.length === 0 ? (
            <p className="text-sm text-muted-foreground">All products have sufficient stock</p>
          ) : (
            <div className="space-y-2">
              {inventoryAlerts.map((item: any, i: number) => (
                <div key={i} className={`flex items-center gap-3 p-2.5 rounded-lg border ${
                  item.urgent || parseInt(item.days_left || 0) <= 3
                    ? 'border-red-500/20 bg-red-500/5'
                    : 'border-amber-500/20 bg-amber-500/5'
                }`}>
                  <Package className={`w-4 h-4 flex-shrink-0 ${item.urgent ? 'text-red-500' : 'text-amber-500'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium truncate">{item.product_name}</p>
                    <p className="text-xs text-muted-foreground">{item.stock_quantity} units left</p>
                  </div>
                  <span className={`text-xs font-bold ${parseInt(item.days_left || 0) <= 3 ? 'text-red-500' : 'text-amber-500'}`}>
                    {item.days_left || '?'} days
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Ad Performance Snapshot */}
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-pink-500" />
            Ad Performance Today
          </h3>
          {adPerf.length === 0 ? (
            <p className="text-sm text-muted-foreground">No active ads in the last 24 hours</p>
          ) : (
            <div className="space-y-2">
              {adPerf.map((a: any, i: number) => {
                const roas = parseFloat(a.avg_roas || 0);
                return (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/30">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold capitalize">{a.platform}</span>
                      <span className="text-xs text-muted-foreground">{a.active_ads} ads</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs">
                      <span className="text-muted-foreground">{formatNumber(a.impressions || 0)} views</span>
                      <span className={`font-bold ${roas >= 2.5 ? 'text-emerald-500' : roas >= 1.6 ? 'text-amber-500' : 'text-red-500'}`}>
                        {roas.toFixed(1)}x ROAS
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Report History */}
      {history.length > 0 && (
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            Report History
          </h3>
          <div className="space-y-1">
            {history.slice(0, 10).map((h: any, i: number) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0 text-xs">
                <span className="text-muted-foreground">{new Date(h.report_date).toLocaleDateString()}</span>
                <span className="text-muted-foreground">{h.summary_json ? 'Report available' : 'Processing...'}</span>
                <button className="text-brand-500 hover:underline">View</button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const MOCK_REPORT = {
  generatedAt: new Date(),
  summary: {
    revenue: { today: 1240, yesterday: 980, week: 7840, growthPercent: 26.5 },
    orders: { today: 8, yesterday: 6, trend: 'up' },
    profit: { margin: 33.8, status: 'good' },
  },
  aiNarrative: "Revenue is up 26.5% today with 8 orders — a strong performance driven by your Wireless Earbuds Pro campaign on TikTok which is delivering 4.2x ROAS. Your true profit margin of 33.8% is healthy, though the Facebook Watch campaign is currently losing money at 1.5x ROAS. Recommend pausing the Facebook campaign and reallocating that $20/day budget to TikTok where you're seeing significantly better returns.",
  topProducts: [
    { name: 'Wireless Earbuds Pro', revenue: 499.9, units: 10 },
    { name: 'LED Strip Lights', revenue: 249.9, units: 10 },
  ],
  anomalies: [
    {
      type: 'ad_underperform',
      severity: 'warning',
      message: 'Facebook Watch campaign ROAS 1.5x — below break-even',
      actionRequired: 'Pause Facebook Watch campaign or adjust targeting to improve ROAS above 2.0x.',
    },
  ],
  inventoryAlerts: [
    { product_name: 'LED Strip Lights 5m', stock_quantity: 12, days_left: 4, urgent: true },
    { product_name: 'Phone Stand Adjustable', stock_quantity: 28, days_left: 11, urgent: false },
  ],
  adPerformance: [
    { platform: 'tiktok', active_ads: 2, impressions: 18400, avg_roas: 4.2 },
    { platform: 'instagram', active_ads: 1, impressions: 9200, avg_roas: 2.8 },
    { platform: 'facebook', active_ads: 1, impressions: 6100, avg_roas: 1.5 },
  ],
  actionsRequired: [],
};
