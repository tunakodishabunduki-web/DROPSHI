'use client';

import { useQuery, useMutation } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Package, AlertTriangle, Clock, TrendingUp,
  RefreshCw, ShoppingCart, BarChart2, CheckCircle,
} from 'lucide-react';
import { api } from '@/lib/api/client';

const URGENCY_CONFIG: Record<string, { color: string; bg: string; label: string }> = {
  critical: { color: 'text-red-500', bg: 'bg-red-500/10 border-red-500/20', label: 'CRITICAL' },
  high: { color: 'text-orange-500', bg: 'bg-orange-500/10 border-orange-500/20', label: 'HIGH' },
  medium: { color: 'text-amber-500', bg: 'bg-amber-500/10 border-amber-500/20', label: 'MEDIUM' },
  ok: { color: 'text-emerald-500', bg: 'bg-emerald-500/5 border-emerald-500/10', label: 'OK' },
};

export default function InventoryPage() {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['inventory-forecasts'],
    queryFn: () => api.get('/inventory/forecasts'),
    refetchInterval: 300_000,
  });

  const { data: reorderData } = useQuery({
    queryKey: ['inventory-reorders'],
    queryFn: () => api.get('/inventory/reorders'),
  });

  const runForecastMutation = useMutation({
    mutationFn: () => api.post('/inventory/run-forecast'),
    onSuccess: () => refetch(),
  });

  const forecasts: any[] = (data as any)?.data || MOCK_FORECASTS;
  const reorders: any[] = (reorderData as any)?.data || forecasts.filter((f) => f.urgency !== 'ok');

  const criticalCount = forecasts.filter((f) => f.urgency === 'critical').length;
  const highCount = forecasts.filter((f) => f.urgency === 'high').length;
  const okCount = forecasts.filter((f) => f.urgency === 'ok').length;

  return (
    <div className="space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Inventory Forecaster</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            AI predicts when stock runs out and tells you exactly when to reorder
          </p>
        </div>
        <button onClick={() => runForecastMutation.mutate()} disabled={runForecastMutation.isPending}
          className="flex items-center gap-1.5 px-3 py-2 border border-border rounded-lg text-sm hover:bg-muted transition-colors">
          <RefreshCw className={`w-3.5 h-3.5 ${runForecastMutation.isPending ? 'animate-spin' : ''}`} />
          Run Forecast
        </button>
      </div>

      {/* Alert Banner */}
      {criticalCount > 0 && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-4 rounded-xl bg-red-500/5 border border-red-500/30">
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold text-red-500">
              {criticalCount} product{criticalCount > 1 ? 's' : ''} will run out in under 3 days!
            </p>
            <p className="text-xs text-muted-foreground">Order immediately — lead time may already exceed remaining stock days</p>
          </div>
        </motion.div>
      )}

      {/* Summary Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: 'Critical', value: criticalCount, icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-500/10', desc: '< 3 days left' },
          { label: 'High Priority', value: highCount, icon: Clock, color: 'text-orange-500', bg: 'bg-orange-500/10', desc: '3-7 days left' },
          { label: 'Needs Reorder', value: reorders.length, icon: ShoppingCart, color: 'text-amber-500', bg: 'bg-amber-500/10', desc: 'Within lead time' },
          { label: 'Stocked OK', value: okCount, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-500/10', desc: 'Sufficient stock' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }} className="stat-card flex items-center gap-4">
              <div className={`p-2.5 rounded-xl ${s.bg}`}><Icon className={`w-5 h-5 ${s.color}`} /></div>
              <div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-xs text-muted-foreground">{s.desc}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Forecast Table */}
      <div className="stat-card !p-0 overflow-hidden">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-sm">Stock Forecast — All Products</h3>
          <p className="text-xs text-muted-foreground">Based on 30-day sales velocity with trend adjustment</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40 border-b border-border">
                {['Product', 'Stock', 'Daily Sales', 'Trend', 'Days Left', 'Reorder Date', 'Qty to Order', 'Status'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading
                ? Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i}>{Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="px-4 py-3"><div className="skeleton h-4 rounded" /></td>
                  ))}</tr>
                ))
                : forecasts.map((f: any, i: number) => {
                  const urgency = URGENCY_CONFIG[f.urgency] || URGENCY_CONFIG.ok;
                  const reorderDate = f.reorderDate ? new Date(f.reorderDate) : null;
                  const isOverdue = reorderDate && reorderDate < new Date();
                  return (
                    <tr key={f.productId || i} className={`hover:bg-muted/20 transition-colors ${f.urgency === 'critical' ? 'bg-red-500/3' : ''}`}>
                      <td className="px-4 py-3">
                        <p className="font-medium text-xs">{f.productName}</p>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-12 bg-muted rounded-full h-1.5">
                            <div className={`h-full rounded-full transition-all ${
                              f.daysUntilStockout <= 3 ? 'bg-red-500'
                              : f.daysUntilStockout <= 7 ? 'bg-orange-500'
                              : 'bg-emerald-500'
                            }`} style={{ width: `${Math.min((f.currentStock / Math.max(f.reorderQuantity * 2, 1)) * 100, 100)}%` }} />
                          </div>
                          <span className="text-xs font-mono">{f.currentStock}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground font-mono">
                        {f.dailyVelocity}/day
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-semibold ${f.trendMultiplier > 1.2 ? 'text-emerald-500' : f.trendMultiplier < 0.8 ? 'text-red-500' : 'text-muted-foreground'}`}>
                          {f.trendMultiplier > 1.2 ? '↑ ' : f.trendMultiplier < 0.8 ? '↓ ' : '→ '}
                          {f.trendMultiplier}x
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-bold ${
                          f.daysUntilStockout <= 3 ? 'text-red-500'
                          : f.daysUntilStockout <= 7 ? 'text-orange-500'
                          : f.daysUntilStockout <= 14 ? 'text-amber-500'
                          : 'text-emerald-500'
                        }`}>
                          {f.daysUntilStockout >= 365 ? '∞' : `${f.daysUntilStockout}d`}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs">
                        {reorderDate ? (
                          <span className={isOverdue ? 'text-red-500 font-semibold' : 'text-muted-foreground'}>
                            {isOverdue ? '⚠ ' : ''}{reorderDate.toLocaleDateString()}
                          </span>
                        ) : '—'}
                      </td>
                      <td className="px-4 py-3 text-xs font-mono font-semibold">{f.reorderQuantity}</td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-bold px-2 py-1 rounded-full border ${urgency.bg} ${urgency.color}`}>
                          {urgency.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>

      {/* How it works */}
      <div className="stat-card bg-muted/30">
        <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-brand-500" />
          How the Forecast Works
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-muted-foreground">
          <div className="space-y-1">
            <p className="font-semibold text-foreground">1. Velocity Calculation</p>
            <p>Measures units sold per day over the last 30 days, weighted toward the most recent 7 days for accuracy.</p>
          </div>
          <div className="space-y-1">
            <p className="font-semibold text-foreground">2. Trend Adjustment</p>
            <p>If recent 7-day sales accelerate vs the 30-day average, the AI adjusts the forecast upward — catching demand spikes early.</p>
          </div>
          <div className="space-y-1">
            <p className="font-semibold text-foreground">3. Lead Time Buffer</p>
            <p>Supplier lead time (usually 7-14 days) is added to the reorder calculation, plus a 3-day safety buffer.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

const MOCK_FORECASTS = [
  { productId: '1', productName: 'LED Strip Lights 5m', currentStock: 12, dailyVelocity: 3.2, trendMultiplier: 1.4, adjustedVelocity: 4.5, leadTimeDays: 17, daysUntilStockout: 2, reorderDate: new Date(Date.now() - 86400000), reorderQuantity: 135, urgency: 'critical', confidence: 0.88 },
  { productId: '2', productName: 'Wireless Earbuds Pro', currentStock: 28, dailyVelocity: 2.8, trendMultiplier: 1.2, adjustedVelocity: 3.4, leadTimeDays: 14, daysUntilStockout: 6, reorderDate: new Date(Date.now() - 2 * 86400000), reorderQuantity: 102, urgency: 'high', confidence: 0.85 },
  { productId: '3', productName: 'Phone Stand Adjustable', currentStock: 45, dailyVelocity: 1.8, trendMultiplier: 1.0, adjustedVelocity: 1.8, leadTimeDays: 14, daysUntilStockout: 11, reorderDate: new Date(Date.now() + 3 * 86400000), reorderQuantity: 54, urgency: 'medium', confidence: 0.82 },
  { productId: '4', productName: 'Smart Watch Fitness', currentStock: 75, dailyVelocity: 1.0, trendMultiplier: 0.9, adjustedVelocity: 0.9, leadTimeDays: 17, daysUntilStockout: 28, reorderDate: new Date(Date.now() + 11 * 86400000), reorderQuantity: 30, urgency: 'ok', confidence: 0.90 },
  { productId: '5', productName: 'Portable Blender USB', currentStock: 95, dailyVelocity: 1.6, trendMultiplier: 1.1, adjustedVelocity: 1.76, leadTimeDays: 14, daysUntilStockout: 38, reorderDate: new Date(Date.now() + 24 * 86400000), reorderQuantity: 53, urgency: 'ok', confidence: 0.87 },
  { productId: '6', productName: 'Yoga Mat Non-Slip', currentStock: 140, dailyVelocity: 0.8, trendMultiplier: 0.95, adjustedVelocity: 0.76, leadTimeDays: 14, daysUntilStockout: 365, reorderDate: new Date(Date.now() + 90 * 86400000), reorderQuantity: 25, urgency: 'ok', confidence: 0.75 },
];
