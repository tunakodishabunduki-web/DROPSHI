'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Music2, Instagram, Facebook, Plus, Zap,
  TrendingUp, DollarSign, Eye, MousePointer,
  Play, Pause, RefreshCw, CheckCircle, XCircle,
  AlertCircle, Loader2, ExternalLink, BarChart2, Link,
} from 'lucide-react';
import { api } from '@/lib/api/client';
import { formatCurrency, formatNumber, formatRelativeTime } from '@/lib/utils';

const PLATFORM_CONFIG = {
  tiktok: {
    name: 'TikTok',
    icon: Music2,
    color: 'text-black dark:text-white',
    bg: 'bg-black/5 dark:bg-white/10',
    border: 'border-black/20 dark:border-white/20',
    gradient: 'from-pink-500 to-cyan-400',
    description: 'Viral short-form video ads',
  },
  instagram: {
    name: 'Instagram',
    icon: Instagram,
    color: 'text-pink-500',
    bg: 'bg-pink-500/10',
    border: 'border-pink-500/20',
    gradient: 'from-purple-500 to-pink-500',
    description: 'Visual shopping & Reels',
  },
  facebook: {
    name: 'Facebook',
    icon: Facebook,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/20',
    gradient: 'from-blue-600 to-blue-400',
    description: 'Targeted audience campaigns',
  },
};

export default function SocialMediaPage() {
  const qc = useQueryClient();
  const [showCampaignForm, setShowCampaignForm] = useState(false);
  const [campaignForm, setCampaignForm] = useState({
    productId: '',
    platforms: ['tiktok'] as string[],
    dailyBudget: 20,
    durationDays: 7,
    autoPublish: false,
  });
  const [generatedCreatives, setGeneratedCreatives] = useState<any[]>([]);

  const { data: accountsData } = useQuery({
    queryKey: ['social-accounts'],
    queryFn: () => api.get('/social/accounts'),
    refetchInterval: 60_000,
  });

  const { data: campaignsData } = useQuery({
    queryKey: ['social-campaigns'],
    queryFn: () => api.get('/social/campaigns?limit=20'),
    refetchInterval: 30_000,
  });

  const { data: analyticsData } = useQuery({
    queryKey: ['social-analytics'],
    queryFn: () => api.get('/social/analytics'),
    refetchInterval: 300_000,
  });

  const createCampaignMutation = useMutation({
    mutationFn: (dto: any) => api.post('/social/campaign', dto),
    onSuccess: (res: any) => {
      qc.invalidateQueries({ queryKey: ['social-campaigns'] });
      setGeneratedCreatives((res as any)?.data?.creatives || []);
    },
  });

  const publishMutation = useMutation({
    mutationFn: (id: string) => api.post(`/social/campaign/${id}/publish`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['social-campaigns'] }),
  });

  const connectMutation = useMutation({
    mutationFn: (platform: string) => api.get(`/social/connect/${platform}`).then((res: any) => {
      window.open(res?.data?.url, '_blank');
    }),
  });

  const accounts: any = (accountsData as any)?.data || {};
  const campaigns: any[] = (campaignsData as any)?.data?.data || [];
  const analytics: any[] = (analyticsData as any)?.data || [];

  const togglePlatform = (p: string) => {
    setCampaignForm((f) => ({
      ...f,
      platforms: f.platforms.includes(p) ? f.platforms.filter((x) => x !== p) : [...f.platforms, p],
    }));
  };

  const totalAnalytics = analytics.reduce(
    (acc: any, p: any) => ({
      impressions: (acc.impressions || 0) + parseInt(p.impressions || 0),
      clicks: (acc.clicks || 0) + parseInt(p.clicks || 0),
      spent: (acc.spent || 0) + parseFloat(p.spent || 0),
    }), {},
  );

  return (
    <div className="space-y-6 max-w-[1400px]">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Social Media Hub</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            AI-powered campaigns across TikTok, Instagram & Facebook
          </p>
        </div>
        <button
          onClick={() => setShowCampaignForm(!showCampaignForm)}
          className="flex items-center gap-2 px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white rounded-lg text-sm font-medium transition-colors"
        >
          <Plus className="w-4 h-4" /> New Campaign
        </button>
      </div>

      {/* Platform Connections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(Object.entries(PLATFORM_CONFIG) as any).map(([key, platform]: [string, any]) => {
          const Icon = platform.icon;
          const account = accounts[key];
          const isConnected = account?.isActive;

          return (
            <div key={key} className={`stat-card border ${platform.border} relative overflow-hidden`}>
              <div className={`absolute inset-0 bg-gradient-to-br ${platform.gradient} opacity-5`} />
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl ${platform.bg}`}>
                      <Icon className={`w-5 h-5 ${platform.color}`} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{platform.name}</p>
                      <p className="text-xs text-muted-foreground">{platform.description}</p>
                    </div>
                  </div>
                  <div className={`flex items-center gap-1.5 ${isConnected ? 'text-emerald-500' : 'text-muted-foreground'}`}>
                    <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-muted-foreground/30'}`} />
                    <span className="text-xs font-medium">{isConnected ? 'Connected' : 'Not connected'}</span>
                  </div>
                </div>

                {isConnected ? (
                  <div className="space-y-2">
                    <p className="text-xs text-muted-foreground">
                      Connected {account.connectedAt ? formatRelativeTime(account.connectedAt) : 'recently'}
                    </p>
                    {/* Platform-specific stats */}
                    {analytics.find((a: any) => a.platform === key) && (() => {
                      const a = analytics.find((a: any) => a.platform === key);
                      return (
                        <div className="grid grid-cols-3 gap-2 pt-2">
                          {[
                            ['Impressions', formatNumber(a.impressions || 0)],
                            ['Clicks', formatNumber(a.clicks || 0)],
                            ['ROAS', `${parseFloat(a.avg_roas || 0).toFixed(1)}x`],
                          ].map(([label, val]) => (
                            <div key={label} className="text-center">
                              <p className="text-sm font-bold">{val}</p>
                              <p className="text-xs text-muted-foreground">{label}</p>
                            </div>
                          ))}
                        </div>
                      );
                    })()}
                  </div>
                ) : (
                  <button
                    onClick={() => connectMutation.mutate(key)}
                    className={`w-full mt-2 py-2 rounded-lg text-xs font-semibold transition-colors bg-gradient-to-r ${platform.gradient} text-white hover:opacity-90`}
                  >
                    Connect {platform.name}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Campaign Creation Form */}
      <AnimatePresence>
        {showCampaignForm && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="stat-card border-brand-500/20 space-y-5"
          >
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-brand-500" />
              <h3 className="font-semibold">Create AI Campaign</h3>
              <span className="text-xs text-muted-foreground ml-auto">AI writes the copy, sets the budget, and publishes automatically</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Product ID</label>
                <input
                  value={campaignForm.productId}
                  onChange={(e) => setCampaignForm((f) => ({ ...f, productId: e.target.value }))}
                  placeholder="Paste product UUID from Products page..."
                  className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Target Platforms</label>
                <div className="flex gap-2">
                  {Object.entries(PLATFORM_CONFIG).map(([key, p]) => {
                    const Icon = p.icon;
                    const connected = accounts[key]?.isActive;
                    return (
                      <button
                        key={key}
                        onClick={() => connected && togglePlatform(key)}
                        disabled={!connected}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                          campaignForm.platforms.includes(key)
                            ? `bg-gradient-to-r ${p.gradient} text-white`
                            : 'bg-muted text-muted-foreground'
                        } disabled:opacity-40 disabled:cursor-not-allowed`}
                      >
                        <Icon className="w-3.5 h-3.5" /> {p.name}
                        {!connected && ' (connect first)'}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">
                  Daily Budget: ${campaignForm.dailyBudget}
                </label>
                <input
                  type="range" min="5" max="500" step="5"
                  value={campaignForm.dailyBudget}
                  onChange={(e) => setCampaignForm((f) => ({ ...f, dailyBudget: +e.target.value }))}
                  className="w-full accent-brand-500"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>$5/day</span>
                  <span className="text-brand-500 font-medium">
                    Total: ${campaignForm.dailyBudget * campaignForm.durationDays}
                  </span>
                  <span>$500/day</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Duration</label>
                <select
                  value={campaignForm.durationDays}
                  onChange={(e) => setCampaignForm((f) => ({ ...f, durationDays: +e.target.value }))}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-brand-500/30"
                >
                  {[3, 5, 7, 14, 21, 30].map((d) => (
                    <option key={d} value={d}>{d} days</option>
                  ))}
                </select>
              </div>

              <div className="col-span-2 flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <div
                    onClick={() => setCampaignForm((f) => ({ ...f, autoPublish: !f.autoPublish }))}
                    className={`w-10 h-5 rounded-full transition-colors cursor-pointer ${campaignForm.autoPublish ? 'bg-brand-500' : 'bg-muted'}`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-white shadow-sm mt-0.5 transition-transform ${campaignForm.autoPublish ? 'translate-x-5' : 'translate-x-0.5'}`} />
                  </div>
                  <span className="text-sm font-medium">Auto-publish immediately</span>
                </label>
                <span className="text-xs text-muted-foreground">
                  {campaignForm.autoPublish ? 'Campaign will go live right after creation' : 'Review creatives before publishing'}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => createCampaignMutation.mutate(campaignForm)}
                disabled={createCampaignMutation.isPending || !campaignForm.productId || campaignForm.platforms.length === 0}
                className="flex items-center gap-2 px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-60"
              >
                {createCampaignMutation.isPending
                  ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating AI Creatives...</>
                  : <><Zap className="w-4 h-4" /> Create Campaign</>}
              </button>
              <button
                onClick={() => { setShowCampaignForm(false); setGeneratedCreatives([]); }}
                className="px-4 py-2.5 border border-border text-sm rounded-lg hover:bg-muted transition-colors"
              >
                Cancel
              </button>
            </div>

            {/* Generated Creatives Preview */}
            {generatedCreatives.length > 0 && (
              <div className="pt-4 border-t border-border">
                <p className="text-sm font-semibold mb-3">AI-Generated Creatives</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {generatedCreatives.map((c: any, i: number) => {
                    const platform = PLATFORM_CONFIG[c.platform as keyof typeof PLATFORM_CONFIG];
                    const Icon = platform?.icon || Zap;
                    return (
                      <div key={i} className={`p-3.5 rounded-xl border ${platform?.border || 'border-border'} bg-muted/30`}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-1.5">
                            <Icon className={`w-4 h-4 ${platform?.color || 'text-brand-500'}`} />
                            <span className="text-xs font-bold capitalize">{c.platform}</span>
                          </div>
                          <span className="text-xs font-semibold text-emerald-500">
                            {c.viralScore}/100 viral
                          </span>
                        </div>
                        <p className="text-sm font-semibold mb-1">{c.headline}</p>
                        <p className="text-xs text-muted-foreground line-clamp-3">{c.script}</p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {(c.hashtags || []).slice(0, 3).map((h: string) => (
                            <span key={h} className="text-xs text-brand-500">#{h}</span>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1.5">Best: {c.bestPostTime}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Platform Performance Summary */}
      {analytics.length > 0 && (
        <div className="stat-card">
          <h3 className="font-semibold text-sm mb-4">Platform Performance (Last 30 days)</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {analytics.map((p: any) => {
              const platform = PLATFORM_CONFIG[p.platform as keyof typeof PLATFORM_CONFIG];
              if (!platform) return null;
              const Icon = platform.icon;
              const ctr = p.total_clicks && p.total_impressions
                ? ((p.total_clicks / p.total_impressions) * 100).toFixed(2)
                : '0';
              return (
                <div key={p.platform} className={`p-4 rounded-xl border ${platform.border} ${platform.bg}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <Icon className={`w-4 h-4 ${platform.color}`} />
                    <span className="font-semibold text-sm">{platform.name}</span>
                    <span className="ml-auto text-xs font-bold text-emerald-500">
                      {parseFloat(p.avg_roas || 0).toFixed(1)}x ROAS
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div><p className="text-muted-foreground">Impressions</p><p className="font-bold">{formatNumber(p.total_impressions || 0)}</p></div>
                    <div><p className="text-muted-foreground">Clicks</p><p className="font-bold">{formatNumber(p.total_clicks || 0)}</p></div>
                    <div><p className="text-muted-foreground">CTR</p><p className="font-bold">{ctr}%</p></div>
                    <div><p className="text-muted-foreground">Spent</p><p className="font-bold">{formatCurrency(p.total_spent || 0)}</p></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Campaigns List */}
      <div className="stat-card !p-0 overflow-hidden">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-sm">Active Campaigns</h3>
          <span className="text-xs text-muted-foreground">{campaigns.length} total</span>
        </div>
        <div className="divide-y divide-border">
          {(campaigns.length ? campaigns : MOCK_CAMPAIGNS).map((c: any) => (
            <div key={c.id} className="px-5 py-4 flex items-center gap-4 hover:bg-muted/30 transition-colors">
              <div className="flex gap-1">
                {(c.platforms || []).map((p: string) => {
                  const platform = PLATFORM_CONFIG[p as keyof typeof PLATFORM_CONFIG];
                  if (!platform) return null;
                  const Icon = platform.icon;
                  return <Icon key={p} className={`w-4 h-4 ${platform.color}`} />;
                })}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{c.name}</p>
                <p className="text-xs text-muted-foreground">
                  ${c.daily_budget || c.dailyBudget}/day · {c.duration_days || c.durationDays} days
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <div className="text-center">
                  <p className="font-semibold">{formatNumber(c.impressions || 0)}</p>
                  <p className="text-muted-foreground">Impressions</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold text-emerald-500">{(c.roas || 0).toFixed(1)}x</p>
                  <p className="text-muted-foreground">ROAS</p>
                </div>
              </div>
              <span className={c.status === 'active' ? 'badge-success' : c.status === 'draft' ? 'badge-warning' : 'badge-neutral'}>
                {c.status}
              </span>
              {c.status === 'draft' && (
                <button
                  onClick={() => publishMutation.mutate(c.id)}
                  className="px-3 py-1.5 text-xs bg-brand-500 hover:bg-brand-600 text-white rounded-lg transition-colors"
                >
                  Publish
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const MOCK_CAMPAIGNS = [
  { id: '1', name: 'Wireless Earbuds Pro — Auto Campaign', platforms: ['tiktok', 'instagram'], status: 'active', daily_budget: 35, duration_days: 7, impressions: 45200, roas: 3.8 },
  { id: '2', name: 'LED Strip Lights 5m — TikTok Viral Push', platforms: ['tiktok'], status: 'active', daily_budget: 25, duration_days: 5, impressions: 23800, roas: 4.2 },
  { id: '3', name: 'Smart Watch Fitness — Facebook Retarget', platforms: ['facebook'], status: 'active', daily_budget: 20, duration_days: 14, impressions: 18500, roas: 2.9 },
  { id: '4', name: 'Portable Blender USB — New Launch', platforms: ['tiktok', 'instagram', 'facebook'], status: 'draft', daily_budget: 50, duration_days: 7, impressions: 0, roas: 0 },
];
