// ─── autopilot-config.entity.ts ──────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('autopilot_configs')
export class AutopilotConfig {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id', unique: true }) tenantId: string;
  @Column({ default: false }) enabled: boolean;
  @Column({ name: 'enabled_by', nullable: true }) enabledBy: string;
  @Column({ name: 'enabled_at', nullable: true }) enabledAt: Date;
  @Column({ name: 'min_margin_percent', type: 'numeric', default: 35 }) minMarginPercent: number;
  @Column({ name: 'max_daily_ad_spend', type: 'numeric', default: 50 }) maxDailyAdSpend: number;
  @Column({ name: 'min_supplier_reliability', type: 'numeric', precision: 3, scale: 2, default: 0.9 }) minSupplierReliability: number;
  @Column({ name: 'min_roas_threshold', type: 'numeric', precision: 4, scale: 2, default: 1.6 }) minRoasThreshold: number;
  @Column({ name: 'auto_import_threshold', type: 'numeric', default: 75 }) autoImportThreshold: number;
  @Column({ name: 'auto_respond_confidence', type: 'numeric', precision: 3, scale: 2, default: 0.85 }) autoRespondConfidence: number;
  @Column({ name: 'pricing_strategy', default: 'ai_optimal' }) pricingStrategy: string;
  @Column({ name: 'max_price_increase_percent', type: 'numeric', default: 15 }) maxPriceIncreasePercent: number;
  @Column({ name: 'require_approval_above', type: 'numeric', default: 100 }) requireApprovalAbove: number;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── autopilot-decision.entity.ts ────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('autopilot_decisions')
export class AutopilotDecision {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 100 }) action: string;
  @Column({ length: 50 }) target: string;
  @Column({ name: 'target_id', nullable: true }) targetId: string;
  @Column({ name: 'old_value', type: 'jsonb', nullable: true }) oldValue: any;
  @Column({ name: 'new_value', type: 'jsonb', nullable: true }) newValue: any;
  @Column({ type: 'numeric', precision: 4, scale: 3 }) confidence: number;
  @Column({ type: 'text' }) reasoning: string;
  @Column({ default: false }) approved: boolean;
  @Column({ name: 'requires_approval', default: false }) requiresApproval: boolean;
  @Column({ name: 'approved_at', nullable: true }) approvedAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
