import {
  Injectable, Logger, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { Cron, CronExpression } from '@nestjs/schedule';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject } from '@nestjs/common';
import { Cache } from 'cache-manager';
import { ConfigService } from '@nestjs/config';
import { EventEmitter2 } from '@nestjs/event-emitter';
import OpenAI from 'openai';
import { AutopilotConfig } from './entities/autopilot-config.entity';
import { AutopilotDecision } from './entities/autopilot-decision.entity';

// ── Interfaces ─────────────────────────────────────────────────────────────────
export interface AutopilotRules {
  minMarginPercent: number;            // e.g. 35 — never go below this
  maxDailyAdSpend: number;             // hard cap on daily ad budget
  minSupplierReliability: number;      // switch supplier below this (0-1)
  minRoasThreshold: number;            // pause ads below this ROAS
  autoImportThreshold: number;         // import products scoring above this
  autoRespondConfidence: number;       // auto-respond tickets above this
  pricingStrategy: string;             // cost_plus | competitor | ai_optimal
  enabled: boolean;
  maxPriceIncreasePercent: number;     // max price increase in one cycle
  requireApprovalAbove: number;        // dollar value — require approval above
}

export interface DecisionResult {
  action: string;
  target: string;
  targetId: string;
  oldValue: any;
  newValue: any;
  confidence: number;
  reasoning: string;
  approved: boolean;
  requiresApproval: boolean;
}

@Injectable()
export class AutopilotService {
  private readonly logger = new Logger(AutopilotService.name);
  private openai: OpenAI;

  constructor(
    @InjectRepository(AutopilotConfig) private configRepo: Repository<AutopilotConfig>,
    @InjectRepository(AutopilotDecision) private decisionsRepo: Repository<AutopilotDecision>,
    @InjectQueue('standard') private standardQueue: Queue,
    @InjectQueue('background') private backgroundQueue: Queue,
    @Inject(CACHE_MANAGER) private cache: Cache,
    private dataSource: DataSource,
    private config: ConfigService,
    private events: EventEmitter2,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Enable / Disable ───────────────────────────────────────────────────────
  async enable(tenantId: string, userId: string): Promise<void> {
    await this.configRepo.upsert(
      { tenantId, enabled: true, enabledBy: userId, enabledAt: new Date() },
      ['tenantId'],
    );
    await this.cache.del(`autopilot:config:${tenantId}`);

    // Queue initial full analysis
    await this.standardQueue.add('autopilot_full_scan', { tenantId }, { priority: 8 });
    this.logger.log(`Autopilot ENABLED for tenant ${tenantId}`);
    this.events.emit('autopilot.enabled', { tenantId });
  }

  async disable(tenantId: string): Promise<void> {
    await this.configRepo.update({ tenantId }, { enabled: false });
    await this.cache.del(`autopilot:config:${tenantId}`);
    this.logger.log(`Autopilot DISABLED for tenant ${tenantId}`);
  }

  // ── Get State ──────────────────────────────────────────────────────────────
  async getStatus(tenantId: string) {
    const cfg = await this.getConfig(tenantId);
    const recentDecisions = await this.decisionsRepo.find({
      where: { tenantId },
      order: { createdAt: 'DESC' },
      take: 10,
    });

    const stats = await this.dataSource.query(
      `SELECT
        COUNT(*) as total_decisions,
        COUNT(*) FILTER (WHERE approved = true) as auto_approved,
        COUNT(*) FILTER (WHERE requires_approval = true) as pending_approval,
        AVG(confidence) as avg_confidence
       FROM autopilot_decisions
       WHERE tenant_id = $1 AND created_at >= NOW() - INTERVAL '7 days'`,
      [tenantId],
    );

    return {
      enabled: cfg.enabled,
      config: cfg,
      recentDecisions,
      weeklyStats: stats[0],
      nextRunAt: new Date(Date.now() + 4 * 60 * 60 * 1000), // next 4h cycle
    };
  }

  // ── Get / Update Config ────────────────────────────────────────────────────
  async getConfig(tenantId: string): Promise<AutopilotConfig> {
    const cacheKey = `autopilot:config:${tenantId}`;
    const cached = await this.cache.get<AutopilotConfig>(cacheKey);
    if (cached) return cached;

    let cfg = await this.configRepo.findOne({ where: { tenantId } });
    if (!cfg) {
      cfg = await this.configRepo.save(this.configRepo.create({
        tenantId,
        enabled: false,
        minMarginPercent: 35,
        maxDailyAdSpend: 50,
        minSupplierReliability: 0.90,
        minRoasThreshold: 1.6,
        autoImportThreshold: 75,
        autoRespondConfidence: 0.85,
        pricingStrategy: 'ai_optimal',
        maxPriceIncreasePercent: 15,
        requireApprovalAbove: 100,
      }));
    }

    await this.cache.set(cacheKey, cfg, 300);
    return cfg;
  }

  async updateConfig(tenantId: string, updates: Partial<AutopilotRules>) {
    // Safety validation — enforce hard minimums
    if (updates.minMarginPercent !== undefined && updates.minMarginPercent < 15) {
      throw new BadRequestException('Minimum margin cannot be set below 15%');
    }
    if (updates.maxDailyAdSpend !== undefined && updates.maxDailyAdSpend > 10000) {
      throw new BadRequestException('Daily ad spend cap cannot exceed $10,000 without enterprise plan');
    }

    await this.configRepo.update({ tenantId }, updates as any);
    await this.cache.del(`autopilot:config:${tenantId}`);
    return this.getConfig(tenantId);
  }

  // ── Main Autopilot Cycle (runs every 4 hours) ──────────────────────────────
  @Cron('0 */4 * * *')
  async runAutopilotCycle() {
    this.logger.log('Starting global autopilot cycle...');
    const activeTenants = await this.dataSource.query(
      `SELECT tenant_id FROM autopilot_configs WHERE enabled = true`,
    );

    for (const { tenant_id } of activeTenants) {
      await this.standardQueue.add(
        'autopilot_cycle',
        { tenantId: tenant_id },
        { priority: 5 },
      );
    }
  }

  // ── Run Cycle for Single Tenant ────────────────────────────────────────────
  async runCycleForTenant(tenantId: string): Promise<void> {
    const cfg = await this.getConfig(tenantId);
    if (!cfg.enabled) return;

    this.logger.log(`Running autopilot cycle for tenant ${tenantId}`);

    // Run all optimization tasks in parallel
    const [pricingResults, adResults, supplierResults, importResults] = await Promise.allSettled([
      this.runPricingOptimization(tenantId, cfg),
      this.runAdOptimization(tenantId, cfg),
      this.runSupplierHealthCheck(tenantId, cfg),
      this.runAutoImport(tenantId, cfg),
    ]);

    // Log cycle summary
    const decisions = [pricingResults, adResults, supplierResults, importResults]
      .filter((r) => r.status === 'fulfilled')
      .flatMap((r: any) => r.value || []);

    this.logger.log(
      `Autopilot cycle complete for ${tenantId}: ${decisions.length} decisions made`,
    );

    this.events.emit('autopilot.cycle_complete', { tenantId, decisions });
  }

  // ── Pricing Optimization ───────────────────────────────────────────────────
  async runPricingOptimization(tenantId: string, cfg: AutopilotConfig): Promise<DecisionResult[]> {
    const products = await this.dataSource.query(
      `SELECT id, name, base_price, cost_price, sales_count, ai_score
       FROM products
       WHERE tenant_id = $1 AND status = 'active' AND deleted_at IS NULL
       LIMIT 100`,
      [tenantId],
    );

    const decisions: DecisionResult[] = [];

    for (const product of products) {
      try {
        const decision = await this.optimizeProductPrice(product, cfg, tenantId);
        if (decision) decisions.push(decision);
      } catch (e) {
        this.logger.warn(`Pricing failed for ${product.id}: ${e.message}`);
      }
    }

    return decisions;
  }

  private async optimizeProductPrice(
    product: any, cfg: AutopilotConfig, tenantId: string,
  ): Promise<DecisionResult | null> {
    const costPrice = parseFloat(product.cost_price);
    const currentPrice = parseFloat(product.base_price);
    const minAllowedPrice = costPrice * (1 + cfg.minMarginPercent / 100);

    // Fetch competitor prices (mock — real implementation scrapes/API)
    const competitorPrices = await this.fetchCompetitorPrices(product.name);
    const competitorAvg = competitorPrices.length
      ? competitorPrices.reduce((a: number, b: number) => a + b, 0) / competitorPrices.length
      : currentPrice;

    // AI-powered optimal price calculation
    let suggestedPrice: number;
    let reasoning: string;

    if (cfg.pricingStrategy === 'ai_optimal') {
      const result = await this.aiCalculatePrice(product, competitorAvg, minAllowedPrice, cfg);
      suggestedPrice = result.price;
      reasoning = result.reasoning;
    } else if (cfg.pricingStrategy === 'competitor') {
      suggestedPrice = Math.max(competitorAvg * 0.98, minAllowedPrice);
      reasoning = `Set 2% below competitor average ($${competitorAvg.toFixed(2)})`;
    } else {
      suggestedPrice = costPrice * (1 + cfg.minMarginPercent / 100) * 1.2;
      reasoning = `Cost-plus pricing with ${cfg.minMarginPercent + 20}% markup`;
    }

    // Hard floor check
    suggestedPrice = Math.max(suggestedPrice, minAllowedPrice);

    // Don't update if change is negligible (<2%)
    const changePercent = Math.abs((suggestedPrice - currentPrice) / currentPrice) * 100;
    if (changePercent < 2) return null;

    // Check if exceeds max increase limit
    const increasePercent = ((suggestedPrice - currentPrice) / currentPrice) * 100;
    if (increasePercent > cfg.maxPriceIncreasePercent) {
      suggestedPrice = currentPrice * (1 + cfg.maxPriceIncreasePercent / 100);
      reasoning += ` (capped at +${cfg.maxPriceIncreasePercent}% limit)`;
    }

    const confidence = 0.85;
    const requiresApproval = (suggestedPrice - currentPrice) > cfg.requireApprovalAbove;

    if (!requiresApproval) {
      // Auto-apply
      await this.dataSource.query(
        `UPDATE products SET base_price = $1 WHERE id = $2 AND tenant_id = $3`,
        [suggestedPrice.toFixed(2), product.id, tenantId],
      );
      await this.dataSource.query(
        `INSERT INTO pricing_history (product_id, tenant_id, old_price, new_price, strategy, change_reason, ai_confidence)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [product.id, tenantId, currentPrice, suggestedPrice, 'autopilot', reasoning, confidence],
      );
    }

    const decision: DecisionResult = {
      action: 'PRICE_UPDATE',
      target: 'product',
      targetId: product.id,
      oldValue: currentPrice,
      newValue: suggestedPrice,
      confidence,
      reasoning,
      approved: !requiresApproval,
      requiresApproval,
    };

    await this.logDecision(tenantId, decision);
    return decision;
  }

  // ── Ad Optimization ────────────────────────────────────────────────────────
  async runAdOptimization(tenantId: string, cfg: AutopilotConfig): Promise<DecisionResult[]> {
    const ads = await this.dataSource.query(
      `SELECT a.id, a.campaign_name, a.platform, a.impressions, a.clicks, a.conversions,
              a.spent, a.roas, a.status,
              p.cost_price, p.base_price
       FROM ads a
       JOIN products p ON p.id = a.product_id
       WHERE a.tenant_id = $1 AND a.status = 'active'`,
      [tenantId],
    );

    const decisions: DecisionResult[] = [];

    for (const ad of ads) {
      if (ad.impressions < 1000) continue; // not enough data

      const ctr = ad.clicks / ad.impressions;
      const roas = parseFloat(ad.roas) || 0;
      const costPrice = parseFloat(ad.cost_price);
      const sellPrice = parseFloat(ad.base_price);
      const breakEvenRoas = sellPrice / (sellPrice - costPrice);

      // Pause ads losing money
      if (roas > 0 && roas < cfg.minRoasThreshold) {
        await this.dataSource.query(
          `UPDATE ads SET status = 'paused' WHERE id = $1`,
          [ad.id],
        );
        const decision: DecisionResult = {
          action: 'PAUSE_AD',
          target: 'ad',
          targetId: ad.id,
          oldValue: 'active',
          newValue: 'paused',
          confidence: 0.95,
          reasoning: `ROAS ${roas.toFixed(2)}x below threshold ${cfg.minRoasThreshold}x (break-even: ${breakEvenRoas.toFixed(2)}x)`,
          approved: true,
          requiresApproval: false,
        };
        await this.logDecision(tenantId, decision);
        decisions.push(decision);
      }

      // Flag creative fatigue (CTR below 0.5% after 3+ days running)
      if (ctr < 0.005 && ad.impressions > 5000) {
        await this.standardQueue.add('generate_fresh_creatives', {
          tenantId,
          adId: ad.id,
          reason: 'creative_fatigue',
        });
      }
    }

    return decisions;
  }

  // ── Supplier Health Check ──────────────────────────────────────────────────
  async runSupplierHealthCheck(tenantId: string, cfg: AutopilotConfig): Promise<DecisionResult[]> {
    const suppliers = await this.dataSource.query(
      `SELECT id, name, reliability_score, failover_supplier_id, status
       FROM suppliers
       WHERE tenant_id = $1 AND status = 'active'`,
      [tenantId],
    );

    const decisions: DecisionResult[] = [];

    for (const supplier of suppliers) {
      const reliability = parseFloat(supplier.reliability_score) || 0.5;
      if (reliability < cfg.minSupplierReliability && supplier.failover_supplier_id) {
        // Switch to failover
        await this.dataSource.query(
          `UPDATE products SET supplier_id = $1 WHERE tenant_id = $2 AND supplier_id = $3`,
          [supplier.failover_supplier_id, tenantId, supplier.id],
        );

        const decision: DecisionResult = {
          action: 'SUPPLIER_FAILOVER',
          target: 'supplier',
          targetId: supplier.id,
          oldValue: supplier.id,
          newValue: supplier.failover_supplier_id,
          confidence: 0.9,
          reasoning: `Supplier reliability ${(reliability * 100).toFixed(0)}% below threshold ${(cfg.minSupplierReliability * 100).toFixed(0)}%`,
          approved: true,
          requiresApproval: false,
        };
        await this.logDecision(tenantId, decision);
        decisions.push(decision);
      }
    }

    return decisions;
  }

  // ── Auto Import ────────────────────────────────────────────────────────────
  async runAutoImport(tenantId: string, cfg: AutopilotConfig): Promise<DecisionResult[]> {
    await this.backgroundQueue.add(
      'auto_import_products',
      { tenantId, minScore: cfg.autoImportThreshold },
      { priority: 3 },
    );
    return [];
  }

  // ── Trigger Manual Import ──────────────────────────────────────────────────
  async triggerAutoImport(tenantId: string, options?: any) {
    const cfg = await this.getConfig(tenantId);
    const job = await this.standardQueue.add('auto_import_products', {
      tenantId,
      minScore: options?.minScore || cfg.autoImportThreshold,
      limit: options?.limit || 20,
    });
    return { jobId: job.id, message: 'Auto-import queued' };
  }

  // ── Get Decisions ──────────────────────────────────────────────────────────
  async getDecisions(tenantId: string, filters: any = {}) {
    const { page = 1, limit = 50, action, approved } = filters;
    const qb = this.decisionsRepo.createQueryBuilder('d')
      .where('d.tenantId = :tenantId', { tenantId })
      .orderBy('d.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    if (action) qb.andWhere('d.action = :action', { action });
    if (approved !== undefined) qb.andWhere('d.approved = :approved', { approved });

    const [data, total] = await qb.getManyAndCount();
    return { data, meta: { total, page, limit } };
  }

  // ── Approve Pending Decision ───────────────────────────────────────────────
  async approveDecision(tenantId: string, decisionId: string) {
    const decision = await this.decisionsRepo.findOne({
      where: { id: decisionId, tenantId, requiresApproval: true, approved: false },
    });

    if (!decision) throw new BadRequestException('Decision not found or already resolved');

    // Apply the decision
    await this.applyDecision(tenantId, decision);
    await this.decisionsRepo.update(decisionId, { approved: true, approvedAt: new Date() });

    return { success: true, decision };
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  private async aiCalculatePrice(
    product: any, competitorAvg: number, minPrice: number, cfg: AutopilotConfig,
  ) {
    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{
          role: 'user',
          content: `You are a pricing AI for a drop shipping store. Calculate the optimal price.

Product: ${product.name}
Cost: $${product.cost_price}
Current Price: $${product.base_price}
Competitor Average: $${competitorAvg.toFixed(2)}
Minimum Allowed: $${minPrice.toFixed(2)}
AI Trend Score: ${product.ai_score || 50}/100

Rules:
- Never below minimum ($${minPrice.toFixed(2)})
- Max increase: ${cfg.maxPriceIncreasePercent}% per cycle
- Aim for 40-60% margin when trend score > 70
- Match or slightly undercut competitor when score < 50

Return JSON only: {"price": number, "reasoning": "brief explanation"}`,
        }],
        response_format: { type: 'json_object' },
        max_tokens: 100,
      });

      const result = JSON.parse(response.choices[0].message.content);
      return { price: Math.max(result.price, minPrice), reasoning: result.reasoning };
    } catch {
      return { price: minPrice * 1.1, reasoning: 'Fallback: cost-plus pricing (AI unavailable)' };
    }
  }

  private async fetchCompetitorPrices(productName: string): Promise<number[]> {
    // In production: integrate with price scraping service or SerpAPI
    // Mock for now
    return [];
  }

  private async logDecision(tenantId: string, decision: DecisionResult) {
    await this.decisionsRepo.save(this.decisionsRepo.create({
      tenantId,
      action: decision.action,
      target: decision.target,
      targetId: decision.targetId,
      oldValue: decision.oldValue,
      newValue: decision.newValue,
      confidence: decision.confidence,
      reasoning: decision.reasoning,
      approved: decision.approved,
      requiresApproval: decision.requiresApproval,
    }));
  }

  private async applyDecision(tenantId: string, decision: AutopilotDecision) {
    switch (decision.action) {
      case 'PRICE_UPDATE':
        await this.dataSource.query(
          `UPDATE products SET base_price = $1 WHERE id = $2 AND tenant_id = $3`,
          [decision.newValue, decision.targetId, tenantId],
        );
        break;
      case 'PAUSE_AD':
        await this.dataSource.query(
          `UPDATE ads SET status = 'paused' WHERE id = $1`,
          [decision.targetId],
        );
        break;
    }
  }
}
