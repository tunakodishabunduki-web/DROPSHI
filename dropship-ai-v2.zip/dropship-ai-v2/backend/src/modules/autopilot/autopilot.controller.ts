import {
  Controller, Get, Post, Put, Body, Param,
  Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AutopilotService } from './autopilot.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';
import { CurrentUser } from '../../common/decorators/index';

@ApiTags('autopilot')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'autopilot', version: '1' })
export class AutopilotController {
  constructor(private readonly svc: AutopilotService) {}

  @Get('status')
  @ApiOperation({ summary: 'Get autopilot status and recent decisions' })
  getStatus(@CurrentTenant() t: string) {
    return this.svc.getStatus(t);
  }

  @Post('enable')
  @Roles('tenant_admin')
  @ApiOperation({ summary: 'Enable autopilot mode' })
  enable(@CurrentTenant() t: string, @CurrentUser() user: any) {
    return this.svc.enable(t, user.id);
  }

  @Post('disable')
  @Roles('tenant_admin')
  @ApiOperation({ summary: 'Disable autopilot mode' })
  disable(@CurrentTenant() t: string) {
    return this.svc.disable(t);
  }

  @Get('config')
  @ApiOperation({ summary: 'Get autopilot configuration' })
  getConfig(@CurrentTenant() t: string) {
    return this.svc.getConfig(t);
  }

  @Put('config')
  @Roles('tenant_admin')
  @ApiOperation({ summary: 'Update autopilot rules and limits' })
  updateConfig(@Body() body: any, @CurrentTenant() t: string) {
    return this.svc.updateConfig(t, body);
  }

  @Get('decisions')
  @ApiOperation({ summary: 'Get all AI decisions made by autopilot' })
  getDecisions(@CurrentTenant() t: string, @Query() filters: any) {
    return this.svc.getDecisions(t, filters);
  }

  @Post('decisions/:id/approve')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Approve a pending autopilot decision' })
  approveDecision(
    @Param('id') id: string,
    @CurrentTenant() t: string,
  ) {
    return this.svc.approveDecision(t, id);
  }

  @Post('auto-import')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Trigger manual product auto-import' })
  triggerAutoImport(@Body() options: any, @CurrentTenant() t: string) {
    return this.svc.triggerAutoImport(t, options);
  }

  @Post('run-cycle')
  @Roles('tenant_admin')
  @ApiOperation({ summary: 'Manually trigger one autopilot cycle' })
  runCycle(@CurrentTenant() t: string) {
    return this.svc.runCycleForTenant(t);
  }
}
