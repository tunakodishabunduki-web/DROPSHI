// ─── viral-detector.service.ts ────────────────────────────────────────────────
import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject } from '@nestjs/common';
import { Cache } from 'cache-manager';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import OpenAI from 'openai';
import axios from 'axios';

export interface ViralSignal {
  source: string;          // tiktok_hashtag | google_trends | aliexpress_orders | reddit
  keyword: string;
  currentValue: number;
  previousValue: number;
  changePercent: number;
  timestamp: Date;
}

export interface ViralProductScore {
  productId?: string;
  keyword: string;
  overallScore: number;     // 0-100
  tiktokScore: number;
  googleTrendsScore: number;
  socialProofScore: number;
  impulseScore: number;
  signals: ViralSignal[];
  predictedPeakDays: number;  // days until expected viral peak
  recommendation: 'import_now' | 'watch' | 'skip';
  estimatedRevenue: number;
}

@Injectable()
export class ViralDetectorService {
  private readonly logger = new Logger(ViralDetectorService.name);
  private openai: OpenAI;

  constructor(
    private dataSource: DataSource,
    @InjectQueue('standard') private standardQueue: Queue,
    @Inject(CACHE_MANAGER) private cache: Cache,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Scan for Viral Products (runs every 6 hours) ───────────────────────────
  @Cron('0 */6 * * *')
  async runViralScan() {
    const tenants = await this.dataSource.query(
      `SELECT DISTINCT tenant_id FROM products WHERE status = 'active'`,
    );
    for (const { tenant_id } of tenants) {
      await this.standardQueue.add('viral_scan', { tenantId: tenant_id }, { priority: 4 });
    }
  }

  // ── Analyze Viral Potential ────────────────────────────────────────────────
  async analyzeViralPotential(keywords: string[]): Promise<ViralProductScore[]> {
    const cacheKey = `viral:batch:${keywords.join(',')}`;
    const cached = await this.cache.get<ViralProductScore[]>(cacheKey);
    if (cached) return cached;

    const scores = await Promise.all(keywords.map((kw) => this.scoreKeyword(kw)));
    const sorted = scores.sort((a, b) => b.overallScore - a.overallScore);

    await this.cache.set(cacheKey, sorted, 3600);
    return sorted;
  }

  // ── Get Top Viral Products ─────────────────────────────────────────────────
  async getTopViralProducts(tenantId: string, limit = 20) {
    const cacheKey = `viral:top:${tenantId}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) return cached;

    const trends = await this.dataSource.query(
      `SELECT t.*, p.name as product_name, p.base_price, p.images
       FROM trends t
       LEFT JOIN products p ON p.id = t.product_id
       WHERE (t.tenant_id = $1 OR t.tenant_id IS NULL)
         AND t.score >= 65
         AND t.recorded_at >= NOW() - INTERVAL '48 hours'
       ORDER BY t.score DESC, t.growth_rate DESC
       LIMIT $2`,
      [tenantId, limit],
    );

    await this.cache.set(cacheKey, trends, 1800);
    return trends;
  }

  // ── Analyze Specific Product ───────────────────────────────────────────────
  async analyzeProduct(tenantId: string, productId: string): Promise<ViralProductScore> {
    const product = await this.dataSource.query(
      'SELECT * FROM products WHERE id = $1 AND tenant_id = $2',
      [productId, tenantId],
    );
    if (!product[0]) throw new Error('Product not found');

    return this.scoreKeyword(product[0].name, productId);
  }

  // ── Score a Keyword ────────────────────────────────────────────────────────
  private async scoreKeyword(keyword: string, productId?: string): Promise<ViralProductScore> {
    const [tiktokSignals, googleSignals, aiAnalysis] = await Promise.all([
      this.getTikTokSignals(keyword),
      this.getGoogleTrendsSignals(keyword),
      this.getAiViralAnalysis(keyword),
    ]);

    const allSignals = [...tiktokSignals, ...googleSignals];

    const tiktokScore = this.calculateSignalScore(tiktokSignals);
    const googleTrendsScore = this.calculateSignalScore(googleSignals);
    const socialProofScore = aiAnalysis.socialProof;
    const impulseScore = aiAnalysis.impulse;

    const overallScore = Math.round(
      tiktokScore * 0.35 +
      googleTrendsScore * 0.25 +
      socialProofScore * 0.20 +
      impulseScore * 0.20,
    );

    const recommendation: 'import_now' | 'watch' | 'skip' =
      overallScore >= 75 ? 'import_now' : overallScore >= 55 ? 'watch' : 'skip';

    const estimatedRevenue = this.estimateRevenue(overallScore, aiAnalysis.priceRange);

    return {
      productId,
      keyword,
      overallScore,
      tiktokScore,
      googleTrendsScore,
      socialProofScore,
      impulseScore,
      signals: allSignals,
      predictedPeakDays: aiAnalysis.peakDays,
      recommendation,
      estimatedRevenue,
    };
  }

  private async getTikTokSignals(keyword: string): Promise<ViralSignal[]> {
    // In production: TikTok Research API (requires business account)
    // Simulated signals based on AI analysis
    try {
      const prompt = `Estimate TikTok trend data for "${keyword}" as a dropshipping product.
Return JSON: {"hashtagViews": number, "weeklyGrowth": number, "videoCount": number}
Be realistic for 2025 data.`;
      const r = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        max_tokens: 80,
      });
      const data = JSON.parse(r.choices[0].message.content);
      return [{
        source: 'tiktok_hashtag',
        keyword,
        currentValue: data.hashtagViews || 100000,
        previousValue: (data.hashtagViews || 100000) / (1 + (data.weeklyGrowth || 0.1) / 100),
        changePercent: data.weeklyGrowth || 10,
        timestamp: new Date(),
      }];
    } catch {
      return [];
    }
  }

  private async getGoogleTrendsSignals(keyword: string): Promise<ViralSignal[]> {
    // In production: Google Trends API via SerpAPI
    return [{
      source: 'google_trends',
      keyword,
      currentValue: Math.floor(Math.random() * 100),
      previousValue: Math.floor(Math.random() * 80),
      changePercent: Math.floor(Math.random() * 30),
      timestamp: new Date(),
    }];
  }

  private async getAiViralAnalysis(keyword: string) {
    try {
      const r = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{
          role: 'user',
          content: `Analyze viral potential of "${keyword}" as a dropshipping product in 2025-2026.
Return JSON: {socialProof: 0-100, impulse: 0-100, peakDays: number, priceRange: {min, max}}`,
        }],
        response_format: { type: 'json_object' },
        max_tokens: 100,
      });
      return JSON.parse(r.choices[0].message.content);
    } catch {
      return { socialProof: 50, impulse: 50, peakDays: 14, priceRange: { min: 15, max: 80 } };
    }
  }

  private calculateSignalScore(signals: ViralSignal[]): number {
    if (!signals.length) return 30;
    const avg = signals.reduce((s, sig) => s + Math.min(sig.changePercent, 100), 0) / signals.length;
    return Math.min(Math.round(avg), 100);
  }

  private estimateRevenue(score: number, priceRange: any): number {
    const midPrice = ((priceRange?.min || 20) + (priceRange?.max || 60)) / 2;
    const estUnits = score >= 75 ? 150 : score >= 55 ? 60 : 15;
    const margin = 0.4;
    return Math.round(midPrice * estUnits * margin);
  }

  // ── History ────────────────────────────────────────────────────────────────
  async getViralHistory(tenantId: string, days = 30) {
    return this.dataSource.query(
      `SELECT keyword, AVG(score) as avg_score, MAX(score) as peak_score,
              platform, DATE_TRUNC('day', recorded_at) as date
       FROM trends
       WHERE (tenant_id = $1 OR tenant_id IS NULL)
         AND recorded_at >= NOW() - INTERVAL '${days} days'
       GROUP BY keyword, platform, DATE_TRUNC('day', recorded_at)
       ORDER BY date DESC, avg_score DESC
       LIMIT 100`,
      [tenantId],
    );
  }
}
