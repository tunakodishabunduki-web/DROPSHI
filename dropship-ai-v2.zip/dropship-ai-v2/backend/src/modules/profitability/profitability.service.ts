import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { ConfigService } from '@nestjs/config';

// True cost breakdown per order
interface CostBreakdown {
  revenue: number;
  supplierCost: number;
  shippingCost: number;
  paymentFees: number;       // Stripe: 2.9% + $0.30
  adSpendAttribued: number;  // ad cost / conversions
  returnReserve: number;     // estimated return rate * refund cost
  platformFees: number;      // Shopify etc
  trueProfit: number;
  trueMarginPercent: number;
}

@Injectable()
export class ProfitabilityService {
  constructor(
    private dataSource: DataSource,
    private config: ConfigService,
  ) {}

  // ── Overview ───────────────────────────────────────────────────────────────
  async getOverview(tenantId: string, period: '7d' | '30d' | '90d' = '30d') {
    const interval = { '7d': '7 days', '30d': '30 days', '90d': '90 days' }[period];

    const [revenue, costs, adSpend, refunds] = await Promise.all([
      this.getRevenue(tenantId, interval),
      this.getCosts(tenantId, interval),
      this.getAdSpend(tenantId, interval),
      this.getRefunds(tenantId, interval),
    ]);

    const totalRevenue = parseFloat(revenue[0]?.total_revenue || 0);
    const supplierCost = parseFloat(costs[0]?.supplier_cost || 0);
    const shippingCost = parseFloat(costs[0]?.shipping_cost || 0);
    const paymentFees = totalRevenue * 0.029 + (parseInt(revenue[0]?.order_count || 0) * 0.30);
    const totalAdSpend = parseFloat(adSpend[0]?.total_spend || 0);
    const totalRefunds = parseFloat(refunds[0]?.total_refunds || 0);

    const totalCosts = supplierCost + shippingCost + paymentFees + totalAdSpend + totalRefunds;
    const trueProfit = totalRevenue - totalCosts;
    const trueMargin = totalRevenue > 0 ? (trueProfit / totalRevenue) * 100 : 0;

    return {
      period,
      revenue: totalRevenue,
      costs: {
        supplierCost,
        shippingCost,
        paymentFees: parseFloat(paymentFees.toFixed(2)),
        adSpend: totalAdSpend,
        refunds: totalRefunds,
        total: parseFloat(totalCosts.toFixed(2)),
      },
      trueProfit: parseFloat(trueProfit.toFixed(2)),
      trueMarginPercent: parseFloat(trueMargin.toFixed(2)),
      orderCount: parseInt(revenue[0]?.order_count || 0),
      avgOrderProfit: parseInt(revenue[0]?.order_count || 0) > 0
        ? parseFloat((trueProfit / parseInt(revenue[0].order_count)).toFixed(2))
        : 0,
      healthStatus: trueMargin >= 30 ? 'excellent' : trueMargin >= 20 ? 'good' : trueMargin >= 10 ? 'fair' : 'poor',
    };
  }

  // ── Per-Product Profitability ──────────────────────────────────────────────
  async getProductProfitability(tenantId: string, limit = 20) {
    return this.dataSource.query(
      `SELECT
        p.id, p.name, p.base_price, p.cost_price, p.images,
        COUNT(oi.id) as units_sold,
        SUM(oi.total) as gross_revenue,
        SUM(oi.quantity * p.cost_price) as supplier_cost,
        SUM(oi.total) - SUM(oi.quantity * p.cost_price) as gross_profit,
        ROUND(((SUM(oi.total) - SUM(oi.quantity * p.cost_price)) / NULLIF(SUM(oi.total), 0)) * 100, 2) as gross_margin,
        -- Estimated true profit after payment fees (2.9%+$0.30) and avg return rate (5%)
        SUM(oi.total) - SUM(oi.quantity * p.cost_price) 
          - SUM(oi.total) * 0.029 - COUNT(DISTINCT oi.order_id) * 0.30
          - SUM(oi.total) * 0.05 * 0.8 as estimated_true_profit
       FROM products p
       JOIN order_items oi ON oi.product_id = p.id
       JOIN orders o ON o.id = oi.order_id
       WHERE p.tenant_id = $1
         AND o.status NOT IN ('cancelled', 'refunded')
         AND o.created_at >= NOW() - INTERVAL '30 days'
       GROUP BY p.id, p.name, p.base_price, p.cost_price, p.images
       ORDER BY estimated_true_profit DESC
       LIMIT $2`,
      [tenantId, limit],
    );
  }

  // ── Per-Supplier Profitability ─────────────────────────────────────────────
  async getSupplierProfitability(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        s.id, s.name, s.reliability_score,
        COUNT(DISTINCT oi.order_id) as total_orders,
        SUM(oi.total) as total_revenue,
        SUM(oi.quantity * oi.cost_price) as total_cost,
        SUM(oi.total) - SUM(oi.quantity * oi.cost_price) as gross_profit,
        ROUND(((SUM(oi.total) - SUM(oi.quantity * oi.cost_price)) / NULLIF(SUM(oi.total), 0)) * 100, 2) as margin,
        COUNT(DISTINCT CASE WHEN o.status = 'refunded' THEN o.id END) as refunds
       FROM suppliers s
       JOIN order_items oi ON oi.supplier_id = s.id
       JOIN orders o ON o.id = oi.order_id
       WHERE s.tenant_id = $1
         AND o.created_at >= NOW() - INTERVAL '30 days'
       GROUP BY s.id, s.name, s.reliability_score
       ORDER BY gross_profit DESC`,
      [tenantId],
    );
  }

  // ── Per-Campaign Profitability ─────────────────────────────────────────────
  async getCampaignProfitability(tenantId: string) {
    return this.dataSource.query(
      `SELECT
        sc.id, sc.name, sc.platforms,
        SUM(sp.spent) as ad_spend,
        SUM(sp.conversions) as conversions,
        SUM(sp.conversions * p.base_price) as attributed_revenue,
        SUM(sp.conversions * (p.base_price - p.cost_price)) - SUM(sp.spent) as profit,
        CASE WHEN SUM(sp.spent) > 0 
          THEN ROUND(SUM(sp.conversions * p.base_price) / SUM(sp.spent), 4)
          ELSE 0 END as roas,
        SUM(sp.impressions) as impressions,
        SUM(sp.clicks) as clicks
       FROM social_campaigns sc
       JOIN social_posts sp ON sp.campaign_id = sc.id
       JOIN products p ON p.id = sc.product_id
       WHERE sc.tenant_id = $1
         AND sc.created_at >= NOW() - INTERVAL '30 days'
       GROUP BY sc.id, sc.name, sc.platforms, p.base_price, p.cost_price
       ORDER BY profit DESC`,
      [tenantId],
    );
  }

  // ── Customer LTV ───────────────────────────────────────────────────────────
  async getCustomerLTV(tenantId: string) {
    return this.dataSource.query(
      `WITH customer_stats AS (
        SELECT
          c.id, c.email, c.first_name, c.last_name,
          COUNT(o.id) as order_count,
          SUM(o.total) as total_revenue,
          AVG(o.total) as avg_order,
          MIN(o.created_at) as first_order,
          MAX(o.created_at) as last_order,
          EXTRACT(EPOCH FROM (MAX(o.created_at) - MIN(o.created_at)))/2592000 as tenure_months
        FROM customers c
        JOIN orders o ON o.customer_id = c.id
        WHERE c.tenant_id = $1
          AND o.status = 'delivered'
        GROUP BY c.id, c.email, c.first_name, c.last_name
      )
      SELECT *,
        -- LTV prediction: avg_order * order_frequency * projected_months
        ROUND(avg_order * (order_count / GREATEST(tenure_months, 1)) * 12, 2) as predicted_annual_ltv,
        CASE 
          WHEN order_count >= 5 AND total_revenue > 500 THEN 'champion'
          WHEN order_count >= 3 THEN 'loyal'
          WHEN order_count >= 2 THEN 'repeat'
          WHEN last_order < NOW() - INTERVAL '60 days' THEN 'at_risk'
          ELSE 'new'
        END as segment
      FROM customer_stats
      ORDER BY total_revenue DESC
      LIMIT 50`,
      [tenantId],
    );
  }

  // ── Export Report ──────────────────────────────────────────────────────────
  async exportReport(tenantId: string, period: string): Promise<string> {
    const [overview, products, suppliers] = await Promise.all([
      this.getOverview(tenantId, period as any),
      this.getProductProfitability(tenantId, 50),
      this.getSupplierProfitability(tenantId),
    ]);

    const csv = [
      'DropShip AI — Profitability Report',
      `Period: Last ${period}`,
      `Generated: ${new Date().toISOString()}`,
      '',
      '=== OVERVIEW ===',
      `Revenue,$${overview.revenue}`,
      `True Profit,$${overview.trueProfit}`,
      `True Margin,${overview.trueMarginPercent}%`,
      `Orders,${overview.orderCount}`,
      '',
      '=== TOP PRODUCTS ===',
      'Product,Units Sold,Revenue,Supplier Cost,True Profit,Margin',
      ...products.map((p: any) =>
        `${p.name},${p.units_sold},$${p.gross_revenue},$${p.supplier_cost},$${p.estimated_true_profit},${p.gross_margin}%`,
      ),
      '',
      '=== SUPPLIER PERFORMANCE ===',
      'Supplier,Orders,Revenue,Cost,Profit,Margin,Reliability',
      ...suppliers.map((s: any) =>
        `${s.name},${s.total_orders},$${s.total_revenue},$${s.total_cost},$${s.gross_profit},${s.margin}%,${(parseFloat(s.reliability_score || 0) * 100).toFixed(0)}%`,
      ),
    ].join('\n');

    return csv;
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  private getRevenue(tenantId: string, interval: string) {
    return this.dataSource.query(
      `SELECT COALESCE(SUM(total), 0) as total_revenue, COUNT(*) as order_count
       FROM orders WHERE tenant_id = $1 AND status = 'delivered'
       AND created_at >= NOW() - INTERVAL '${interval}'`,
      [tenantId],
    );
  }

  private getCosts(tenantId: string, interval: string) {
    return this.dataSource.query(
      `SELECT COALESCE(SUM(oi.quantity * oi.cost_price), 0) as supplier_cost,
              COALESCE(SUM(o.shipping_total), 0) as shipping_cost
       FROM order_items oi JOIN orders o ON o.id = oi.order_id
       WHERE oi.tenant_id = $1 AND o.status = 'delivered'
       AND o.created_at >= NOW() - INTERVAL '${interval}'`,
      [tenantId],
    );
  }

  private getAdSpend(tenantId: string, interval: string) {
    return this.dataSource.query(
      `SELECT COALESCE(SUM(spent), 0) as total_spend
       FROM social_posts sp
       JOIN social_campaigns sc ON sc.id = sp.campaign_id
       WHERE sc.tenant_id = $1
       AND sp.created_at >= NOW() - INTERVAL '${interval}'`,
      [tenantId],
    );
  }

  private getRefunds(tenantId: string, interval: string) {
    return this.dataSource.query(
      `SELECT COALESCE(SUM(refund_amount), 0) as total_refunds
       FROM orders WHERE tenant_id = $1 AND refund_amount > 0
       AND created_at >= NOW() - INTERVAL '${interval}'`,
      [tenantId],
    );
  }
}
