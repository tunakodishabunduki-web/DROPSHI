import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import OpenAI from 'openai';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ProfitabilityService } from '../profitability/profitability.service';

interface AnomalyAlert {
  type: string;
  severity: 'warning' | 'critical';
  message: string;
  metric: string;
  currentValue: number;
  expectedValue: number;
  changePercent: number;
  actionRequired: string;
}

@Injectable()
export class DailyReportService {
  private readonly logger = new Logger(DailyReportService.name);
  private openai: OpenAI;

  constructor(
    private dataSource: DataSource,
    private profitSvc: ProfitabilityService,
    @InjectQueue('background') private backgroundQueue: Queue,
    private events: EventEmitter2,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  // ── Daily Report Generation (8 AM every day) ──────────────────────────────
  @Cron('0 8 * * *')
  async generateDailyReports() {
    const tenants = await this.dataSource.query(
      `SELECT tenant_id FROM users WHERE role = 'tenant_admin' AND status = 'active'
       GROUP BY tenant_id`,
    );

    for (const { tenant_id } of tenants) {
      await this.backgroundQueue.add(
        'generate_daily_report',
        { tenantId: tenant_id },
        { priority: 2 },
      );
    }
  }

  // ── Generate Report for Tenant ────────────────────────────────────────────
  async generateReport(tenantId: string): Promise<any> {
    const [
      todayRevenue,
      yesterdayRevenue,
      weekRevenue,
      topProducts,
      recentOrders,
      adPerformance,
      inventoryAlerts,
      anomalies,
      profitOverview,
    ] = await Promise.all([
      this.getRevenueForPeriod(tenantId, 'today'),
      this.getRevenueForPeriod(tenantId, 'yesterday'),
      this.getRevenueForPeriod(tenantId, '7d'),
      this.getTopProducts(tenantId, 3),
      this.getRecentOrders(tenantId),
      this.getAdPerformanceSummary(tenantId),
      this.getInventoryAlerts(tenantId),
      this.detectAnomalies(tenantId),
      this.profitSvc.getOverview(tenantId, '7d'),
    ]);

    const revenueGrowth = yesterdayRevenue.total > 0
      ? ((todayRevenue.total - yesterdayRevenue.total) / yesterdayRevenue.total) * 100
      : 0;

    // Generate AI-written narrative
    const narrative = await this.generateNarrative({
      tenantId,
      todayRevenue,
      revenueGrowth,
      topProducts,
      anomalies,
      profitOverview,
    });

    const report = {
      tenantId,
      generatedAt: new Date(),
      period: 'daily',
      summary: {
        revenue: {
          today: todayRevenue.total,
          yesterday: yesterdayRevenue.total,
          week: weekRevenue.total,
          growthPercent: parseFloat(revenueGrowth.toFixed(2)),
        },
        orders: {
          today: todayRevenue.count,
          yesterday: yesterdayRevenue.count,
          trend: revenueGrowth >= 0 ? 'up' : 'down',
        },
        profit: {
          margin: profitOverview.trueMarginPercent,
          status: profitOverview.healthStatus,
        },
      },
      topProducts,
      adPerformance,
      anomalies,
      inventoryAlerts,
      aiNarrative: narrative,
      actionsRequired: [
        ...anomalies.filter((a) => a.severity === 'critical').map((a) => a.actionRequired),
        ...inventoryAlerts.filter((i: any) => i.urgent).map((i: any) => `Restock ${i.productName} (${i.daysLeft} days left)`),
      ],
    };

    // Save to DB
    await this.dataSource.query(
      `INSERT INTO daily_reports (tenant_id, report_date, data)
       VALUES ($1, CURRENT_DATE, $2)
       ON CONFLICT (tenant_id, report_date) DO UPDATE SET data = $2`,
      [tenantId, JSON.stringify(report)],
    );

    // Emit event for email delivery
    this.events.emit('daily_report.ready', { tenantId, report });

    return report;
  }

  // ── Anomaly Detector ───────────────────────────────────────────────────────
  async detectAnomalies(tenantId: string): Promise<AnomalyAlert[]> {
    const anomalies: AnomalyAlert[] = [];

    // Check revenue drop
    const [today, avgLast7] = await Promise.all([
      this.getRevenueForPeriod(tenantId, 'today'),
      this.getAvgDailyRevenue(tenantId, 7),
    ]);

    if (avgLast7 > 0) {
      const revenueChange = ((today.total - avgLast7) / avgLast7) * 100;
      if (revenueChange < -30) {
        anomalies.push({
          type: 'revenue_drop',
          severity: revenueChange < -50 ? 'critical' : 'warning',
          message: `Revenue is ${Math.abs(revenueChange).toFixed(0)}% below 7-day average`,
          metric: 'daily_revenue',
          currentValue: today.total,
          expectedValue: avgLast7,
          changePercent: revenueChange,
          actionRequired: 'Check if store is accessible. Review ad campaigns. Check supplier stock levels.',
        });
      }
    }

    // Check refund spike
    const refundData = await this.dataSource.query(
      `SELECT COUNT(*) as refund_count, COUNT(DISTINCT tenant_id) as orders
       FROM orders WHERE tenant_id = $1 AND refunded_at >= NOW() - INTERVAL '24 hours'`,
      [tenantId],
    );
    const refundRate = refundData[0]?.orders > 0
      ? (refundData[0].refund_count / refundData[0].orders)
      : 0;
    if (refundRate > 0.05) {
      anomalies.push({
        type: 'refund_spike',
        severity: 'warning',
        message: `Refund rate ${(refundRate * 100).toFixed(1)}% (normal: <5%)`,
        metric: 'refund_rate',
        currentValue: refundRate,
        expectedValue: 0.05,
        changePercent: ((refundRate - 0.05) / 0.05) * 100,
        actionRequired: 'Review recent orders for quality issues. Check supplier fulfillment.',
      });
    }

    // Check ad ROAS drop
    const adData = await this.dataSource.query(
      `SELECT AVG(roas) as avg_roas FROM social_posts
       WHERE created_at >= NOW() - INTERVAL '48 hours'
       AND impressions > 1000`,
    );
    const avgRoas = parseFloat(adData[0]?.avg_roas || 0);
    if (avgRoas > 0 && avgRoas < 1.0) {
      anomalies.push({
        type: 'ad_roas_below_breakeven',
        severity: 'critical',
        message: `Average ad ROAS ${avgRoas.toFixed(2)}x is below break-even (1.0x) — losing money on ads`,
        metric: 'avg_roas',
        currentValue: avgRoas,
        expectedValue: 2.0,
        changePercent: -50,
        actionRequired: 'Pause all active ad campaigns immediately. Review product pricing.',
      });
    }

    // Supplier fulfillment check
    const supplierData = await this.dataSource.query(
      `SELECT s.name, s.reliability_score FROM suppliers s
       WHERE tenant_id = $1 AND reliability_score < 0.88 AND status = 'active'`,
      [tenantId],
    );
    for (const s of supplierData) {
      anomalies.push({
        type: 'supplier_reliability_drop',
        severity: 'warning',
        message: `${s.name} reliability dropped to ${(s.reliability_score * 100).toFixed(0)}%`,
        metric: 'supplier_reliability',
        currentValue: s.reliability_score,
        expectedValue: 0.95,
        changePercent: ((s.reliability_score - 0.95) / 0.95) * 100,
        actionRequired: `Consider switching to failover supplier. Investigate ${s.name} issues.`,
      });
    }

    return anomalies;
  }

  // ── AI Narrative Generator ─────────────────────────────────────────────────
  private async generateNarrative(data: any): Promise<string> {
    try {
      const prompt = `Generate a concise daily business report narrative for a drop shipping store owner.

Data:
- Today's revenue: $${data.todayRevenue.total} (${data.revenueGrowth >= 0 ? '+' : ''}${data.revenueGrowth.toFixed(1)}% vs yesterday)
- Orders today: ${data.todayRevenue.count}
- True profit margin this week: ${data.profitOverview.trueMarginPercent}%
- Store health: ${data.profitOverview.healthStatus}
- Anomalies: ${data.anomalies.length} (${data.anomalies.filter((a: any) => a.severity === 'critical').length} critical)
- Top product today: ${data.topProducts[0]?.name || 'None'}

Write a 3-4 sentence plain-English summary in the style of a smart business advisor. 
Start with the most important thing the owner needs to know.
End with one actionable recommendation.`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 200,
      });

      return response.choices[0].message.content;
    } catch {
      const trend = data.revenueGrowth >= 0 ? 'up' : 'down';
      return `Revenue is ${trend} ${Math.abs(data.revenueGrowth).toFixed(1)}% today with ${data.todayRevenue.count} orders. Your profit margin is ${data.profitOverview.trueMarginPercent}%, which is ${data.profitOverview.healthStatus}. ${data.anomalies.length > 0 ? `${data.anomalies.length} issues detected — review your action items below.` : 'All systems running normally.'}`;
    }
  }

  // ── Get Latest Report ──────────────────────────────────────────────────────
  async getLatestReport(tenantId: string) {
    const row = await this.dataSource.query(
      `SELECT * FROM daily_reports WHERE tenant_id = $1 ORDER BY report_date DESC LIMIT 1`,
      [tenantId],
    );
    return row[0] ? { ...row[0], data: row[0].data } : null;
  }

  async getReportHistory(tenantId: string, days = 30) {
    return this.dataSource.query(
      `SELECT report_date, data->>'summary' as summary_json FROM daily_reports
       WHERE tenant_id = $1 AND report_date >= CURRENT_DATE - INTERVAL '${days} days'
       ORDER BY report_date DESC`,
      [tenantId],
    );
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  private async getRevenueForPeriod(tenantId: string, period: string) {
    const whereClause = period === 'today'
      ? `created_at::date = CURRENT_DATE`
      : period === 'yesterday'
      ? `created_at::date = CURRENT_DATE - 1`
      : `created_at >= NOW() - INTERVAL '${period}'`;

    const rows = await this.dataSource.query(
      `SELECT COALESCE(SUM(total), 0) as total, COUNT(*) as count
       FROM orders WHERE tenant_id = $1 AND ${whereClause} AND status != 'cancelled'`,
      [tenantId],
    );
    return { total: parseFloat(rows[0]?.total || 0), count: parseInt(rows[0]?.count || 0) };
  }

  private async getAvgDailyRevenue(tenantId: string, days: number): Promise<number> {
    const rows = await this.dataSource.query(
      `SELECT COALESCE(SUM(total), 0) / $2 as avg_daily
       FROM orders WHERE tenant_id = $1
       AND created_at >= NOW() - INTERVAL '${days} days'
       AND status != 'cancelled'`,
      [tenantId, days],
    );
    return parseFloat(rows[0]?.avg_daily || 0);
  }

  private async getTopProducts(tenantId: string, limit: number) {
    return this.dataSource.query(
      `SELECT p.name, SUM(oi.total) as revenue, SUM(oi.quantity) as units
       FROM order_items oi
       JOIN products p ON p.id = oi.product_id
       JOIN orders o ON o.id = oi.order_id
       WHERE oi.tenant_id = $1 AND o.created_at::date = CURRENT_DATE
       GROUP BY p.name ORDER BY revenue DESC LIMIT $2`,
      [tenantId, limit],
    );
  }

  private async getRecentOrders(tenantId: string) {
    return this.dataSource.query(
      `SELECT o.order_number, o.total, o.status, o.created_at,
              c.email as customer_email
       FROM orders o LEFT JOIN customers c ON c.id = o.customer_id
       WHERE o.tenant_id = $1 ORDER BY o.created_at DESC LIMIT 5`,
      [tenantId],
    );
  }

  private async getAdPerformanceSummary(tenantId: string) {
    return this.dataSource.query(
      `SELECT platform, COUNT(*) as active_ads,
              SUM(impressions) as impressions, SUM(clicks) as clicks,
              SUM(spent) as spent, AVG(roas) as avg_roas
       FROM social_posts sp
       JOIN social_campaigns sc ON sc.id = sp.campaign_id
       WHERE sc.tenant_id = $1 AND sp.created_at >= NOW() - INTERVAL '24 hours'
       GROUP BY platform`,
      [tenantId],
    );
  }

  private async getInventoryAlerts(tenantId: string) {
    return this.dataSource.query(
      `SELECT p.id, p.name as product_name, p.stock_quantity,
              ROUND(p.stock_quantity::numeric / GREATEST(p.sales_count::numeric / 30, 0.1)) as days_left,
              p.stock_quantity <= p.low_stock_threshold as urgent
       FROM products p
       WHERE tenant_id = $1 AND status = 'active' AND track_inventory = true
       AND (p.stock_quantity <= p.low_stock_threshold OR p.stock_quantity <= 5)
       ORDER BY days_left ASC
       LIMIT 10`,
      [tenantId],
    );
  }
}
