// ─── ai-assistant.controller.ts ──────────────────────────────────────────────
import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AiAssistantService } from './ai-assistant.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('ai-assistant')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller({ path: 'ai-assistant', version: '1' })
export class AiAssistantController {
  constructor(private svc: AiAssistantService) {}

  @Post('chat')
  chat(
    @Body() body: { message: string; history?: any[] },
    @CurrentTenant() t: string,
  ) {
    return this.svc.chat(t, body.message, body.history || []);
  }
}

// ─── viral-detector.controller.ts ────────────────────────────────────────────
import { Controller, Get, Post, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ViralDetectorService } from './viral-detector.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('viral')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller({ path: 'viral', version: '1' })
export class ViralDetectorController {
  constructor(private svc: ViralDetectorService) {}

  @Get('scores')
  getTopViral(@CurrentTenant() t: string, @Query('limit') limit = 20) {
    return this.svc.getTopViralProducts(t, +limit);
  }

  @Get('trending')
  getTrending(@CurrentTenant() t: string) {
    return this.svc.analyzeViralPotential(['wireless earbuds', 'led strip', 'phone holder', 'portable blender', 'yoga mat', 'smart watch']);
  }

  @Post('analyze/:productId')
  analyzeProduct(@Param('productId') id: string, @CurrentTenant() t: string) {
    return this.svc.analyzeProduct(t, id);
  }

  @Get('history')
  getHistory(@CurrentTenant() t: string, @Query('days') days = 7) {
    return this.svc.getViralHistory(t, +days);
  }
}

// ─── inventory-forecaster.controller.ts ──────────────────────────────────────
import { Controller, Get, Post, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { InventoryForecasterService } from './inventory-forecaster.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('inventory')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller({ path: 'inventory', version: '1' })
export class InventoryForecasterController {
  constructor(private svc: InventoryForecasterService) {}

  @Get('forecasts')
  getForecasts(@CurrentTenant() t: string) { return this.svc.getForecasts(t); }

  @Get('reorders')
  getReorders(@CurrentTenant() t: string) { return this.svc.getReorderList(t); }

  @Post('run-forecast')
  runForecast(@CurrentTenant() t: string) { return this.svc.runForecast(t); }
}

// ─── profitability.controller.ts ─────────────────────────────────────────────
import { Controller, Get, Query, UseGuards, Res } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { Response } from 'express';
import { ProfitabilityService } from './profitability.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('profitability')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller({ path: 'profitability', version: '1' })
export class ProfitabilityController {
  constructor(private svc: ProfitabilityService) {}

  @Get('overview')
  getOverview(@CurrentTenant() t: string, @Query('period') period: any = '30d') {
    return this.svc.getOverview(t, period);
  }

  @Get('products')
  getProducts(@CurrentTenant() t: string) { return this.svc.getProductProfitability(t); }

  @Get('suppliers')
  getSuppliers(@CurrentTenant() t: string) { return this.svc.getSupplierProfitability(t); }

  @Get('campaigns')
  getCampaigns(@CurrentTenant() t: string) { return this.svc.getCampaignProfitability(t); }

  @Get('customers')
  getCustomers(@CurrentTenant() t: string) { return this.svc.getCustomerLTV(t); }

  @Get('report')
  async exportReport(@CurrentTenant() t: string, @Query('period') period = '30d', @Res() res: Response) {
    const csv = await this.svc.exportReport(t, period);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="profitability-${period}.csv"`);
    res.send(csv);
  }
}

// ─── daily-report.controller.ts ──────────────────────────────────────────────
import { Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { DailyReportService } from './daily-report.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentTenant } from '../../common/decorators/index';

@ApiTags('daily-report')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller({ path: 'daily-report', version: '1' })
export class DailyReportController {
  constructor(private svc: DailyReportService) {}

  @Get('latest')
  getLatest(@CurrentTenant() t: string) { return this.svc.getLatestReport(t); }

  @Get('history')
  getHistory(@CurrentTenant() t: string, @Query('days') days = 30) {
    return this.svc.getReportHistory(t, +days);
  }

  @Post('generate')
  generate(@CurrentTenant() t: string) { return this.svc.generateReport(t); }

  @Get('anomalies')
  getAnomalies(@CurrentTenant() t: string) { return this.svc.detectAnomalies(t); }
}
