import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';

@Injectable()
export class AiAssistantService {
  private readonly logger = new Logger(AiAssistantService.name);
  private openai: OpenAI;

  constructor(
    private dataSource: DataSource,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({ apiKey: config.get('OPENAI_API_KEY') });
  }

  async chat(tenantId: string, message: string, history: any[] = []) {
    // Fetch live store context
    const context = await this.buildStoreContext(tenantId);

    const systemPrompt = `You are an expert AI business advisor for a drop shipping store. You have live access to the store's data and give direct, actionable advice.

CURRENT STORE DATA:
${JSON.stringify(context, null, 2)}

INSTRUCTIONS:
- Be direct and specific — use actual numbers from the data
- Prioritize advice that maximizes profit and reduces losses  
- If you identify a problem, say what it is clearly and give a specific action
- Keep responses under 200 words unless complex analysis is needed
- Use markdown bold (**text**) for important numbers and product names
- If asked about something you don't have data for, say so and suggest where to look`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map((h: any) => ({ role: h.role, content: h.content })),
      { role: 'user', content: message },
    ];

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: messages as any,
        max_tokens: 600,
        temperature: 0.7,
      });

      const reply = response.choices[0].message.content;

      // Log the interaction
      await this.dataSource.query(
        `INSERT INTO ai_logs (tenant_id, module, task_type, status, input_data, output_data, tokens_used)
         VALUES ($1, 'ai_assistant', 'chat', 'completed', $2, $3, $4)`,
        [
          tenantId,
          JSON.stringify({ message }),
          JSON.stringify({ reply }),
          response.usage?.total_tokens || 0,
        ],
      ).catch(() => {}); // Non-critical

      return { reply };
    } catch (e) {
      this.logger.error(`AI chat failed: ${e.message}`);
      return {
        reply: "I'm having trouble connecting to the AI right now. Please check your OpenAI API key in Settings → AI Settings and try again.",
      };
    }
  }

  private async buildStoreContext(tenantId: string) {
    try {
      const [revenue, orders, products, adPerf, inventory] = await Promise.all([
        this.dataSource.query(
          `SELECT 
            COALESCE(SUM(CASE WHEN created_at >= NOW() - INTERVAL '24 hours' THEN total ELSE 0 END), 0) as today,
            COALESCE(SUM(CASE WHEN created_at >= NOW() - INTERVAL '7 days' THEN total ELSE 0 END), 0) as week,
            COALESCE(SUM(CASE WHEN created_at >= NOW() - INTERVAL '30 days' THEN total ELSE 0 END), 0) as month
           FROM orders WHERE tenant_id = $1 AND status != 'cancelled'`,
          [tenantId],
        ),
        this.dataSource.query(
          `SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'pending') as pending,
            COUNT(*) FILTER (WHERE status = 'processing') as processing
           FROM orders WHERE tenant_id = $1 AND created_at >= NOW() - INTERVAL '7 days'`,
          [tenantId],
        ),
        this.dataSource.query(
          `SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'active') as active,
            COUNT(*) FILTER (WHERE stock_quantity <= low_stock_threshold) as low_stock,
            AVG(ai_score) as avg_ai_score
           FROM products WHERE tenant_id = $1 AND deleted_at IS NULL`,
          [tenantId],
        ),
        this.dataSource.query(
          `SELECT platform, AVG(roas) as avg_roas, SUM(spent) as total_spend
           FROM social_posts sp JOIN social_campaigns sc ON sc.id = sp.campaign_id
           WHERE sc.tenant_id = $1 AND sp.created_at >= NOW() - INTERVAL '7 days'
           GROUP BY platform`,
          [tenantId],
        ),
        this.dataSource.query(
          `SELECT name as product_name, stock_quantity, low_stock_threshold
           FROM products WHERE tenant_id = $1 AND stock_quantity <= low_stock_threshold
           AND status = 'active' LIMIT 5`,
          [tenantId],
        ),
      ]);

      return {
        revenue: revenue[0] || {},
        orders: orders[0] || {},
        products: products[0] || {},
        adPerformance: adPerf || [],
        lowStockAlerts: inventory || [],
      };
    } catch {
      return { note: 'Could not fetch store data — limited context available' };
    }
  }
}
