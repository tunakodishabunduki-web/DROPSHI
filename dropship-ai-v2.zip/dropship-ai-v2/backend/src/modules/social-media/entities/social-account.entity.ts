// ─── social-account.entity.ts ─────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, Unique } from 'typeorm';

@Entity('social_accounts')
@Unique(['tenantId', 'platform'])
export class SocialAccount {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ length: 30 }) platform: string;
  @Column({ name: 'account_id', nullable: true }) accountId: string;
  @Column({ name: 'account_name', nullable: true }) accountName: string;
  @Column({ name: 'access_token', type: 'text' }) accessToken: string;
  @Column({ name: 'refresh_token', type: 'text', nullable: true }) refreshToken: string;
  @Column({ name: 'token_expires_at', nullable: true }) tokenExpiresAt: Date;
  @Column({ name: 'is_active', default: true }) isActive: boolean;
  @Column({ name: 'connected_at', nullable: true }) connectedAt: Date;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── social-campaign.entity.ts ────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('social_campaigns')
export class SocialCampaign {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'product_id', nullable: true }) productId: string;
  @Column({ length: 255 }) name: string;
  @Column({ type: 'text', array: true, default: [] }) platforms: string[];
  @Column({ default: 'draft' }) status: string;
  @Column({ name: 'daily_budget', type: 'numeric', precision: 10, scale: 2 }) dailyBudget: number;
  @Column({ name: 'total_budget', type: 'numeric', precision: 12, scale: 2, nullable: true }) totalBudget: number;
  @Column({ name: 'budget_split', type: 'jsonb', default: {} }) budgetSplit: object;
  @Column({ name: 'duration_days', default: 7 }) durationDays: number;
  @Column({ type: 'jsonb', default: {} }) targetAudience: object;
  @Column({ type: 'jsonb', default: [] }) creatives: object;
  @Column({ name: 'external_ids', type: 'jsonb', default: {} }) externalIds: object;
  @Column({ name: 'total_spent', type: 'numeric', precision: 12, scale: 2, default: 0 }) totalSpent: number;
  @Column({ name: 'starts_at', nullable: true }) startsAt: Date;
  @Column({ name: 'ends_at', nullable: true }) endsAt: Date;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}

// ─── social-post.entity.ts ────────────────────────────────────────────────────
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('social_posts')
export class SocialPost {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'tenant_id' }) tenantId: string;
  @Column({ name: 'campaign_id' }) campaignId: string;
  @Column({ length: 30 }) platform: string;
  @Column({ name: 'external_id', nullable: true }) externalId: string;
  @Column({ default: 'pending' }) status: string;
  @Column({ name: 'published_at', nullable: true }) publishedAt: Date;
  @Column({ type: 'bigint', default: 0 }) impressions: number;
  @Column({ type: 'bigint', default: 0 }) clicks: number;
  @Column({ type: 'bigint', default: 0 }) conversions: number;
  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 }) spent: number;
  @Column({ type: 'numeric', precision: 8, scale: 4, nullable: true }) roas: number;
  @Column({ name: 'ab_variant', nullable: true }) abVariant: string;
  @Column({ type: 'jsonb', default: {} }) metadata: object;
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
