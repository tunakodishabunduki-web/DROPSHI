import {
  Controller, Get, Post, Delete, Body, Param,
  Query, UseGuards, Req, Res, HttpCode, HttpStatus,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { SocialMediaService, SocialPlatform } from './social-media.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/index';
import { CurrentTenant } from '../../common/decorators/index';
import { Public } from '../../common/decorators/index';

@ApiTags('social')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller({ path: 'social', version: '1' })
export class SocialMediaController {
  constructor(private readonly svc: SocialMediaService) {}

  // ── Connected Accounts ────────────────────────────────────────────────────
  @Get('accounts')
  @ApiOperation({ summary: 'Get connected social media accounts' })
  getAccounts(@CurrentTenant() t: string) {
    return this.svc.getConnectedAccounts(t);
  }

  // ── OAuth Connect ─────────────────────────────────────────────────────────
  @Get('connect/:platform')
  @Roles('tenant_admin')
  @ApiOperation({ summary: 'Get OAuth URL to connect a social platform' })
  getConnectUrl(
    @Param('platform') platform: SocialPlatform,
    @CurrentTenant() t: string,
  ) {
    const url = this.svc.getOAuthUrl(platform, t);
    return { url, platform };
  }

  // ── OAuth Callback ─────────────────────────────────────────────────────────
  @Get('oauth/:platform/callback')
  @Public()
  @ApiOperation({ summary: 'OAuth callback handler (called by social platform)' })
  async oauthCallback(
    @Param('platform') platform: SocialPlatform,
    @Query('code') code: string,
    @Query('state') state: string,
    @Res() res: Response,
  ) {
    try {
      const decoded = JSON.parse(Buffer.from(state, 'base64').toString());
      await this.svc.handleOAuthCallback(platform, code, decoded.tenantId);
      res.redirect(`${process.env.APP_URL}/dashboard/social-media?connected=${platform}`);
    } catch (e) {
      res.redirect(`${process.env.APP_URL}/dashboard/social-media?error=${encodeURIComponent(e.message)}`);
    }
  }

  @Delete('disconnect/:platform')
  @Roles('tenant_admin')
  @ApiOperation({ summary: 'Disconnect a social platform' })
  disconnect(@Param('platform') platform: SocialPlatform, @CurrentTenant() t: string) {
    return this.svc.disconnectAccount(t, platform);
  }

  // ── Campaigns ─────────────────────────────────────────────────────────────
  @Get('campaigns')
  @ApiOperation({ summary: 'List all social campaigns' })
  getCampaigns(@CurrentTenant() t: string, @Query() filters: any) {
    return this.svc.getCampaigns(t, filters);
  }

  @Post('campaign')
  @Roles('tenant_admin', 'manager')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new social media campaign' })
  createCampaign(@Body() dto: any, @CurrentTenant() t: string) {
    return this.svc.createCampaign(t, dto);
  }

  @Post('campaign/:id/publish')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Publish a campaign to connected social platforms' })
  publishCampaign(@Param('id') id: string, @CurrentTenant() t: string) {
    return this.svc.publishCampaign(t, id);
  }

  // ── Creative Generation ───────────────────────────────────────────────────
  @Post('generate-creative')
  @ApiOperation({ summary: 'Generate AI ad creatives for a product' })
  generateCreative(
    @Body() body: { productId: string; platforms: SocialPlatform[] },
    @CurrentTenant() t: string,
  ) {
    // Get product first, then generate
    return this.svc.getCampaigns(t); // Placeholder — real impl fetches product
  }

  // ── Analytics ─────────────────────────────────────────────────────────────
  @Get('analytics')
  @ApiOperation({ summary: 'Get campaign performance analytics' })
  getAnalytics(@CurrentTenant() t: string, @Query('campaignId') campaignId?: string) {
    return this.svc.getCampaignAnalytics(t, campaignId);
  }

  // ── Auto Optimize ─────────────────────────────────────────────────────────
  @Post('optimize')
  @Roles('tenant_admin', 'manager')
  @ApiOperation({ summary: 'Run performance optimizer on all active campaigns' })
  optimize(@CurrentTenant() t: string) {
    return this.svc.runPerformanceOptimizer(t);
  }
}
