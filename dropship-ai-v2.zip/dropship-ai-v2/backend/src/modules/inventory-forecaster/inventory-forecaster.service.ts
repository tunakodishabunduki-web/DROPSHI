import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Cron } from '@nestjs/schedule';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { EventEmitter2 } from '@nestjs/event-emitter';

export interface InventoryForecast {
  productId: string;
  productName: string;
  currentStock: number;
  dailyVelocity: number;
  trendMultiplier: number;
  adjustedVelocity: number;
  leadTimeDays: number;
  daysUntilStockout: number;
  reorderDate: Date;
  reorderQuantity: number;
  urgency: 'critical' | 'high' | 'medium' | 'ok';
  confidence: number;
}

@Injectable()
export class InventoryForecasterService {
  private readonly logger = new Logger(InventoryForecasterService.name);

  constructor(
    private dataSource: DataSource,
    @InjectQueue('background') private backgroundQueue: Queue,
    private events: EventEmitter2,
  ) {}

  // ── Run Forecasts Daily ────────────────────────────────────────────────────
  @Cron('0 6 * * *') // 6 AM daily
  async runDailyForecasts() {
    const tenants = await this.dataSource.query(
      `SELECT DISTINCT tenant_id FROM products WHERE status = 'active' AND track_inventory = true`,
    );
    for (const { tenant_id } of tenants) {
      await this.backgroundQueue.add('inventory_forecast', { tenantId: tenant_id });
    }
  }

  // ── Get Forecasts ──────────────────────────────────────────────────────────
  async getForecasts(tenantId: string): Promise<InventoryForecast[]> {
    const products = await this.dataSource.query(
      `SELECT p.id, p.name, p.stock_quantity, p.low_stock_threshold,
              p.ai_score, p.sales_count,
              s.avg_ship_days as supplier_lead_time
       FROM products p
       LEFT JOIN suppliers s ON s.id = p.supplier_id
       WHERE p.tenant_id = $1
         AND p.status = 'active'
         AND p.track_inventory = true
       ORDER BY p.stock_quantity ASC`,
      [tenantId],
    );

    const forecasts = await Promise.all(
      products.map((p: any) => this.forecastProduct(p, tenantId)),
    );

    return forecasts.sort((a, b) => a.daysUntilStockout - b.daysUntilStockout);
  }

  // ── Get Reorders ───────────────────────────────────────────────────────────
  async getReorderList(tenantId: string): Promise<InventoryForecast[]> {
    const all = await this.getForecasts(tenantId);
    return all.filter((f) => f.urgency !== 'ok' || f.reorderDate <= new Date(Date.now() + 7 * 86400000));
  }

  // ── Forecast Single Product ────────────────────────────────────────────────
  private async forecastProduct(product: any, tenantId: string): Promise<InventoryForecast> {
    // Get 30-day sales velocity
    const salesData = await this.dataSource.query(
      `SELECT
        COALESCE(SUM(quantity), 0)::float / 30 as daily_avg,
        COALESCE(SUM(CASE WHEN o.created_at >= NOW() - INTERVAL '7 days' THEN quantity ELSE 0 END), 0)::float / 7 as recent_avg
       FROM order_items oi
       JOIN orders o ON o.id = oi.order_id
       WHERE oi.product_id = $1 AND o.status != 'cancelled'
       AND o.created_at >= NOW() - INTERVAL '30 days'`,
      [product.id],
    );

    const dailyVelocity = parseFloat(salesData[0]?.daily_avg || 0.5);
    const recentVelocity = parseFloat(salesData[0]?.recent_avg || 0.5);

    // Trend multiplier: if recent 7-day velocity > 30-day average, demand is accelerating
    const trendMultiplier = dailyVelocity > 0
      ? Math.min(recentVelocity / dailyVelocity, 3.0)
      : 1.0;

    // AI score boosts velocity estimate if product is trending
    const aiScoreBoost = product.ai_score >= 75 ? 1.2 : product.ai_score >= 50 ? 1.0 : 0.9;
    const adjustedVelocity = dailyVelocity * trendMultiplier * aiScoreBoost;

    const leadTimeDays = (product.supplier_lead_time || 14) + 3; // +3 safety buffer
    const stock = parseInt(product.stock_quantity || 0);
    const daysUntilStockout = adjustedVelocity > 0
      ? Math.floor(stock / adjustedVelocity)
      : 365;

    const reorderDate = new Date(Date.now() + (daysUntilStockout - leadTimeDays) * 86400000);
    const reorderQuantity = Math.ceil(adjustedVelocity * 30); // 30-day supply

    const urgency: 'critical' | 'high' | 'medium' | 'ok' =
      daysUntilStockout <= 3 ? 'critical'
      : daysUntilStockout <= 7 ? 'high'
      : daysUntilStockout <= leadTimeDays ? 'medium'
      : 'ok';

    if (urgency !== 'ok') {
      this.events.emit('inventory.low_stock', {
        tenantId,
        productId: product.id,
        productName: product.name,
        daysLeft: daysUntilStockout,
        urgency,
      });
    }

    return {
      productId: product.id,
      productName: product.name,
      currentStock: stock,
      dailyVelocity: parseFloat(dailyVelocity.toFixed(2)),
      trendMultiplier: parseFloat(trendMultiplier.toFixed(2)),
      adjustedVelocity: parseFloat(adjustedVelocity.toFixed(2)),
      leadTimeDays,
      daysUntilStockout,
      reorderDate,
      reorderQuantity: Math.max(reorderQuantity, 1),
      urgency,
      confidence: dailyVelocity > 0.5 ? 0.85 : 0.5,
    };
  }

  // ── Run forecast manually ──────────────────────────────────────────────────
  async runForecast(tenantId: string) {
    const job = await this.backgroundQueue.add('inventory_forecast', { tenantId });
    return { jobId: job.id, message: 'Forecast queued' };
  }
}
