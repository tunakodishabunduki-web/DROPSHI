# DropShip AI — First User Tutorial
## From Zero to Your First Sale in Under 30 Minutes

Welcome! This tutorial walks you through setting up your drop shipping store from scratch. Follow every step in order. No prior technical knowledge required.

---

## Before You Start — What You'll Need

- An email address
- A computer with internet access
- Your business bank account details (for payouts)
- 30 minutes of uninterrupted time

**Optional but recommended** (set these up in advance):
- A TikTok Business account (free at business.tiktok.com)
- An Instagram Business account (free, convert in app settings)
- A Facebook Business Manager account (free at business.facebook.com)
- A Stripe account for payment processing (stripe.com)

---

## Step 1: Create Your Account (2 minutes)

1. Go to the platform URL (e.g. `https://app.dropshipai.com`)
2. Click **"Start Free Trial"**
3. Fill in:
   - First name and last name
   - Work email address (use a real email — you'll receive daily reports here)
   - Password (minimum 8 characters, mix letters and numbers)
4. Click **"Create Account"**
5. Check your email for a verification link and click it

✅ **You're in!** The onboarding wizard will open automatically.

---

## Step 2: The Onboarding Wizard (5 minutes)

The wizard guides you through 5 steps. Do NOT skip this — it configures your entire AI system.

### Wizard Step 1: Store Profile
- Enter your **store name** (e.g. "TechGadgetsHub")
- Select your **primary market**: USA, UK, East Africa, Europe, Global
- Choose your **product niche**: Electronics, Fashion, Home & Garden, Health, Sports, or General
- Set your **store currency** (USD recommended for international selling)

> 💡 **Why this matters**: The AI uses your niche and market to find relevant trending products. A "Electronics" store in the "USA" market gets completely different product recommendations than a "Fashion" store in "East Africa."

### Wizard Step 2: Connect Your First Supplier
- Click **"Connect AliExpress"** (recommended for beginners)
- You'll be redirected to AliExpress to authorize the connection
- Or click **"Connect CJ Dropshipping"** for faster shipping
- The AI will immediately start scanning for products in your niche

> 💡 **What happens now**: Within 60 seconds, the AI analyzes thousands of products and scores them. You don't need to do anything.

### Wizard Step 3: Set Your Profit Rules
This is the most important step. These rules govern every pricing decision.

- **Minimum margin**: Set to **35-40%** for beginners. This means the AI will NEVER price a product where you make less than 35-40% profit.
- **Maximum price vs. competitor**: Set to **"Match or slightly below"** until you have reviews.
- **Auto-import threshold**: Products scoring **75+** (out of 100) will be auto-imported.

> ⚠️ **Do not set minimum margin below 25%**. After payment processing fees (2.9%), shipping surprises, and occasional refunds, a 25% margin barely breaks even. 35%+ is the sweet spot.

### Wizard Step 4: Connect Payment Processing
- Click **"Connect Stripe"** → you'll go through Stripe's quick signup
- Or **"Connect PayPal"** if you prefer
- For East Africa: **"Connect M-Pesa"** → enter your Safaricom/M-Pesa business number
- Click **"Test Payment"** to verify connection

### Wizard Step 5: Connect Social Media (Optional but Powerful)
- Click **"Connect TikTok"** → authorize with your TikTok Business account
- Click **"Connect Instagram"** → authorize through Facebook (Instagram uses Facebook's API)
- Click **"Connect Facebook"** → authorize with your Facebook Business Manager

> 💡 **If you don't have business accounts yet**: Skip this step. Come back to it via Settings → Social Media after creating your business accounts. The platform will still work — you'll just approve ads manually.

Click **"Complete Setup"** — the wizard is done!

---

## Step 3: Your First Look at the Dashboard (3 minutes)

You're now on the **Overview dashboard**. Here's what everything means:

```
┌─────────────────────────────────────────────────────┐
│  Revenue     Orders    Products    Customers         │
│  $0.00       0         [X]         0                 │
│  (This will fill up once you get your first sale)    │
└─────────────────────────────────────────────────────┘
```

**The sidebar navigation**:
- 🏠 **Overview** — daily summary of your whole business
- 📦 **Products** — your product catalog
- 🛒 **Orders** — incoming customer orders
- 📊 **Analytics** — detailed performance data
- 📱 **Social Media** — your TikTok/Instagram/Facebook campaigns
- 🔥 **Viral Products** — trending products the AI is tracking
- 🤖 **Autopilot** — your AI store manager controls
- 📈 **Profitability** — real profit after all costs
- 🏭 **Suppliers** — your connected supplier accounts
- 💬 **AI Assistant** — ask your store AI anything
- ⚙️ **Settings** — account and configuration

---

## Step 4: Check Your Auto-Imported Products (2 minutes)

Click **"Products"** in the sidebar.

The AI has already imported its top-scoring products from your niche. You should see 10-20 products with:
- Product names and images
- Selling prices (AI-calculated based on your margin rules)
- AI scores (the higher the better)
- Status: "Active" means they're ready to sell

**What to do**:
1. Review the products — do they fit your niche?
2. If you see anything you don't want, click the trash icon
3. If everything looks good, move to Step 5

> 💡 **Don't obsess over perfection at this stage**. The AI will continuously refine your catalog based on what actually sells. Start with what's there and let data guide future decisions.

---

## Step 5: Launch Your First Social Media Campaign (10 minutes)

This is where money is made. Click **"Social Media"** in the sidebar.

### Create Your First Campaign

1. Click **"+ New Campaign"**
2. Select a product — choose one with an AI score above **75**
3. Select platforms — start with just **TikTok** or **Instagram** (not all three at once)
4. Set your daily budget — **start with $10-20/day** to test
5. Click **"Generate AI Creatives"**

**The AI will generate**:
- A TikTok video script (30 seconds, hook + demo + CTA)
- An Instagram Reel concept with captions
- Ad copy in 2 variants (A and B) for testing

6. Review the creatives — you can edit the copy if you want
7. Click **"Publish Campaign"**

> ⚠️ **Ad platforms review ads before going live**. TikTok typically approves within 2 hours. Facebook/Instagram within 24 hours. Don't panic if you don't see it immediately.

---

## Step 6: Enable Autopilot Mode (1 minute)

Click **"Autopilot"** in the sidebar.

You'll see a large toggle switch. Before enabling it, review the **Safety Rules** panel:

- ✅ Minimum margin protection: 35% (from your setup)
- ✅ Maximum daily ad spend: $20 (from your setup)
- ✅ Auto-pause ads below break-even ROAS
- ✅ Auto-switch supplier if reliability drops below 90%
- ✅ Auto-respond to customer tickets (confidence >85%)

If you're comfortable with these rules, toggle **Autopilot ON**.

> 💡 **The Autopilot is conservative by default**. It protects your money first. As you gain confidence, you can increase its autonomy in Settings → Autopilot Config.

---

## Step 7: Set Up Your Daily Report (1 minute)

Click **Settings → Notifications**.

- Enter your email address for daily reports
- Set your preferred delivery time (8:00 AM in your timezone recommended)
- Toggle **"Enable Daily AI Report"** ON

Starting tomorrow morning, you'll receive a plain-English email summary of your store's performance.

---

## Step 8: Understand Your Profitability Dashboard

Click **"Profitability"** in the sidebar.

Initially it will show zeros (no sales yet). Once orders start coming in, this dashboard shows your **real profit** — after all costs.

**Key metrics to watch**:
- **Net Profit Margin** — aim for >30% after all costs
- **ROAS by Platform** — if TikTok shows 3.5x and Facebook shows 1.2x, shift budget to TikTok
- **Product Profitability** — some products look good until you factor in shipping; this exposes that

---

## Step 9: Talk to Your AI Assistant

Click **"AI Assistant"** in the sidebar (or click the chat bubble icon at the bottom right).

This AI knows your store data and can answer questions like:
- *"Why did my revenue drop yesterday?"*
- *"Which product should I promote this week?"*
- *"What's my best-performing supplier?"*
- *"Should I lower the price on the wireless earbuds?"*
- *"How long until my LED lights stock runs out?"*

**Try asking it**: *"Give me a summary of my store's performance this week and what I should focus on."*

---

## Step 10: Your First Week Checklist

Print this out and check off each item:

**Day 1** (Today):
- [ ] Account created and verified
- [ ] Onboarding wizard completed
- [ ] At least 1 supplier connected
- [ ] At least 10 products imported
- [ ] First ad campaign created
- [ ] Autopilot enabled
- [ ] Daily report configured

**Days 2-3**:
- [ ] Check daily report emails
- [ ] Review Autopilot decisions log
- [ ] Check ad campaign performance (wait at least 48 hours before judging)
- [ ] Ask AI Assistant at least one question about your store

**Days 4-5**:
- [ ] Review your first Viral Products alerts
- [ ] If you have your first order: check it in the Orders section
- [ ] Review Profitability dashboard for early trends

**Days 6-7**:
- [ ] Connect second social platform if not done
- [ ] Review which products the AI is recommending for scaling
- [ ] Adjust Autopilot safety rules if needed based on your comfort

---

## Common Questions

**Q: The AI imported products I don't like. How do I control what it imports?**
Go to Settings → Autopilot Config → Auto-Import Rules. You can set keywords to exclude, price ranges, and categories. You can also set import to "Review Mode" where you approve each import manually.

**Q: My ad campaign was rejected by TikTok/Instagram. Why?**
The most common reasons: (1) Claims that are too bold ("cures X", "guaranteed results"), (2) Price claims that don't match your landing page, (3) Prohibited product categories. Check the rejection reason in Social Media → Campaigns and click "Fix Issues."

**Q: The Autopilot raised my prices. Is that right?**
Yes. If competitor prices are higher or demand is trending up, raising prices increases your margin without losing sales. Check Autopilot → Decisions Log to see exactly why it changed each price.

**Q: I'm not getting any sales. What should I do?**
First, check if your ads have been approved and are actually running. Second, check your product prices vs competitors manually. Third, ask the AI Assistant: "Why am I not getting sales and what should I change?" Fourth, make sure your payment gateway is properly configured by placing a test order.

**Q: How do I add my own products (not from AliExpress)?**
Go to Products → Add Product. You can manually enter all product details including images, pricing, and your supplier's information. The AI will still analyze it and include it in Autopilot decisions.

**Q: Is my store data safe?**
Your data is isolated from all other stores by tenant ID. Nobody else can see your products, orders, or customer data. All passwords are hashed with Argon2id (the strongest available algorithm). All connections are HTTPS encrypted. See Settings → Security for your account's security settings.

---

## Getting Help

**AI Assistant**: Click the chat bubble on any page. It knows your store data and can answer most operational questions instantly.

**Documentation**: This tutorial + the full EXPLANATION.md file cover everything in detail.

**Support tickets**: Settings → Help & Support → New Ticket. Our AI will respond within minutes for common questions, and route complex issues to human support within 24 hours.

---

*You're ready to start. The AI is already working in the background. Check back in 24 hours to see what it's found for you.*

**Good luck with your store! 🚀**
