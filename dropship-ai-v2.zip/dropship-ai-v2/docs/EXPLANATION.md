# DropShip AI Platform v2 — Complete System Explanation

> Everything you need to understand about how this platform works, why each piece exists, and how they all connect together. Written for both technical developers and non-technical store owners.

---

## Table of Contents

1. [What Is This Platform?](#1-what-is-this-platform)
2. [System Architecture Overview](#2-system-architecture-overview)
3. [Core AI Automation Modules](#3-core-ai-automation-modules)
4. [Social Media Automation Engine](#4-social-media-automation-engine)
5. [Analytics & Profit Intelligence](#5-analytics--profit-intelligence)
6. [The Autopilot System](#6-the-autopilot-system)
7. [Database Design](#7-database-design)
8. [Payment Systems](#8-payment-systems)
9. [Security Architecture](#9-security-architecture)
10. [Multi-Tenant SaaS Design](#10-multi-tenant-saas-design)
11. [Technology Choices Explained](#11-technology-choices-explained)
12. [How Profit Maximization Works](#12-how-profit-maximization-works)
13. [API Reference Summary](#13-api-reference-summary)

---

## 1. What Is This Platform?

DropShip AI is a **fully automated drop shipping management system** powered by artificial intelligence. It handles the most time-consuming parts of running a drop shipping store:

- **Finding products** that will sell before competitors discover them
- **Pricing products** at the maximum the market will bear without losing sales
- **Advertising products** on TikTok, Instagram, and Facebook automatically
- **Managing inventory** and switching suppliers when problems occur
- **Handling customers** via AI-powered support with zero human intervention
- **Reporting profits** daily so you always know exactly where you stand

### The Core Philosophy

Traditional drop shipping requires you to manually do everything. This platform inverts that model: **the AI acts as your full-time employee** that never sleeps, never makes emotional decisions, and optimizes purely for maximum profit.

---

## 2. System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          USER / STORE OWNER                              │
│                     (Browser / Mobile App)                               │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │ HTTPS
┌──────────────────────────────▼──────────────────────────────────────────┐
│                          NGINX (Reverse Proxy)                           │
│             Rate Limiting · SSL Termination · Load Balancing             │
└──────────┬───────────────────────────────────────────┬──────────────────┘
           │                                           │
┌──────────▼──────────┐                   ┌───────────▼──────────────────┐
│   Next.js Frontend   │                   │    NestJS Backend API         │
│  (SSR + React 18)    │◄──────REST API────►│  (REST · WebSockets)         │
│  TypeScript          │                   │  TypeScript                   │
└─────────────────────┘                   └───────────┬──────────────────┘
                                                      │
              ┌───────────────────────────────────────┼──────────────────┐
              │                   │                   │                   │
   ┌──────────▼──────┐  ┌─────────▼──────┐  ┌────────▼────────┐ ┌───────▼──────┐
   │  PostgreSQL 16   │  │  Redis 7 Cache  │  │  RabbitMQ 3.13 │ │  OpenAI API  │
   │  (Main Database) │  │  (Sessions +    │  │  (3 Queues)     │ │  (GPT-4o)    │
   │  Partitioned     │  │   Hot Data)     │  │  critical/      │ │              │
   │  Tables          │  │                 │  │  standard/      │ └──────────────┘
   └─────────────────┘  └─────────────────┘  │  background     │
                                              └────────┬────────┘
                                                       │ Queue Messages
              ┌────────────────────────────────────────┼──────────────────┐
              │              AI MODULE WORKERS (Python 3.12)               │
              │  ┌──────────────┐ ┌────────────────┐ ┌──────────────────┐ │
              │  │  Autopilot   │ │  Social Media  │ │  Viral Detector  │ │
              │  │  Worker      │ │  Worker        │ │  Worker          │ │
              │  └──────────────┘ └────────────────┘ └──────────────────┘ │
              │  ┌──────────────┐ ┌────────────────┐                       │
              │  │  Inventory   │ │  Daily Report  │                       │
              │  │  Forecaster  │ │  Worker        │                       │
              │  └──────────────┘ └────────────────┘                       │
              └───────────────────────────────────────────────────────────┘
                                       │
              ┌────────────────────────┼──────────────────────────────────┐
              │           EXTERNAL INTEGRATIONS                            │
              │  TikTok API · Instagram Graph · Facebook Ads · Stripe      │
              │  PayPal · M-Pesa · AliExpress · CJ Dropshipping           │
              └───────────────────────────────────────────────────────────┘
```

### Why This Architecture?

**NGINX as the gateway**: Every request goes through NGINX first. This gives us rate limiting (prevents abuse), SSL termination (handles HTTPS), and can load-balance across multiple backend instances as you scale.

**NestJS for the backend**: NestJS is built on top of Express.js but adds TypeScript decorators, dependency injection, and module organization. This makes the code maintainable as it grows. It's the same pattern used by enterprise companies.

**Next.js for the frontend**: React alone is a JavaScript library. Next.js adds server-side rendering (pages load faster for users and rank better on Google), file-based routing, and built-in image optimization.

**Redis for caching**: PostgreSQL database queries are powerful but slow for frequently-accessed data. Redis stores hot data in RAM. When 1,000 users view the same trending products list, we serve it from Redis in 0.1ms instead of hitting PostgreSQL every time.

**RabbitMQ for task queues**: AI operations (generating ad copy, analyzing products, syncing suppliers) take 2-30 seconds. If we ran them inline during a request, the user's browser would freeze. Instead, we drop tasks into a queue and process them in the background. The user gets an instant response and checks back for results.

**Consolidated to 3 queues**: The previous version had 9 queues which was over-engineered. Now:
- `critical` → order payments, fraud checks (processed immediately)
- `standard` → AI tasks, social media posting (processed within 30 seconds)
- `background` → daily reports, supplier syncs (processed within hours)

---

## 3. Core AI Automation Modules

### A1 — Auto-Product Import

**What it does**: Every 6 hours, the AI scans AliExpress and CJ Dropshipping for new products, scores them on 8 dimensions, and automatically imports the top performers into your catalog.

**The 8 scoring dimensions**:
1. **Trend velocity** — how fast is interest growing on TikTok/Google?
2. **Profit margin** — does it meet your minimum margin threshold (default: 40%)?
3. **Competition saturation** — how many other stores are selling this?
4. **Shipping viability** — can it ship to your target markets within acceptable timeframes?
5. **Impulse-buy factor** — is it the kind of product people buy on a whim?
6. **Visual appeal** — does it look good in video/photo ads? (AI vision analysis)
7. **Return risk** — based on product category and supplier history, how likely are returns?
8. **Social proof** — existing reviews, star ratings, order volume on source platforms

**Why this matters**: Most drop shippers spend 4-8 hours daily manually searching for products. The AI does this in minutes and never gets tired or biased.

**Code location**: `ai-modules/autopilot/auto_import.py` + `backend/src/modules/autopilot/auto-import.service.ts`

---

### A2 — Autopilot Mode

**What it does**: A single ON/OFF toggle that activates the AI store manager. When ON, the AI makes all operational decisions autonomously.

**What the Autopilot controls**:
- Reprices all products every 4 hours based on competitor data
- Detects low stock and places virtual reorder flags
- Switches to failover suppliers when primary supplier reliability drops below 90%
- Pauses ads that fall below break-even ROAS
- Generates fresh ad creatives when ad fatigue is detected
- Responds to all customer support tickets under the confidence threshold

**What the Autopilot will NOT do without approval**:
- Delete products
- Issue refunds over $100
- Change payment gateway settings
- Spend more than daily budget cap on ads

**The safety boundaries**: Every Autopilot action is logged to the `autopilot_decisions` table with a timestamp, the decision made, the data that drove the decision, and the outcome. You can audit every single decision the AI has made.

**Code location**: `backend/src/modules/autopilot/autopilot.service.ts` + `ai-modules/autopilot/worker.py`

---

### A5 — Viral Product Detector

**What it does**: Identifies products that are about to go viral on social media, typically 2-4 weeks before they peak. This gives you first-mover advantage.

**How early detection works**:
The AI monitors multiple leading indicators simultaneously:

1. **TikTok hashtag velocity** — a hashtag going from 10K to 500K views in 72 hours is a signal
2. **AliExpress order acceleration** — when weekly orders jump 300%+ with positive reviews
3. **Google Trends inflection points** — the moment a keyword breaks out of flat-line into growth
4. **Reddit and forum mentions** — product being discussed before it hits mainstream
5. **Instagram reel engagement rates** — organic posts with unusually high engagement

The system assigns a **Viral Score (0-100)** to each product. Anything above 75 is flagged for immediate review. The AI can automatically import and create ad campaigns for products scoring above your configured threshold.

**The math behind it**: We use a weighted moving average of all signals with exponential smoothing to reduce noise. A single spike in one metric doesn't trigger the detector — we need at least 3 signals moving in the same direction.

**Code location**: `ai-modules/viral_detector/worker.py` + `backend/src/modules/viral-detector/viral-detector.service.ts`

---

### A8 — Inventory Forecaster

**What it does**: Predicts when each product will run out of stock and automatically creates purchase requisitions before that happens.

**The forecasting model**:
Uses a combination of:
- **Historical sales velocity** (units sold per day, weighted toward recent days)
- **Seasonal adjustments** (same period last year)
- **Trend multiplier** (if product is trending, velocity will accelerate)
- **Lead time buffer** (supplier average shipping time + safety buffer)

**Formula**:
```
Days Until Stockout = Current Stock / (Daily Velocity × Trend Multiplier)
Reorder Date = Today + Days Until Stockout - Lead Time Buffer
```

**What happens automatically**:
When a product hits the reorder date, the system creates a `reorder_requisition` record, sends you a notification, and if Autopilot Mode is ON, can place the order with the supplier automatically.

**Code location**: `ai-modules/inventory_forecaster/worker.py`

---

## 4. Social Media Automation Engine

This is the most powerful revenue-generating feature in the platform.

### How It Works End-to-End

```
Product Identified → AI Scores TikTok Virality → AI Writes Scripts/Copy
       ↓
Creative Assets Generated → Platform-Specific Format Applied
       ↓
Optimal Posting Time Calculated → Published to TikTok/Instagram/Facebook
       ↓
Performance Monitoring → Underperformers Paused → Budget Reallocated
       ↓
Ad Fatigue Detected → Fresh Creatives Generated → Cycle Repeats
```

### S1 — TikTok Business API Integration

**Connection**: OAuth 2.0 flow through TikTok for Business. You authenticate once, the platform stores encrypted tokens.

**What the AI posts**:
- **Spark Ads** — boost your own organic posts (highest converting format)
- **In-Feed Video Ads** — 9:16 vertical video with native captions
- **TopView Ads** — premium placement (only for high-performing products)

**The TikTok Viral Score**: Before spending a single dollar, the AI calculates a virality score based on:
- Can this product be demonstrated visually in under 15 seconds?
- Does it have a "wow moment" or transformation?
- Is there an active TikTok trend/sound it can leverage?
- What's the impulse-buy potential?

Products scoring below 65/100 are not promoted on TikTok and budget is redirected to Facebook instead.

### S2 — Instagram Graph API Integration

**Connection**: Through Facebook Business Manager (Instagram Business accounts are managed under Facebook).

**Ad formats the AI creates**:
- **Reels Ads** — 15-30 second vertical videos, auto-captioned
- **Story Ads** — 24-hour disappearing format with swipe-up links
- **Shopping Posts** — product catalog tags with direct checkout
- **Carousel Ads** — multiple product images with individual CTAs

**Optimal posting windows**: The AI analyzes your account's historical engagement data to identify when your specific audience is most active (not generic "best time to post" advice — your audience specifically).

### S3 — Facebook Ads Manager Integration

**Connection**: Facebook Marketing API via Business Manager access token.

**Why Facebook is different**: Facebook's targeting is the most sophisticated of the three platforms. The AI leverages:
- **Lookalike Audiences** — find people who look like your existing customers
- **Dynamic Product Ads** — auto-generate ads from your product catalog
- **Retargeting** — show ads to people who visited your store but didn't buy
- **Custom Audiences** — target your existing customer list

**Budget intelligence**: The AI calculates your break-even ROAS for each product and sets Facebook bid strategies accordingly. If a product costs $10 and sells for $30 with $8 in shipping/fees, break-even ROAS = 1.6x. The AI targets 2.5x+ ROAS before scaling.

### S4 — AI Auto-Creative Generator

**The creative process**:
1. Product URL or ID is passed to the generator
2. AI analyzes product images using GPT-4 Vision
3. AI selects the most compelling visual angle
4. Platform-specific script/copy is generated
5. Copy is A/B tested with 2 variants per platform
6. Winners are scaled, losers are paused automatically

**Creative types generated**:
- TikTok: "Before/After" hooks, "POV" scenarios, trend-surfing scripts
- Instagram: Aesthetic product photography descriptions, lifestyle positioning
- Facebook: Benefit-focused, objection-handling, social proof copy

### S5 — Cross-Platform Campaign Orchestrator

**The budget allocation algorithm**:
When you set a daily ad budget, the AI distributes it across platforms based on:
1. Your historical ROAS per platform (TikTok vs Instagram vs Facebook)
2. Product category (fashion = Instagram, gadgets = TikTok, home goods = Facebook)
3. Target audience demographics
4. Current platform CPM rates (cost per 1,000 impressions)

**Example**: $100/day budget for a viral gadget product:
- TikTok: $55 (highest ROAS for gadget category based on historical data)
- Instagram: $30 (secondary platform, good for retargeting)
- Facebook: $15 (broad audience awareness)

### S6 — AI Performance Auto-Optimizer

**Triggers for optimization**:
- CTR drops >20% over 3 days → ad fatigue detected → generate new creatives
- ROAS falls below break-even → pause ad, alert user
- One ad variant outperforms other by >30% → kill loser, scale winner
- Daily budget overspent → automatic bid reduction
- Competitor enters same keyword space → adjust targeting

---

## 5. Analytics & Profit Intelligence

### AN1 — Daily AI Business Report

Every morning at 8:00 AM (your timezone), the AI generates a plain-English business summary and delivers it via email and in-app notification.

**Report structure**:
```
Yesterday's Performance:
- Revenue: $X (↑Y% vs same day last week)
- Profit: $X (margin: X%)
- Orders: X (X new customers, X returning)
- Ad Spend: $X → ROAS: Xx

Top 3 Performing Products:
1. [Product name] → $X profit, Xx ROAS
2. ...

Immediate Actions Required (0):
✅ All systems normal

Watch List (2):
⚠️ [Product] stock will run out in 4 days
⚠️ [Ad campaign] ROAS dropped to 1.2x (break-even: 1.6x)

AI Opportunities (1):
💡 [Product] is trending on TikTok (score: 87/100) — consider launching campaign
```

### AN2 — Profitability Dashboard

**True profit calculation** (not just revenue):
```
Revenue
- Supplier cost
- Shipping cost (inbound + outbound)
- Platform fees (Shopify/custom)
- Payment processing fees (2.9% + $0.30 for Stripe)
- Ad spend attributed to order
- Return rate adjustment
- Refunds
= True Profit
```

Most drop shippers track revenue and confuse it with profit. This dashboard shows you the real number.

**Profitability breakdowns available**:
- Per product
- Per supplier
- Per ad campaign
- Per customer acquisition channel
- Per geographic market
- Per customer segment

### AN4 — Anomaly Detector

**What constitutes an anomaly**:
- Revenue drops >30% compared to rolling 7-day average
- Conversion rate drops >25% (possible checkout issue)
- Refund rate spikes >5% (possible supplier quality issue)
- Ad spend exceeds budget by >10% (bidding anomaly)
- Supplier fulfillment rate drops below 90%
- Customer support ticket volume increases >50% in 24 hours

**Alert channels**: In-app notifications, email, optional SMS via Twilio.

---

## 6. The Autopilot System

The Autopilot is the crown jewel of this platform. It's what separates a software tool from a true AI business partner.

### Decision-Making Framework

The Autopilot uses a **confidence-based decision system**:

| Confidence | Action |
|------------|--------|
| >90% | Execute automatically, log decision |
| 70-90% | Execute automatically, send notification |
| 50-70% | Queue for user approval (24-hour timeout → auto-execute) |
| <50% | Alert user, require manual decision |

### The Profit Maximization Loop

Every 4 hours, the Autopilot runs this cycle:

```
1. Pull latest sales data for all products
2. For each product, calculate current margin
3. Check competitor prices (scrape or API)
4. Run demand signal analysis (trend score)
5. Calculate optimal price using multi-strategy AI
6. If new optimal price > current price by >2%: update price
7. If new optimal price < current price: simulate impact first
8. Log decision to autopilot_decisions table
```

### Loss Prevention Rules (Hard Limits)

The Autopilot will NEVER:
- Set a price below (cost × 1.15) — absolute floor is 15% margin
- Spend more than the daily ad budget cap
- Import products with <20% potential margin
- Continue a supplier with <85% reliability score
- Keep running ads with ROAS below 1.0 (losing money)

These rules are hardcoded and cannot be overridden by AI decisions.

---

## 7. Database Design

### Multi-Tenancy

Every table includes `tenant_id`. When a query runs, it always filters by tenant_id first. This means:
- Store A can never see Store B's data
- One database serves unlimited stores
- Each store pays for their own plan (free/starter/pro/enterprise)

### Partitioned Tables

High-volume tables are partitioned by date:
- `orders` — partitioned by month
- `ai_logs` — partitioned by month  
- `trends` — partitioned by month
- `pricing_history` — partitioned by year
- `social_posts` — partitioned by month

Why partition? A table with 10 million rows takes seconds to query. The same data split into monthly partitions means any date-range query only scans 1/24th of the data.

### Redis Caching Strategy

```
Cache Key Pattern → TTL
products:{tenantId}:list:{filters} → 5 minutes
trends:{tenantId}:top20 → 10 minutes
analytics:{tenantId}:dashboard → 1 minute
viral_scores:{date} → 1 hour
social_accounts:{tenantId} → 30 minutes
ai_recommendations:{tenantId} → 15 minutes
```

---

## 8. Payment Systems

### Stripe (Primary for US/EU)
- Payment intents with 3D Secure support
- Webhook signature verification (HMAC-SHA256)
- Automatic retry for failed charges
- Refund processing with amount validation

### PayPal REST SDK v2 (Updated from deprecated v1)
- OAuth 2.0 client credentials
- Order creation → approval → capture flow
- Sandbox/Production switching via config

### M-Pesa (East Africa)
- STK Push (Lipa Na M-Pesa Online)
- Callback URL verification
- Tanzania and Kenya shortcode support
- Currency conversion: KES/TZS → USD for reporting

---

## 9. Security Architecture

### Authentication Flow
```
User submits email + password
      ↓
Argon2id hash verification (memory-hard, GPU-resistant)
      ↓
Generate JWT access token (15 minute expiry)
Generate random refresh token → hash with SHA-256 → store in DB
      ↓
Return both tokens to client
      ↓
Client stores access token in memory (not localStorage)
Client stores refresh token in httpOnly cookie
      ↓
Access token expires → client sends refresh token
Server verifies hash → rotate: revoke old, issue new pair
```

### Token Rotation Security
If an attacker steals a refresh token and uses it after the legitimate user has already used it, the server detects **token reuse** (the stolen token has been revoked). The entire token family is immediately invalidated, forcing re-authentication.

### Rate Limiting
```
/auth/login → 5 requests/minute per IP
/auth/register → 3 requests/minute per IP
/api/v1/* → 100 requests/minute per user
/api/v1/ai/* → 20 requests/minute per user (expensive operations)
```

### Input Validation
Every API endpoint uses class-validator to whitelist allowed fields. If you send unexpected fields, they are silently stripped. SQL injection is prevented by TypeORM's parameterized queries.

---

## 10. Multi-Tenant SaaS Design

### Plan Limits

| Feature | Free | Starter | Pro | Enterprise |
|---------|------|---------|-----|------------|
| Products | 50 | 500 | Unlimited | Unlimited |
| Orders/month | 100 | 1,000 | Unlimited | Unlimited |
| AI tasks/day | 10 | 100 | Unlimited | Unlimited |
| Social accounts | 0 | 1 each | 3 each | Unlimited |
| Autopilot | ❌ | ❌ | ✅ | ✅ |
| Daily AI Report | ❌ | ✅ | ✅ | ✅ |
| Team members | 1 | 3 | 10 | Unlimited |

### Data Isolation
Row-level security via `tenant_id` on every table. The `TenantGuard` in NestJS extracts tenant from JWT and injects it into every query. Impossible to query another tenant's data even with a valid access token.

---

## 11. Technology Choices Explained

| Technology | Why Chosen | Alternative Considered |
|------------|------------|----------------------|
| **NestJS** | TypeScript + DI + modules = maintainable | Express (too bare), Fastify (less ecosystem) |
| **Next.js 14** | SSR for SEO + App Router + Server Components | CRA (dead), Vite+React (no SSR) |
| **PostgreSQL 16** | JSONB + partitioning + full-text search | MySQL (weaker JSON), MongoDB (no joins) |
| **Redis 7** | Pub/Sub + sorted sets + streams in one | Memcached (no persistence), Elasticsearch (heavy) |
| **RabbitMQ** | Reliable delivery + DLQ + management UI | Kafka (overkill), SQS (AWS lock-in) |
| **Python for AI workers** | OpenAI SDK maturity + numpy/pandas for ML | Node.js (less mature ML ecosystem) |
| **Tailwind CSS** | Utility-first = no CSS files to maintain | MUI (opinionated), Styled Components (slow) |
| **Argon2id** | Winner of Password Hashing Competition 2015 | bcrypt (older), scrypt (less support) |
| **Framer Motion** | Best React animation library | CSS animations (limited), React Spring (complex API) |
| **Zustand** | Minimal, fast, no boilerplate | Redux (heavy), Jotai (less ecosystem) |

---

## 12. How Profit Maximization Works

The platform uses a **Profit Maximization Stack** — multiple layers working together:

### Layer 1: Product Selection (Upstream)
- Only import products with >40% potential margin
- Viral Score >65 = higher priority for ad spend
- Return Risk Score <30% = prefer these products

### Layer 2: Dynamic Pricing (Continuous)
- Every 4 hours: compare your price to top 5 competitors
- If competitors are higher: raise your price (maximize margin)
- If competitors are lower: analyze elasticity — is the lower competitor high-quality?
- If demand is trending up: raise price proactively
- Hard floor: cost × 1.15 (15% minimum margin)

### Layer 3: Ad Efficiency (Spend Less, Earn More)
- Kill ads below break-even ROAS within 48 hours
- Scale winning ads aggressively (up to 3x budget increase per week)
- Fresh creatives on 14-day rotation to prevent fatigue
- Cross-platform budget optimization — money follows ROAS

### Layer 4: Loss Prevention (Reduce Losses)
- Fraud detection on every order (saves chargeback fees)
- Return risk flagging (prevents stocking products customers return)
- Supplier reliability scoring (switches before problems escalate)
- Refund amount alerts (catches patterns before they become losses)

### Layer 5: Customer Lifetime Value (Long-term)
- Repeat customer identification → lower acquisition cost
- Segmentation → right message to right customer
- AI email marketing → automated retention without effort

---

## 13. API Reference Summary

### Authentication
```
POST /api/v1/auth/register     Create account
POST /api/v1/auth/login        Get tokens
POST /api/v1/auth/refresh      Refresh tokens
POST /api/v1/auth/logout       Revoke tokens
GET  /api/v1/auth/me           Current user
```

### Autopilot
```
GET  /api/v1/autopilot/status       Get autopilot state
POST /api/v1/autopilot/enable       Enable autopilot
POST /api/v1/autopilot/disable      Disable autopilot
GET  /api/v1/autopilot/decisions    Get all AI decisions made
GET  /api/v1/autopilot/config       Get current rules
PUT  /api/v1/autopilot/config       Update rules and limits
POST /api/v1/autopilot/auto-import  Trigger manual product import
```

### Social Media
```
POST /api/v1/social/connect/:platform    OAuth connect
DELETE /api/v1/social/disconnect/:platform
GET  /api/v1/social/accounts            Connected accounts
POST /api/v1/social/campaign            Create campaign
GET  /api/v1/social/campaigns           List campaigns
GET  /api/v1/social/analytics           Platform analytics
POST /api/v1/social/generate-creative   Generate ad creative
POST /api/v1/social/publish/:campaignId Publish campaign
```

### Viral Detector
```
GET  /api/v1/viral/scores          Get top viral products
GET  /api/v1/viral/trending        Current trending signals
POST /api/v1/viral/analyze/:id     Analyze specific product
GET  /api/v1/viral/history         Historical viral predictions
```

### Inventory Forecaster
```
GET  /api/v1/inventory/forecasts    All products with forecasts
GET  /api/v1/inventory/reorders     Products needing reorder
GET  /api/v1/inventory/:id/forecast Specific product forecast
POST /api/v1/inventory/run-forecast Trigger forecast run
```

### Profitability
```
GET  /api/v1/profitability/overview     Summary metrics
GET  /api/v1/profitability/products     Per-product breakdown
GET  /api/v1/profitability/suppliers    Per-supplier breakdown
GET  /api/v1/profitability/campaigns    Per-campaign breakdown
GET  /api/v1/profitability/customers    Per-customer LTV
GET  /api/v1/profitability/report       Export profitability report
```

### Daily Report
```
GET  /api/v1/daily-report/latest    Get today's/yesterday's report
GET  /api/v1/daily-report/history   Past reports
POST /api/v1/daily-report/generate  Force report generation
```

---

*This documentation is auto-updated with each platform release. Last updated: v2.0.0*
