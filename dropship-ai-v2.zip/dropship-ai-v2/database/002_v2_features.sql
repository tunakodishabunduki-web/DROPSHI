-- ─────────────────────────────────────────────────────────────────────────────
-- DropShip AI v2 — New Tables Migration
-- Adds: autopilot, social media, viral detection, profitability, daily reports
-- ─────────────────────────────────────────────────────────────────────────────

-- ── Autopilot Config ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS autopilot_configs (
  id                        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id                 UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE UNIQUE,
  enabled                   BOOLEAN NOT NULL DEFAULT false,
  enabled_by                UUID REFERENCES users(id),
  enabled_at                TIMESTAMPTZ,
  min_margin_percent        NUMERIC(5,2) NOT NULL DEFAULT 35,
  max_daily_ad_spend        NUMERIC(10,2) NOT NULL DEFAULT 50,
  min_supplier_reliability  NUMERIC(3,2) NOT NULL DEFAULT 0.90,
  min_roas_threshold        NUMERIC(4,2) NOT NULL DEFAULT 1.6,
  auto_import_threshold     NUMERIC(5,2) NOT NULL DEFAULT 75,
  auto_respond_confidence   NUMERIC(3,2) NOT NULL DEFAULT 0.85,
  pricing_strategy          VARCHAR(30) NOT NULL DEFAULT 'ai_optimal',
  max_price_increase_percent NUMERIC(5,2) NOT NULL DEFAULT 15,
  require_approval_above    NUMERIC(10,2) NOT NULL DEFAULT 100,
  metadata                  JSONB NOT NULL DEFAULT '{}',
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Autopilot Decisions ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS autopilot_decisions (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id         UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  action            VARCHAR(100) NOT NULL,
  target            VARCHAR(50) NOT NULL,
  target_id         UUID,
  old_value         JSONB,
  new_value         JSONB,
  confidence        NUMERIC(4,3) NOT NULL,
  reasoning         TEXT NOT NULL,
  approved          BOOLEAN NOT NULL DEFAULT false,
  requires_approval BOOLEAN NOT NULL DEFAULT false,
  approved_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);

CREATE TABLE autopilot_decisions_2026 PARTITION OF autopilot_decisions
  FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE INDEX idx_autopilot_decisions_tenant ON autopilot_decisions(tenant_id, created_at DESC);
CREATE INDEX idx_autopilot_decisions_action ON autopilot_decisions(action, approved);

-- ── Social Accounts ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS social_accounts (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  platform         VARCHAR(30) NOT NULL,
  account_id       VARCHAR(255),
  account_name     VARCHAR(255),
  access_token     TEXT NOT NULL,
  refresh_token    TEXT,
  token_expires_at TIMESTAMPTZ,
  is_active        BOOLEAN NOT NULL DEFAULT true,
  connected_at     TIMESTAMPTZ,
  metadata         JSONB NOT NULL DEFAULT '{}',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, platform)
);
CREATE INDEX idx_social_accounts_tenant ON social_accounts(tenant_id, is_active);

-- ── Social Campaigns ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS social_campaigns (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id      UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  product_id     UUID REFERENCES products(id),
  name           VARCHAR(255) NOT NULL,
  platforms      TEXT[] NOT NULL DEFAULT '{}',
  status         VARCHAR(30) NOT NULL DEFAULT 'draft',
  daily_budget   NUMERIC(10,2) NOT NULL,
  total_budget   NUMERIC(12,2),
  budget_split   JSONB NOT NULL DEFAULT '{}',
  duration_days  INTEGER NOT NULL DEFAULT 7,
  target_audience JSONB NOT NULL DEFAULT '{}',
  creatives      JSONB NOT NULL DEFAULT '[]',
  external_ids   JSONB NOT NULL DEFAULT '{}',
  total_spent    NUMERIC(12,2) NOT NULL DEFAULT 0,
  starts_at      TIMESTAMPTZ,
  ends_at        TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_social_campaigns_tenant ON social_campaigns(tenant_id, status, created_at DESC);

-- ── Social Posts ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS social_posts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES social_campaigns(id) ON DELETE CASCADE,
  platform    VARCHAR(30) NOT NULL,
  external_id VARCHAR(255),
  status      VARCHAR(30) NOT NULL DEFAULT 'pending',
  published_at TIMESTAMPTZ,
  impressions BIGINT NOT NULL DEFAULT 0,
  clicks      BIGINT NOT NULL DEFAULT 0,
  conversions BIGINT NOT NULL DEFAULT 0,
  spent       NUMERIC(10,2) NOT NULL DEFAULT 0,
  roas        NUMERIC(8,4),
  ab_variant  VARCHAR(10),
  metadata    JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);

CREATE TABLE social_posts_2026 PARTITION OF social_posts
  FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE INDEX idx_social_posts_campaign ON social_posts(campaign_id, created_at DESC);
CREATE INDEX idx_social_posts_platform ON social_posts(tenant_id, platform, status);

-- ── Daily Reports ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS daily_reports (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  report_date DATE NOT NULL,
  data        JSONB NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, report_date)
);
CREATE INDEX idx_daily_reports_tenant ON daily_reports(tenant_id, report_date DESC);

-- ── Triggers ──────────────────────────────────────────────────────────────────
CREATE TRIGGER trg_autopilot_configs_updated_at
  BEFORE UPDATE ON autopilot_configs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_social_accounts_updated_at
  BEFORE UPDATE ON social_accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_social_campaigns_updated_at
  BEFORE UPDATE ON social_campaigns
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
